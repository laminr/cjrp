<!DOCTYPE html>
<html lang="en">
  <head>
    <title>CJRP Travel</title>    
    <!-- Bootstrap -->
    <link href="{{asset('css/bootstrap.min.css')}}" rel="stylesheet" media="screen">
    <link href="{{asset('css/commons.css')}}" rel="stylesheet" media="screen">

    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,300' rel='stylesheet' type='text/css'>

    <style type="text/css">
      .text {
        font-size: 2em; 
        width: 400px;
        text-shadow: 1px 1px 0px #fff;
        color: #6281A3;
      }
    </style>
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="js/assets/html5shiv.js"></script>
      <script src="js/assets/respond.min.js"></script>
    <![endif]-->
  </head>
  <body id="404">
    <div class="container">
      <div class="row">
        <div class="col-md-6 col-xs-12 col-md-offset-3">
          <a href="/">
            <img src="img/cjrp-logo_large.png" alt="CJRP Travel">
          </a>
          <p class="text container">
           Currently under maintenance, we will back shortly ?
          </p>
        </div>
      </div>
    </div>
  </body>
</html>