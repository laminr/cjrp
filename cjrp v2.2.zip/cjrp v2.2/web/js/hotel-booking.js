
$(function (){
    $('#myCarousel').carousel({interval: 3000});

    $('#booking-tab a').click(function (e) {
      e.preventDefault();
      $(this).tab('show');
    })

    $('#check-out-date').datepicker({minDate: 0});
    $('#check-in-date').datepicker({
        minDate: 0,
        onSelect : function(clickDate) {
            $('#check-out-date').datepicker( "option", "minDate", clickDate );          
        }
    });

});