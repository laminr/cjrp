
$(function(){

});

function setFormValue(company, car, ratingId, total, fee, fullTotal ){
    
    $('input[id$="ratingId"').val(ratingId);
    $('input[id$="totalPrice"').val(ratingId);
    
    var message = $('textarea[id$="comment"').val();
    var messageWithCommpanie = message.replace("#companie#", company);
    var message = messageWithCommpanie.replace("#car#", car);
    
    $('textarea[id$="comment"').val(message);

    $('#service-fee #final-charge').html('$'+total.toFixed(2));
    $('#service-fee #final-fee').html('$'+fee.toFixed(2));
    $('#service-fee #final-total').html('$'+fullTotal.toFixed(2));

    $('#modal-message').modal({
        keyboard: true
    });
}

function displayPriceList(carId) {
    $('#'+carId+' .price-list').toggle();

    if ($('#'+carId+' button.btn-sm').hasClass('btn-primary')) {
        $('#'+carId+' button.btn-sm').removeClass('btn-primary').addClass('btn-default').text('See less');
    } else {
        $('#'+carId+' button.btn-sm').removeClass('btn-default').addClass('btn-primary').text('See more');
    }
}