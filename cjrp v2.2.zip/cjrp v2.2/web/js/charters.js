
$(function(){

	$('#returnDate').datepicker({minDate: 0});
    $('#departureDate').datepicker({
      minDate: 0,
      onSelect : function(clickDate) {
      $('#returnDate').datepicker( "option", "minDate", clickDate );       
      }
    });
    
	$('.timespinner').timepicker();
});

function chooseRoundtrip(isRoundtrip) {
	if (isRoundtrip == true) {
		$("#roundtrip-choice").removeClass("btn-default").addClass("btn-primary");
		$("#oneway-choice").removeClass("btn-primary").addClass("btn-default");
		$("#unable").fadeOut(500);
		$("#isRoundtrip").val(true);
	} else {
		$("#oneway-choice").removeClass("btn-default").addClass("btn-primary");
		$("#roundtrip-choice").removeClass("btn-primary").addClass("btn-default");
		$("#unable").fadeIn(500);
		$("#isRoundtrip").val(false);
	}
}