//*
var scrolling = function(){
    var speed     = 1000;
    jQuery('#menu-b4ufly a[href^="before-you-fly.php"]').bind('click',function(){
        var id = jQuery(this).attr('href');

        goTo(this.hash);
        return(false);
        void(0);
    });

    function goTo(ancre){
        jQuery('html,body').animate({scrollTop:jQuery(ancre).offset().top},speed,'swing',function(){
            if(ancre != 'body')
                window.location.hash = ancre;
            else
                window.location.hash = '#';

            jQuery(ancre).attr('tabindex','-1');
            jQuery(ancre).focus();
            jQuery(ancre).removeClass('tabindex');
        });
    }
};

$(function(){
    scrolling();
});