
$(function (){
    $('#myCarousel').carousel({interval: 5000});

    $('#booking-tab a').click(function (e) {
      e.preventDefault();
      $(this).tab('show');
    })

    $("input[id$='dropOffDate']").datepicker({minDate: 0});
    $("input[id$='pickUpDate']").datepicker({
    	minDate: 0,
    	onSelect : function(clickDate) {
    		$("input[id$='dropOffDate']").datepicker( "option", "minDate", clickDate );    		
    	}
    });

});