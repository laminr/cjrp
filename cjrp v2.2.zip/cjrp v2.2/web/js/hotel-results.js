
$(function(){

});

function setFormValue(hotelName, hotelRatingId, grandTotal, includedTaxe, fee, fullTotal ){
    
    $('#hotelRatingId').val(hotelRatingId);

    var message = $('#final-message').val();
    var messageWithHotel = message.replace("#hotel#", hotelName);
    
    $('#final-message').val(messageWithHotel);

    $('#service-fee #final-charge').html('$'+grandTotal.toFixed(2));
    $('#service-fee #final-tax').html('$'+includedTaxe.toFixed(2));
    $('#service-fee #final-fee').html('$'+fee.toFixed(2));
    $('#service-fee #final-total').html('$'+fullTotal.toFixed(2));

    $('#modal-message').modal({
        keyboard: true
    });
}

function displayPriceList(hotelId) {
    $('#'+hotelId+' .price-list').toggle();

    if ($('#'+hotelId+' button.btn-sm').hasClass('btn-primary')) {
        $('#'+hotelId+' button.btn-sm').removeClass('btn-primary').addClass('btn-default').text('See less');
    } else {
        $('#'+hotelId+' button.btn-sm').removeClass('btn-default').addClass('btn-primary').text('See more');
    }
}