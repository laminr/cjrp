var pics = [
	{extension: "car_", alt: "Car rental" ,nbr: 5, widths: [149, 148, 174, 125, 243]},
	{extension: "cruise_", alt: "Cruise booking" , nbr: 8, widths: [152, 160, 142, 160, 95, 137, 155, 100]},
	{extension: "gen_" , alt: "CJRP Travel" , nbr: 7, widths: [150, 160, 153, 213, 139, 127, 149]},
	{extension: "hotel_" , alt: "Hotel booking" , nbr: 7, widths: [133, 139, 214, 149, 139, 153, 134]}
];

$(function (){
	var viewport = $(window).width();
	$(".img-line").each(
		function() {
			var currentElement = $(this);
			
			var size = 0;
			var count = 0;
			var html = '';
			while(size < viewport && count < 20) {
				for (var i = 0; i < pics.length; i++) {
					var index = Math.floor((Math.random()*pics[i].nbr)+1);
					size += pics[i].widths[index-1];
					if (size < viewport) { 
						html += '<img src="'+symPath+'/line/'+pics[i].extension+index+'.jpg" alt="'+pics[i].alt+'" />';
					}else{
						$(this).css("background-image", "url('"+symPath+"/line/"+pics[i].extension+index+".jpg')");
						break;
					}
					count++;
				}
			}
			$(this).html(html);
		}
	);
});
