var airports = [
	{code : "ANU", country : 'Antigua' , name : 'VC Bird Intl'},
	{code : "SKB", country : 'St. Kitts', name : 'Robert L. Bradshaw'},
	{code : "EIS", country : 'Tortola' , name: 'Terrance B. Lettsome Intl'},
	{code : "AXA", country : 'Anguilla' , name : 'Claton J. Lloyd Intl Aiport'},
	//{code : "BPF", country : 'Anguilla' , name : 'Blowing Point Ferry Terminal'},
	{code : "SXM", country : 'St. Maarten' , name : 'Juliana Airport'},
	{code : "DOM", country : 'Dominica' , name : 'Melville Hall'},
	{code : "STT", country : 'St. Thomas' , name : 'U.S.V.I'},
	{code : "SJU", country : 'Puerto Rico' , name : 'Puerto Rico'},
	{code : "NGD", country : 'Anegada VG' , name : 'Anegada Airport'},
	{code : "NEV", country : 'Nevis' , name : 'Nevis'},
	{code : "VIJ", country : 'Virgin Gorda', name : 'Airport'}
];

var routes = [
	{departure: "ANU", destinations: ["SKB", "EIS", "AXA"]},
	{departure: "SKB", destinations: ["SJU", "EIS", "AXA", "ANU"]},
	{departure: "EIS", destinations: ["SXM", "STT", "SKB", "SJU", "NGD", "DOM", "AXA", "ANU"]},
	{departure: "AXA", destinations: ["SKB", "EIS", "ANU", "SJU"]},
	{departure: "BPF", destinations: ["SXM"]},
	{departure: "SXM", destinations: ["SKB", "EIS", "DOM", "AXA"]},
	{departure: "DOM", destinations: ["SXM", "EIS"]},
	{departure: "STT", destinations: ["VIJ", "NGD", "EIS"]},
	{departure: "SJU", destinations: ["SKB", "EIS", "NEV", "AXA"]},
	{departure: "NGD", destinations: ["VIJ", "STT", "EIS"]},
	{departure: "NEV", destinations: ["AXA", "SJU"]},
	{departure: "VIJ", destinations: ["SXM", "STT", "NGD"]}
];

function compareAirport(a,b) {
	if (a.country < b.country)
 		return -1;
  	if (a.country > b.country)
    	return 1;
  	return 0;
}

function updateDestination(target, from) {
	var options = "";
	var destinations = null;
	for (index in routes) {
		if (routes[index].departure == from) {
			destinations = routes[index].destinations;
		}
	};

	
	if (destinations != null) {
		var airportsList = [];
		for(indexDestinations in destinations) {
			for(indexAirport in airports) {
				if (airports[indexAirport].code == destinations[indexDestinations]) {
					airportsList.push(airports[indexAirport]);
					break;
				}
			}
		}
		if (airportsList.length > 0){
			// in order
			airportsList.sort(compareAirport);
			// options
			options = createHtmlOption(airportsList);
		}
	} else {
		// in order first
		airports.sort(compareAirport);
		options = createHtmlOption(airports);
	}
	//console.log(options);
	document.getElementById(target).innerHTML = options;

}

function createHtmlOption(airportsList) {
	var options = '<option value=""></option>';
	for(indexAirport in airportsList) {
		options += '<option value="'
			+airportsList[indexAirport].code+'">'
			+airportsList[indexAirport].country
			+' ('+airportsList[indexAirport].code+') '
		+'</option>';
	}
	return options;
}

function udpatePaxTotalNbr() {
	document.getElementById("passengers").value 
		= parseInt(document.getElementById("adult_passengers").value)
		+ parseInt(document.getElementById("senior_passengers").value)
		+ parseInt(document.getElementById("child_passengers").value)
		+ parseInt(document.getElementById("infant_passengers").value);
	//console.log(document.getElementById("passengers").value);
}
///var test = updateDestination("SXM");