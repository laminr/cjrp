var tick=0;
var maxTick=20;
var interval;

$(function (){
    $('#myCarousel').carousel({interval: 5000});
    // Bookings Tab
    $('#booking-tab a').click(function (e) {
      e.preventDefault();
      
      $(this).tab('show');
      if (e.target.hash == '#check-online') {
        startCheckInTimer();
      } else {
        resetCheckInTimer();
      }
    })
    // tooltip
    $('.flight-tooltip').tooltip();
    //*
    var nowTemp = new Date();
    var now = new Date(nowTemp.getFullYear(), nowTemp.getMonth(), nowTemp.getDate(), 0, 0, 0, 0);

    $('#ferry-return-date').datepicker({minDate: 0});
    $('#ferry-depart-date').datepicker({
      minDate: 0,
      onSelect : function(clickDate) {
      $('#ferry-return-date').datepicker( "option", "minDate", clickDate );       
      }
    });

    $('#flight-return-date').datepicker({minDate: 0});
    $('#flight-depart-date').datepicker({
      minDate: 0,
      onSelect : function(clickDate) {
      $('#flight-return-date').datepicker( "option", "minDate", clickDate );       
      }
    });    

});

function startCheckInTimer() {
  interval = setInterval(
    function(){
      tick++;
      if (tick >= maxTick) {
        $('#check-online input').val('');
      }
    }
    ,1000);
}

function resetCheckInTimer() {
  window.clearInterval(interval);
  tick=0;
}