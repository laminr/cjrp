var tick = 0;
// var myVar=setInterval(function(){myTimer()},1000);

function enterFerryForm() {
	var d=new Date();
	var t=d.toLocaleTimeString();
	document.getElementById("demo").innerHTML=t;
}

function notInFerryForm() {
	window.clearInterval(intervalVariable);
}
