<?php

namespace cjrp\AdminBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class cjrpAdminBundle extends Bundle
{
}
