<?php
namespace cjrp\AdminBundle\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Bridge\Doctrine\RegistryInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use cjrp\WebsiteBundle\Entity\Company;
use cjrp\WebsiteBundle\Entity\Room;

class HotelRatingType extends AbstractType {

	private $doctrine;
	
	public function __construct(RegistryInterface $doctrine)
	{
		$this->doctrine = $doctrine;
	}
	
	public function buildForm(FormBuilderInterface $builder, array $options)
	{
		$em = $this->doctrine->getManager();
		$query = $em->createQuery(
              		'SELECT c
                     FROM cjrpWebsiteBundle:Company c
                     ORDER BY c.name ASC');
		$companies = $query->getResult();
		//var_dump($companies);
		
		$query = $em->createQuery(
				'SELECT r
                 FROM cjrpWebsiteBundle:Room r
                 ORDER BY r.description ASC');
		$rooms = $query->getResult();
		//var_dump($rooms);
		
		$builder->add('id', 'hidden')
				->add('company', 'entity', array(
						'choices' => $companies,
						'class' => 'cjrpWebsiteBundle:Company',
						'property' => 'name',
						'multiple'  => false,
						'required' => true)
				)				
	    		->add('perDay', 'money', array('currency'=>'USD'))
	    		->add('taxe', 'percent')
	    		->add('government', 'money', array('currency'=>'USD'))
	    		->add('fee', 'money', array('currency'=>'USD'))
	    		->add('room', 'entity', array(
	    				'choices' => $rooms,
	    				'class' => 'cjrpWebsiteBundle:Room',
	    				'property' => 'description',
	    				'multiple'  => false,
	    				'required' => true)
	    		)
	    		->add('save', 'submit');
	}
	
	public function getName()
	{
		return 'HotelRatingType'; //must be unique.
	}
	
	//Symfony can guess the type but it is a good practice to always set de data_class because embedding forms is necessary.
	public function setDefaultOptions(OptionsResolverInterface $resolver)
	{
		$resolver->setDefaults(array(
				'data_class' => 'cjrp\WebsiteBundle\Entity\HotelRating',
				'cascade_validation' => true, //needed to validate embeed forms.
				'validation_groups' => array('hr_creation'), //use of validation groups.
				'csrf_protection' => true,
				'csrf_field_name' => '_addhrtoken', // a unique key to help generate the secret token
				'intention' => 'addhr_item',
		));
	}
}