<?php
namespace cjrp\AdminBundle\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Bridge\Doctrine\RegistryInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class NewsType extends AbstractType {

	public function buildForm(FormBuilderInterface $builder, array $options)
	{

		$builder->add('id', 'hidden')
	    		->add('when', 'datetime')
	    		->add('title', 'text')
	    		->add('content', 'textarea')
				->add('save', 'submit');
	}
	
	public function getName()
	{
		return 'NewsType'; //must be unique.
	}
	
	//Symfony can guess the type but it is a good practice to always set de data_class because embedding forms is necessary.
	public function setDefaultOptions(OptionsResolverInterface $resolver)
	{
		$resolver->setDefaults(array(
				'data_class' => 'cjrp\WebsiteBundle\Entity\News',
				'cascade_validation' => true, //needed to validate embeed forms.
				'validation_groups' => array('news_creation'), //use of validation groups.
				'csrf_protection' => true,
				'csrf_field_name' => '_addNewsToken', // a unique key to help generate the secret token
				'intention' => 'addNews_item',
		));
	}
}