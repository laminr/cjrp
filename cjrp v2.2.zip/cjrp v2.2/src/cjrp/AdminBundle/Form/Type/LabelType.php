<?php
namespace cjrp\AdminBundle\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Bridge\Doctrine\RegistryInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

use cjrp\WebsiteBundle\Entity\Label;

class LabelType extends AbstractType {

	private $doctrine;
	
	public function __construct(RegistryInterface $doctrine)
	{
		$this->doctrine = $doctrine;
	}
	
	public function buildForm(FormBuilderInterface $builder, array $options)
	{
		$em = $this->doctrine->getManager();
		//*
		$query = $em->createQuery('SELECT l.type, l.type FROM cjrpWebsiteBundle:Label l GROUP BY l.type ORDER BY l.type ASC');
		$arrayTypes = $query->getResult();
		
		// transforming the array, source is [x] => array("type" => "theType")
		$types = array();
		foreach ($arrayTypes as $key => $value) {
			$types[$value['type']] = $value['type'];	
		}
		//*/
		//$types = array(Label::TYPE_CITY => Label::TYPE_CITY, Label::TYPE_ISLAND => Label::TYPE_ISLAND);
		$builder->add('id', 'hidden')
	    		->add('type', 'choice', array(
						'choices' => $types,
						'required' => true)
	    		)
	    		->add('value', 'text')
				->add('save', 'submit');
	}
	
	public function getName()
	{
		return 'LabelType'; //must be unique.
	}
	
	//Symfony can guess the type but it is a good practice to always set de data_class because embedding forms is necessary.
	public function setDefaultOptions(OptionsResolverInterface $resolver)
	{
		$resolver->setDefaults(array(
				'data_class' => 'cjrp\WebsiteBundle\Entity\Label',
				'cascade_validation' => true, //needed to validate embeed forms.
				'validation_groups' => array('label_creation'), //use of validation groups.
				'csrf_protection' => true,
				'csrf_field_name' => '_addlabeltoken', // a unique key to help generate the secret token
				'intention' => 'addlabel_item',
		));
	}
}