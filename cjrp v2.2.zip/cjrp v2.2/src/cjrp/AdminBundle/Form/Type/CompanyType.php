<?php
namespace cjrp\AdminBundle\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Bridge\Doctrine\RegistryInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use cjrp\WebsiteBundle\Entity\Label;

class CompanyType extends AbstractType {

	private $doctrine;
	
	public function __construct(RegistryInterface $doctrine)
	{
		$this->doctrine = $doctrine;
	}
	
	public function buildForm(FormBuilderInterface $builder, array $options)
	{
		$repo = $this->doctrine->getRepository('cjrpWebsiteBundle:Label');
		
		$islands = $repo->findAllIslands();
		$cities = $repo->findAllCities();
		$types = $repo->findAllCompanyTypes();
		
		$builder->add('id', 'hidden')
	    		->add('name', 'text')
				->add('island', 'entity', array(
						'choices' => $islands,
						'class' => 'cjrpWebsiteBundle:Label', 
						'property' => 'value',
						'multiple'  => false, 
						'required' => true)
				)
				->add('city', 'entity', array(
						'choices' => $cities, 
						'class' => 'cjrpWebsiteBundle:Label',
						'property' => 'value',
						'multiple'  => false, 
						'required' => true)
				)
				->add('type', 'entity', array(
						'choices' => $types, 
						'class' => 'cjrpWebsiteBundle:Label',
						'property' => 'value',
						'multiple'  => false, 
						'required' => true)
				)
				->add('rating', 'choice', array('choices' => array(1=>1, 2=>2,3=>3,4=>4,5=>5)))
				->add('description', 'textarea', array('required' => false))
				->add('save', 'submit');
	}
	
	public function getName()
	{
		return 'CompanyType'; //must be unique.
	}
	
	//Symfony can guess the type but it is a good practice to always set de data_class because embedding forms is necessary.
	public function setDefaultOptions(OptionsResolverInterface $resolver)
	{
		$resolver->setDefaults(array(
				'data_class' => 'cjrp\WebsiteBundle\Entity\Company',
				'cascade_validation' => false, //needed to validate embeed forms.
				'validation_groups' => array('company_creation'), //use of validation groups.
				'csrf_protection' => true,
				'csrf_field_name' => '_addCompanytoken', // a unique key to help generate the secret token
				'intention' => 'addCompany_item',
		));
	}
}