<?php

namespace cjrp\AdminBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;

use cjrp\WebsiteBundle\Entity\HotelRating;
use cjrp\AdminBundle\Form\Type\HotelRatingType;

class HotelRatingController extends Controller
{
	public function listAction() {

		$em = $this->getDoctrine()->getRepository('cjrpWebsiteBundle:HotelRating');
		$ratings = $em->findAll();
		
		return $this->render('cjrpAdminBundle:HotelRating:list.html.twig', array('ratings' => $ratings));
	}
	
    public function updateAction(Request $request, $id)
    {	
    	$logger = $this->get('logger');
    	
    	$em = $this->getDoctrine()->getManager();
    	$hr = new HotelRating();
    	
    	//$id = $request->get('id');
		if ($id != null || $id > 0) {
			$hr = $em->getRepository('cjrpWebsiteBundle:HotelRating')->find($id);
		} 	
    			 		
    	$hrForm = $this->createForm(new HotelRatingType($this->getDoctrine()), $hr);
    	$hrForm->handleRequest($request);
    	
    	if ($hrForm->isValid()) {
    		
   			$em = $this->getDoctrine()->getManager();
   			if ($hr->getId() == null || $hr->getId() <= 0) {
   				$em->persist($hr);
   			}
   			$em->flush();
   			
    		return $this->render('cjrpAdminBundle:HotelRating:display.html.twig', array('hr' => $hr) );
    	}
    	
        return $this->render('cjrpAdminBundle:HotelRating:update.html.twig', 
        	array('hrForm' => $hrForm->createView())
        );
    }
    
    public function displayAction($id)
    {
    	$em = $this->getDoctrine()->getRepository('cjrpWebsiteBundle:HotelRating');
    	// $em->getRepository('AcmeStoreBundle:Product')->find($id);
    	$hotelRating = $em->find($id);
    	return $this->render('cjrpAdminBundle:HotelRating:display.html.twig', array('hr' => $hotelRating) );
    }    
    
    public function deleteAction($id)
    {
    	$repo = $this->getDoctrine()->getRepository('cjrpWebsiteBundle:HotelRating');
    	// $em->getRepository('AcmeStoreBundle:Product')->find($id);
    	$hotelRating = $repo->find($id);
    	if ($hotelRating != null) {
    		$em = $this->getDoctrine()->getManager();
    		$em->remove($hotelRating);
    		$em->flush();
    	}
    	return $this->redirect($this->generateUrl('admin_list_hotelRating'));
    }    
}
