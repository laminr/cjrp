<?php

namespace cjrp\AdminBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;

use cjrp\WebsiteBundle\Entity\News;
use cjrp\AdminBundle\Form\Type\NewsType;

class NewsController extends Controller
{
	public function listAction() {

		$em = $this->getDoctrine()->getRepository('cjrpWebsiteBundle:News');
		$news = $em->findAll();
		
		return $this->render('cjrpAdminBundle:News:list.html.twig', array('news' => $news));
	}
	
    public function updateAction(Request $request, $id)
    {	   	
    	$em = $this->getDoctrine()->getManager();
    	$news = new News();
    	
		if ($id != null || $id > 0) {
			$news = $em->getRepository('cjrpWebsiteBundle:News')->find($id);
		} 	
    			 		
    	$newsForm = $this->createForm(new NewsType(), $news);
    	$newsForm->handleRequest($request);
    	
    	if ($id == null || $id == 0) {
    		$newsForm->get("when")->setData(new \DateTime());
    	}
    	
    	if ($newsForm->isValid()) {
    		
   			$em = $this->getDoctrine()->getManager();
   			if ($news->getId() == null || $news->getId() <= 0) {
   				$em->persist($news);
   			}
   			$em->flush();
   			
    		return $this->render('cjrpAdminBundle:News:display.html.twig', array('news' => $news) );
    	}
    	
        return $this->render('cjrpAdminBundle:News:update.html.twig', 
        	array('newsForm' => $newsForm->createView())
        );
    }
    
    public function displayAction($id)
    {
    	$news = $this->getDoctrine()->getRepository('cjrpWebsiteBundle:News')->find($id);
    	return $this->render('cjrpAdminBundle:News:display.html.twig', array('news' => $news) );
    }    
    
    public function deleteAction($id)
    {
    	$news = $this->getDoctrine()->getRepository('cjrpWebsiteBundle:News')->find($id);
    	if ($news != null) {
    		$em = $this->getDoctrine()->getManager();
    		try {
    			$em->remove($news);
    			$em->flush();
    		} catch (Exception $e) {
    			$logger = $this->get('logger');
    			$logger->info('FAIL: '.$e->getMessage());
    		}
    	}
    	return $this->redirect($this->generateUrl('admin_list_news'));
    }    
}
