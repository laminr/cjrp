<?php

namespace cjrp\AdminBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;

use cjrp\WebsiteBundle\Entity\Room;
use cjrp\AdminBundle\Form\Type\RoomType;

class RoomController extends Controller
{
	public function listAction() {

		$em = $this->getDoctrine()->getRepository('cjrpWebsiteBundle:Room');
		$rooms = $em->findAll();
		
		return $this->render('cjrpAdminBundle:Room:list.html.twig', array('rooms' => $rooms));
	}
	
    public function updateAction(Request $request, $id)
    {	   	
    	$em = $this->getDoctrine()->getManager();
    	$room = new Room();
    	
		if ($id != null || $id > 0) {
			$room = $em->getRepository('cjrpWebsiteBundle:Room')->find($id);
		} 	
    			 		
    	$roomForm = $this->createForm(new RoomType($this->getDoctrine()), $room);
    	$roomForm->handleRequest($request);
    	
    	if ($roomForm->isValid()) {
    		
   			$em = $this->getDoctrine()->getManager();
   			if ($room->getId() == null || $room->getId() <= 0) {
   				$em->persist($room);
   			}
   			$em->flush();
   			
    		return $this->render('cjrpAdminBundle:Room:display.html.twig', array('room' => $room) );
    	}
    	
        return $this->render('cjrpAdminBundle:Room:update.html.twig', 
        	array('roomForm' => $roomForm->createView())
        );
    }
    
    public function displayAction($id)
    {
    	$room = $this->getDoctrine()->getRepository('cjrpWebsiteBundle:Room')->find($id);
    	return $this->render('cjrpAdminBundle:Room:display.html.twig', array('room' => $room) );
    }    
    
    public function deleteAction($id)
    {
    	$room = $this->getDoctrine()->getRepository('cjrpWebsiteBundle:Room')->find($id);
    	if ($room != null) {
    		$em = $this->getDoctrine()->getManager();
    		try {
    			$em->remove($room);
    			$em->flush();
    		} catch (Exception $e) {
    			$logger = $this->get('logger');
    			$logger->info('FAIL: '.$e->getMessage());
    		}
    	}
    	return $this->redirect($this->generateUrl('admin_list_room'));
    }    
}
