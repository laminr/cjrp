<?php

namespace cjrp\AdminBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;

use cjrp\WebsiteBundle\Entity\Car;
use cjrp\AdminBundle\Form\Type\CarType;

class CarController extends Controller
{
	public function listAction() {

		$em = $this->getDoctrine()->getRepository('cjrpWebsiteBundle:Car');
		$cars = $em->findAll(array('make.value' => 'ASC'));
		
		return $this->render('cjrpAdminBundle:Car:list.html.twig', array('cars' => $cars));
	}
	
    public function updateAction(Request $request, $id)
    {	   	
    	$doctrine = $this->getDoctrine();
    	$car = new Car();
    	
		if ($id != null || $id > 0) {
			$car = $doctrine->getManager()->getRepository('cjrpWebsiteBundle:Car')->find($id);
		} 	
    			 		
    	$carForm = $this->createForm(new CarType($doctrine), $car);
    	$carForm->handleRequest($request);
    	
    	if ($carForm->isValid()) {
    		
   			$em = $doctrine->getManager();
   			if ($car->getId() == null || $car->getId() <= 0) {
   				$em->persist($car);
   			}
   			$em->flush();
   			
    		return $this->render('cjrpAdminBundle:Car:display.html.twig', array('car' => $car) );
    	}
    	
        return $this->render('cjrpAdminBundle:Car:update.html.twig', 
        	array('carForm' => $carForm->createView())
        );
    }
    
    public function displayAction($id)
    {
    	$car = $this->getDoctrine()->getRepository('cjrpWebsiteBundle:Car')->find($id);
    	return $this->render('cjrpAdminBundle:Car:display.html.twig', array('car' => $car));
    }    
    
    public function deleteAction($id)
    {
    	$car = $this->getDoctrine()->getRepository('cjrpWebsiteBundle:Car')->find($id);
    	if ($car != null) {
    		$em = $this->getDoctrine()->getManager();
    		try {
    			$em->remove($car);
    			$em->flush();
    		} catch (Exception $e) {
    			$logger = $this->get('logger');
    			$logger->info('FAIL: '.$e->getMessage());
    		}
    	}
    	return $this->redirect($this->generateUrl('admin_list_car'));
    }    
}
