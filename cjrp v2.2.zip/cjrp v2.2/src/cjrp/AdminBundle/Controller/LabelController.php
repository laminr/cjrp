<?php

namespace cjrp\AdminBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;

use cjrp\WebsiteBundle\Entity\Label;
use cjrp\AdminBundle\Form\Type\LabelType;

class LabelController extends Controller
{
	public function listAction(Request $request) 
	{
		$em = $this->getDoctrine()->getManager();
		$query = $em->createQuery('SELECT l FROM cjrpWebsiteBundle:Label l ORDER BY l.type ASC, l.value ASC');
		$labels = $query->getResult();
		
		return $this->render('cjrpAdminBundle:Label:list.html.twig', array('labels' => $labels));
	}
	
	public function updateAction(Request $request, $id)
    {	    	
    	$em = $this->getDoctrine()->getManager();
    	$repo = $em->getRepository('cjrpWebsiteBundle:Label');
		   	
    	$label = new Label();
		if ($id != null || $id > 0) {
			$label = $em->getRepository('cjrpWebsiteBundle:Label')->find($id);
		} 	
    			 		
    	$labelForm = $this->createForm(new LabelType($this->getDoctrine()), $label);
    	$labelForm->handleRequest($request);
    	
    	if ($labelForm->isValid()) {
    		
   			$em = $this->getDoctrine()->getManager();
   			if ($label->getId() == null || $label->getId() <= 0) {
   				$em->persist($label);
   			}
   			$em->flush();
   			// if AJAX
   			if ($request->isXMLHttpRequest()) {
   				$labels = $em
   					->getRepository('cjrpWebsiteBundle:Label')
   					->findAll(array('type' => $label->getType()), array('value' => 'ASC'));
   					
   				return new JsonResponse(array('data' => json_encode($labels)));
   			}
    		return $this->render('cjrpAdminBundle:Label:display.html.twig', array('label' => $label) );
    	}
    	
        return $this->render('cjrpAdminBundle:Label:update.html.twig', 
        	array('labelForm' => $labelForm->createView()));
    }   

    public function displayAction($id)
    {
    	$em = $this->getDoctrine()->getRepository('cjrpWebsiteBundle:Label');
    	// $em->getRepository('AcmeStoreBundle:Product')->find($id);
    	$label = $em->find($id);
    	return $this->render('cjrpAdminBundle:Label:display.html.twig', array('label' => $label) );
    }
    
    public function deleteAction($id)
    {
    	$repo = $this->getDoctrine()->getRepository('cjrpWebsiteBundle:Label');
    	$label = $repo->find($id);
    	if ($label != null) {
    		$em = $this->getDoctrine()->getManager();
    		$em->remove($label);
    		$em->flush();
    	}
    	return $this->redirect($this->generateUrl('admin_list_label'));
    }    
}
