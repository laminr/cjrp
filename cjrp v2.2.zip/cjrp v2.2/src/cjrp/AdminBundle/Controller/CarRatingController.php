<?php

namespace cjrp\AdminBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;

use cjrp\WebsiteBundle\Entity\CarRating;
use cjrp\AdminBundle\Form\Type\CarRatingType;
use cjrp\WebsiteBundle\Entity\Label;

class CarRatingController extends Controller
{
	public function listAction() {

		$em = $this->getDoctrine()->getRepository('cjrpWebsiteBundle:CarRating');
		$ratings = $em->findAll(array('company.name' => 'ASC'));
		
		return $this->render('cjrpAdminBundle:CarRating:list.html.twig', array('ratings' => $ratings));
	}
	
    public function updateAction(Request $request, $id)
    {	
    	$logger = $this->get('logger');
    	$em = $this->getDoctrine()->getManager();
    	$cr = new CarRating();
    	
    	//$id = $request->get('id');
		if ($id != null || $id > 0) {
			//echo 'get an ID ??';
			$cr = $em->getRepository('cjrpWebsiteBundle:CarRating')->find($id);
		} 	
    			
    	$crForm = $this->createForm(new CarRatingType($this->getDoctrine()), $cr);
    	$crForm->handleRequest($request);
    	
    	if ($crForm->isValid()) {
    		
   			$em = $this->getDoctrine()->getManager();
   			if ($cr->getId() == null || $cr->getId() <= 0) {
   				$em->persist($cr);
   			}
   			$em->flush();
   			
    		return $this->render('cjrpAdminBundle:CarRating:display.html.twig', array('cr' => $cr) );
    	}
    	
        return $this->render('cjrpAdminBundle:CarRating:update.html.twig', 
        	array('crForm' => $crForm->createView())
        );
    }
    
    public function displayAction($id)
    {
    	$em = $this->getDoctrine()->getRepository('cjrpWebsiteBundle:CarRating');
    	// $em->getRepository('AcmeStoreBundle:Product')->find($id);
    	$carRating = $em->find($id);
    	return $this->render('cjrpAdminBundle:CarRating:display.html.twig', array('cr' => $carRating) );
    }    
    
    public function deleteAction($id)
    {
    	$repo = $this->getDoctrine()->getRepository('cjrpWebsiteBundle:CarRating');
    	$carRating = $repo->find($id);
    	if ($carRating != null) {
    		$em = $this->getDoctrine()->getManager();
    		$em->remove($carRating);
    		$em->flush();
    	}
    	return $this->redirect($this->generateUrl('admin_list_carRating'));
    }    
}
