<?php

namespace cjrp\AdminBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;

use cjrp\WebsiteBundle\Entity\Label;
use cjrp\WebsiteBundle\Entity\Company;
use cjrp\AdminBundle\Form\Type\CompanyType;

class CompanyController extends Controller
{
	public function listAction() {

		$em = $this->getDoctrine()->getRepository('cjrpWebsiteBundle:Company');
		$companies = $em->findAll();
		
		return $this->render('cjrpAdminBundle:Company:list.html.twig', array('companies' => $companies));
	}
	
    public function updateAction(Request $request, $id)
    {	
    	$logger = $this->get('logger');
    	
    	$em = $this->getDoctrine()->getManager();
    	$repo = $em->getRepository('cjrpWebsiteBundle:Label');
    	
    	$company = new Company();
    	
		if ($id != null || $id > 0) {
			$company = $em->getRepository('cjrpWebsiteBundle:Company')->find($id);
		} 	
    			 		
    	$companyForm = $this->createForm(new CompanyType($this->getDoctrine()), $company);
   	 
    	$companyForm->handleRequest($request);
    	
    	if ($companyForm->isValid()) {
    		
   			$em = $this->getDoctrine()->getManager();
   			if ($company->getId() == null || $company->getId() <= 0) {
   				$em->persist($company);
   			}
   			$em->flush();
   			
    		return $this->render('cjrpAdminBundle:Company:display.html.twig', array('company' => $company) );
    	}
    	
        return $this->render('cjrpAdminBundle:Company:update.html.twig', 
        	array('companyForm' => $companyForm->createView()));
    }
    
    public function displayAction($id)
    {
    	$em = $this->getDoctrine()->getRepository('cjrpWebsiteBundle:Company');
    	// $em->getRepository('AcmeStoreBundle:Product')->find($id);
    	$company = $em->find($id);
    	return $this->render('cjrpAdminBundle:Company:display.html.twig', array('company' => $company) );
    }    
    
    public function deleteAction($id)
    {
    	$repo = $this->getDoctrine()->getRepository('cjrpWebsiteBundle:Company');
    	// $em->getRepository('AcmeStoreBundle:Product')->find($id);
    	$company = $repo->find($id);
    	if ($company != null) {
    		$em = $this->getDoctrine()->getManager();
    		$em->remove($company);
    		$em->flush();
    	}
    	return $this->redirect($this->generateUrl('admin_list_company'));
    }    
}
