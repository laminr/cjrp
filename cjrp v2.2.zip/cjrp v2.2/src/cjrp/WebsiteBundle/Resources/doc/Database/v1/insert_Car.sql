INSERT INTO carbooking (company, island, seats, type, make, model,  perDay, perWeek, chargePerDay, ratioChargePerWeek) 
VALUES 
('Gumbsie Car Rental', 'Anguilla', '7', 'Jeep', 'Suzuki', 'Grand Vitara XL7', 75, 450, 10, 1),
('Gumbsie Car Rental', 'Anguilla', '4/5', 'Jeep', 'Suzuki', 'Vitara', 60, 360, 10, 1),
('Gumbsie Car Rental', 'Anguilla', '4/5', 'Jeep', 'Ford' , 'Escape', 60, 360, 10, 1),
('Gumbsie Car Rental', 'Anguilla', '4/5', 'Jeep', 'Diahatsu', '', 60, 360, 10, 1),
('Gumbsie Car Rental', 'Anguilla', '4/5', 'Jeep', 'Mitsubishi', '', 60, 360, 10, 1),
('Gumbsie Car Rental', 'Anguilla', '4/5', 'Jeep', 'Hyundai' , 'Tuscon', 60, 360, 10, 1),
('Gumbsie Car Rental', 'Anguilla', '4/5', 'Jeep', 'Toyota', '', 60, 360, 10, 1),
('Gumbsie Car Rental', 'Anguilla', '5', 'Cars', 'Toyota', '', 50, 300, 10, 1),
('Gumbsie Car Rental', 'Anguilla', '5', 'Cars', 'Mazda', '', 50, 300, 10, 1),
('Gumbsie Car Rental', 'Anguilla', '5', 'Cars', 'Mitsubishi', '', 50, 300, 10, 1),
('Gumbsie Car Rental', 'Anguilla', '5', 'Cars', 'Suzuki', '', 50, 300, 10, 1),
('Gumbsie Car Rental', 'Anguilla', '8/10', 'MiniVans', 'Any', '', 95, 540, 10, 1),
('Gumbsie Car Rental', 'Anguilla', '12', 'MiniVans', 'Any', '', 100, 600, 10, 1),
('Gumbsie Car Rental', 'Anguilla', '5', 'Jeep', 'Jeep', 'Wrangler', 75, 450, 10, 1),
('Gumbsie Car Rental', 'Anguilla', '6', 'Jeep', 'Jeep', 'Wrangler', 85, 510, 10, 1),
('Gumbsie Car Rental', 'Anguilla', '7', 'Jeep', 'Crystler' , 'Aspen', 95, 590, 10, 1),
('Gumbsie Car Rental', 'Anguilla', '7', 'SUV', 'Nissan', 'Quest', 100, 600, 10, 1);
