INSERT INTO company (name, island_label_id, city_label_id, type_label_id, rating,  description )
VALUES 
('The Pool House', 5, 24, 26, 3,''),
('La Vue', 5, 26, 26, 3,''),
('Cap Juluca', 5, 27, 26, 3,''),
('Frangipani Beach Hotel', 5, 27, 26, 3,''),
('Paradise Cove', 5, 28, 26, 3,''),
('Cuisinart Resort & Spa', 5, 29, 26, 3,'');