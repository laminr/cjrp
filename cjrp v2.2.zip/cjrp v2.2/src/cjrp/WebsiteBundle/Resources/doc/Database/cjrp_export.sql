-- phpMyAdmin SQL Dump
-- version 3.4.10.1deb1
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le : Jeu 21 Novembre 2013 à 18:56
-- Version du serveur: 5.5.22
-- Version de PHP: 5.5.6-1+debphp.org~precise+2
SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

CREATE SCHEMA IF NOT EXISTS `cjrp` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci ;
USE `cjrp` ;
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `cjrp`
--

-- --------------------------------------------------------

--
-- Structure de la table `car`
--

CREATE TABLE IF NOT EXISTS `car` (
  `car_id` int(11) NOT NULL AUTO_INCREMENT,
  `make_label_id` int(11) NOT NULL,
  `model` varchar(45) DEFAULT NULL,
  `type_label_id` int(11) NOT NULL,
  `capacity` int(11) DEFAULT NULL,
  PRIMARY KEY (`car_id`),
  UNIQUE KEY `car_id_UNIQUE` (`car_id`),
  KEY `fk_car_label1_idx` (`make_label_id`),
  KEY `fk_car_label2_idx` (`type_label_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT=' ' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `carRating`
--

CREATE TABLE IF NOT EXISTS `carrating` (
  `carRating_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `car_id` int(11) NOT NULL,
  `perDay` double(6,2) NOT NULL,
  `perWeekRatio` double(5,4) NOT NULL,
  `fee` double(6,2) NOT NULL,
  PRIMARY KEY (`carRating_id`),
  UNIQUE KEY `rating_id_UNIQUE` (`carRating_id`),
  KEY `fk_rating_company1_idx` (`company_id`),
  KEY `fk_rating_car1_idx` (`car_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `company`
--

CREATE TABLE IF NOT EXISTS `company` (
  `company_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `island_label_id` int(11) NOT NULL,
  `city_label_id` int(11) NOT NULL,
  `type_label_id` int(11) NOT NULL COMMENT 'hotel or car',
  `rating` double(2,1) DEFAULT NULL,
  `description` longtext,
  PRIMARY KEY (`company_id`),
  UNIQUE KEY `company_id_UNIQUE` (`company_id`),
  KEY `fk_company_label_idx` (`island_label_id`),
  KEY `fk_company_label1_idx` (`city_label_id`),
  KEY `fk_company_label2_idx` (`type_label_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Contenu de la table `company`
--

INSERT INTO `company` (`company_id`, `name`, `island_label_id`, `city_label_id`, `type_label_id`, `rating`, `description`) VALUES
(1, 'The Pool House', 1, 20, 26, 3.0, 'general description of the famous hotel'),
(2, 'La Vue', 1, 22, 26, 3.0, 'general description of the famous hotel'),
(3, 'Cap Juluca', 1, 23, 26, 3.0, 'general description of the famous hotel'),
(4, 'Frangipani Beach Hotel', 1, 23, 26, 3.0, 'general description of the famous hotel'),
(5, 'Paradise Cove', 1, 24, 26, 3.0, 'general description of the famous hotel'),
(6, 'Cuisinart Resort & spa', 1, 25, 26, 3.0, 'general description of the famous hotel');

-- --------------------------------------------------------

--
-- Structure de la table `hotelRating`
--

CREATE TABLE IF NOT EXISTS `hotelrating` (
  `hotelRating_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `perDay` double(8,2) NOT NULL,
  `taxe` double(5,4) NOT NULL,
  `government` double(8,2) NOT NULL,
  `fee` double(6,2) NOT NULL,
  `room_id` int(11) NOT NULL,
  PRIMARY KEY (`hotelRating_id`),
  UNIQUE KEY `rating_id_UNIQUE` (`hotelRating_id`),
  KEY `fk_rating_company1_idx` (`company_id`),
  KEY `fk_hotelRating_room1_idx` (`room_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=24 ;

--
-- Contenu de la table `hotelRating`
--

INSERT INTO `hotelrating` (`hotelRating_id`, `company_id`, `perDay`, `taxe`, `government`, `fee`, `room_id`) VALUES
(1, 1, 119.20, 0.1997, 2.00, 10.00, 19),
(2, 2, 200.00, 0.0000, 0.00, 10.00, 1),
(3, 2, 322.00, 0.0000, 1.00, 10.00, 2),
(4, 3, 595.00, 0.1000, 1.00, 10.00, 3),
(5, 3, 1810.00, 0.1000, 1.00, 10.00, 4),
(6, 3, 995.00, 0.1000, 1.00, 10.00, 5),
(7, 3, 1300.00, 0.1000, 1.00, 10.00, 6),
(8, 3, 1410.00, 0.1000, 1.00, 10.00, 7),
(9, 3, 3810.00, 0.1000, 1.00, 10.00, 8),
(10, 3, 4910.00, 0.1000, 1.00, 10.00, 9),
(11, 3, 5862.00, 0.1000, 1.00, 10.00, 10),
(12, 3, 7010.00, 0.1000, 1.00, 10.00, 11),
(13, 3, 8010.00, 0.1000, 1.00, 10.00, 12),
(14, 4, 1328.00, 0.1000, 1.00, 10.00, 13),
(15, 4, 1688.00, 0.1000, 1.00, 10.00, 14),
(16, 4, 1849.00, 0.1000, 1.00, 10.00, 15),
(17, 4, 2500.00, 0.1000, 1.00, 10.00, 16),
(18, 5, 340.00, 0.1000, 1.00, 10.00, 17),
(19, 5, 400.00, 0.1000, 1.00, 10.00, 18),
(20, 5, 375.00, 0.1000, 1.00, 10.00, 1),
(21, 5, 530.00, 0.1000, 1.00, 10.00, 2),
(22, 5, 650.00, 0.1000, 1.00, 10.00, 18),
(23, 6, 5088.00, 0.1000, 1.00, 50.88, 13);

-- --------------------------------------------------------

--
-- Structure de la table `label`
--

CREATE TABLE IF NOT EXISTS `label` (
  `label_id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(45) DEFAULT NULL COMMENT 'island, city, company_hotel, company_car, car_make, car_type, rating_delay',
  `value` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`label_id`),
  UNIQUE KEY `label_id_UNIQUE` (`label_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=29 ;

--
-- Contenu de la table `label`
--

INSERT INTO `label` (`label_id`, `type`, `value`) VALUES
(1, 'ISLAND', 'Anguilla'),
(2, 'ISLAND', 'Antigua '),
(3, 'ISLAND', 'Barbuda'),
(4, 'ISLAND', 'Barbados'),
(5, 'ISLAND', 'Dominica'),
(6, 'ISLAND', 'Dominican Republic'),
(7, 'ISLAND', 'Grenada'),
(8, 'ISLAND', 'Guadeloupe'),
(9, 'ISLAND', 'Jamaica'),
(10, 'ISLAND', 'Martinique'),
(11, 'ISLAND', 'Puerto Rico'),
(12, 'ISLAND', 'Saint Kitts '),
(13, 'ISLAND', 'Nevis'),
(14, 'ISLAND', 'Saint Lucia'),
(15, 'ISLAND', 'Saint Martin'),
(16, 'ISLAND', 'Trinidad'),
(17, 'ISLAND', 'Tobago'),
(18, 'ISLAND', 'US Virgin Islands'),
(19, 'ISLAND', 'Trinidad (POS)'),
(20, 'CITY', ''),
(21, 'CITY', 'The Valley'),
(22, 'CITY', 'South Hill'),
(23, 'CITY', 'Meads Bay'),
(24, 'CITY', 'The Cove'),
(25, 'CITY', 'Rendezvous'),
(26, 'COMP_TYPE', 'HOTEL'),
(27, 'COMP_TYPE', 'VILLA'),
(28, 'COMP_TYPE', 'CAR_RENTAL');

-- --------------------------------------------------------

--
-- Structure de la table `room`
--

CREATE TABLE IF NOT EXISTS `room` (
  `room_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(45) NOT NULL,
  `capacity` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`room_id`),
  UNIQUE KEY `room_id_UNIQUE` (`room_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=20 ;

--
-- Contenu de la table `room`
--

INSERT INTO `room` (`room_id`, `description`, `capacity`) VALUES
(1, 'One Bedroom Suite', 2),
(2, 'Two Bedroom Suite', 2),
(3, 'Standard', 2),
(4, 'Ocean front junior', 2),
(5, 'Ocean front Superior', 2),
(6, 'Ocean front premier', 2),
(7, 'Ocean front Luxury', 2),
(8, 'Oeean one bedroom', 2),
(9, 'Ocean front two bedroom', 2),
(10, 'Ocean front three bedroom', 2),
(11, 'Ocean front four bedroom', 2),
(12, 'Ocean front five bedroom', 2),
(13, 'Luxury room', 2),
(14, 'Ocean luxury', 2),
(15, 'Queens junior suite o/f', 2),
(16, 'Studio suite', 2),
(17, 'Garden view', 2),
(18, 'Penthouse', 2),
(19, '4 Bedrooms', 8);

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `car`
--
ALTER TABLE `car`
  ADD CONSTRAINT `fk_car_label1` FOREIGN KEY (`make_label_id`) REFERENCES `label` (`label_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_car_label2` FOREIGN KEY (`type_label_id`) REFERENCES `label` (`label_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `carRating`
--
ALTER TABLE `carrating`
  ADD CONSTRAINT `fk_rating_company1` FOREIGN KEY (`company_id`) REFERENCES `company` (`company_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_rating_car1` FOREIGN KEY (`car_id`) REFERENCES `car` (`car_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `company`
--
ALTER TABLE `company`
  ADD CONSTRAINT `fk_company_label` FOREIGN KEY (`island_label_id`) REFERENCES `label` (`label_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_company_label1` FOREIGN KEY (`city_label_id`) REFERENCES `label` (`label_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_company_label2` FOREIGN KEY (`type_label_id`) REFERENCES `label` (`label_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `hotelRating`
--
ALTER TABLE `hotelrating`
  ADD CONSTRAINT `fk_hotelRating_room1` FOREIGN KEY (`room_id`) REFERENCES `room` (`room_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_rating_company10` FOREIGN KEY (`company_id`) REFERENCES `company` (`company_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
