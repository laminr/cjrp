INSERT INTO hotelbooking (name, island, city, type, perDay, taxe, govLevy, chargePerDay)
VALUES
('The Pool House', 'Anguilla', '', 'King Room', 119, 0, 2, 119.20, 10),
('La Vue', 'Anguilla', '', 'King Room', 200, 0, 2, 200, 10),
('La Vue', 'Anguilla', '', 'King Room', 322, 0, 2, 322, 10);
