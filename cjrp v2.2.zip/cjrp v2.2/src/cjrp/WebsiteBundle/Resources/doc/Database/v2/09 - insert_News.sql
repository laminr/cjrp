INSERT INTO `news` (`news_id`, `iswhen`, `title`, `content`) VALUES
(1, '2013-10-10 12:00:00', 'Releasing a new Website', 'CJRP Travel is thrilled to announce the launch a new website'),
(2, '2013-11-23 12:00:00', 'Online hotel booking reservation', 'CJRP Travel has released a new functionality to its website. Now, you can search hotel promotions directly online and make your reservation at great CJRP rates!');
