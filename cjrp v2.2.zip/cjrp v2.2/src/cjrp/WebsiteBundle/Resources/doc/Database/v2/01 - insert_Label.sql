insert into label (type, value) values ('ROOM_TYPE', 'HOTEL');
insert into label (type, value) values ('ROOM_TYPE', 'VILLA');
insert into label (type, value) values ('COMP_TYPE', 'VEHICULE');
insert into label (type, value) values ('COMP_TYPE', 'HOUSING');

insert into label (type, value) values 
('ISLAND', 'Anguilla'),
('ISLAND', 'Antigua '),
('ISLAND', 'Barbuda'),
('ISLAND', 'Barbados'),
('ISLAND', 'Dominica'),
('ISLAND', 'Dominican Republic'),
('ISLAND', 'Grenada'),
('ISLAND', 'Guadeloupe'),
('ISLAND', 'Jamaica'),
('ISLAND', 'Martinique'),
('ISLAND', 'Puerto Rico'),
('ISLAND', 'Saint Kitts '),
('ISLAND', 'Nevis'),
('ISLAND', 'Saint Lucia'),
('ISLAND', 'Saint Martin'),
('ISLAND', 'Trinidad'),
('ISLAND', 'Tobago'),
('ISLAND', 'US Virgin Islands'),
('ISLAND', 'Trinidad (POS)');

insert into label (type, value) values 
('CITY', ''),
('CITY', 'The Valley'),
('CITY', 'South Hill'),
('CITY', 'Meads Bay'),
('CITY', 'The Cove'),
('CITY', 'Rendezvous'),
('CITY', 'George Hill'),
('CITY', 'The Cove'),
('CITY', 'WRST End'),
('CITY', 'Little Harbour'),
('CITY', 'The Valley'),
('CITY', 'Cul de Sac'),
('CITY', 'Bolwing Point'),
('CITY', 'East End'),
('CITY', 'Basseterre'),
('CITY', 'Conrad Sunset'),
('CITY', 'Blue Bay'),
('CITY', 'Gozumel'),
('CITY', 'Park Royal'),
('CITY', 'Secrets Cerpin'),
('CITY', 'Valentine'),
('CITY', 'St. James'),
('CITY', 'Hastings'),
('CITY', 'St. Lawrence'),
('CITY', 'St. Phillip'),
('CITY', 'Christ Church'),
('CITY', 'St. Johns'),
('CITY', 'Colebay');

insert into label (type, value) values 
('CITY', 'Anse des Cayes Gustavia'),
('CITY', 'Blowing point'),
('CITY', 'Brewer\'s Bay'),
('CITY', 'Castle Bruse'),
('CITY', 'Castle Comfort'),
('CITY', 'Charlotte Amalie'),
('CITY', 'Frenchman Cay'),
('CITY', 'Frigate Bay'),
('CITY', 'Meads Bay'),
('CITY', 'North Sound'),
('CITY', 'Oualie Bay'),
('CITY', 'Pinneys Beach'),
('CITY', 'South of Roseau'),
('CITY', 'Spring Bay'),
('CITY', 'St. James Parish'),
('CITY', 'The Valley Plum Bay Road'),
('CITY', 'West End');

insert into label (type, value) values
('CAR_TYPE', 'Jeep'),
('CAR_TYPE', 'Car'),
('CAR_TYPE', 'Mini Van'),
('CAR_TYPE', 'SUV'),
('CAR_TYPE', 'Convertibles'),
('CAR_TYPE', 'Green Car'),
('CAR_TYPE', 'Pick Up'),
('CAR_TYPE', 'Station Wagon'),
('CAR_TYPE', 'Compact'),
('CAR_TYPE', 'Economy'),
('CAR_TYPE', 'Full Size'),
('CAR_TYPE', 'Intermediate'),
('CAR_TYPE', 'Luxury'),
('CAR_TYPE', 'Premium'),
('CAR_TYPE', 'Standard');

insert into label (type, value) values
('CAR_MAKE', 'Suzuki'),
('CAR_MAKE', 'Ford'),
('CAR_MAKE', 'Diahatsu'),
('CAR_MAKE', 'Mitsubishi'),
('CAR_MAKE', 'Hyundai'),
('CAR_MAKE', 'Toyota'),
('CAR_MAKE', 'Mazda'),
('CAR_MAKE', 'Wrangler'),
('CAR_MAKE', 'Crystler'),
('CAR_MAKE', 'Nissan');

