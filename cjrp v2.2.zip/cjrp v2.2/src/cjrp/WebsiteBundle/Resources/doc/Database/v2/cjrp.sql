SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

CREATE SCHEMA IF NOT EXISTS `cjrp` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci ;
USE `cjrp` ;

-- -----------------------------------------------------
-- Table `cjrp`.`label`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `cjrp`.`label` (
  `label_id` INT NOT NULL AUTO_INCREMENT,
  `type` VARCHAR(45) NULL,
  `value` VARCHAR(45) NULL,
  PRIMARY KEY (`label_id`),
  UNIQUE INDEX `label_id_UNIQUE` (`label_id` ASC))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `cjrp`.`company`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `cjrp`.`company` (
  `company_id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) NULL,
  `island_label_id` INT NOT NULL,
  `city_label_id` INT NOT NULL,
  `type_label_id` INT NOT NULL COMMENT 'hotel or car',
  `rating` DOUBLE(2,1) NULL,
  `description` LONGTEXT NULL,
  PRIMARY KEY (`company_id`),
  INDEX `fk_company_label_idx` (`island_label_id` ASC),
  INDEX `fk_company_label1_idx` (`city_label_id` ASC),
  INDEX `fk_company_label2_idx` (`type_label_id` ASC),
  UNIQUE INDEX `company_id_UNIQUE` (`company_id` ASC),
  CONSTRAINT `fk_company_label`
    FOREIGN KEY (`island_label_id`)
    REFERENCES `cjrp`.`label` (`label_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_company_label1`
    FOREIGN KEY (`city_label_id`)
    REFERENCES `cjrp`.`label` (`label_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_company_label2`
    FOREIGN KEY (`type_label_id`)
    REFERENCES `cjrp`.`label` (`label_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `cjrp`.`car`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `cjrp`.`car` (
  `car_id` INT NOT NULL AUTO_INCREMENT,
  `make_label_id` INT NOT NULL,
  `model` VARCHAR(45) NULL,
  `type_label_id` INT NOT NULL,
  `capacity` INT NULL,
  PRIMARY KEY (`car_id`),
  INDEX `fk_car_label1_idx` (`make_label_id` ASC),
  INDEX `fk_car_label2_idx` (`type_label_id` ASC),
  UNIQUE INDEX `car_id_UNIQUE` (`car_id` ASC),
  CONSTRAINT `fk_car_label1`
    FOREIGN KEY (`make_label_id`)
    REFERENCES `cjrp`.`label` (`label_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_car_label2`
    FOREIGN KEY (`type_label_id`)
    REFERENCES `cjrp`.`label` (`label_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = ' ';


-- -----------------------------------------------------
-- Table `cjrp`.`carrating`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `cjrp`.`carrating` (
  `carRating_id` INT NOT NULL AUTO_INCREMENT,
  `company_id` INT NOT NULL,
  `car_id` INT NOT NULL,
  `perDay` DOUBLE(6,2) NOT NULL,
  `perWeek` DOUBLE(6,2) NOT NULL,
  `feeDay` DOUBLE(6,2) NOT NULL,
  `feeWeek` DOUBLE(6,2) NOT NULL,
  PRIMARY KEY (`carRating_id`),
  INDEX `fk_rating_company1_idx` (`company_id` ASC),
  UNIQUE INDEX `rating_id_UNIQUE` (`carRating_id` ASC),
  INDEX `fk_rating_car1_idx` (`car_id` ASC),
  CONSTRAINT `fk_rating_company1`
    FOREIGN KEY (`company_id`)
    REFERENCES `cjrp`.`company` (`company_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_rating_car1`
    FOREIGN KEY (`car_id`)
    REFERENCES `cjrp`.`car` (`car_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB


-- -----------------------------------------------------
-- Table `cjrp`.`room`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `cjrp`.`room` (
  `room_id` INT NOT NULL AUTO_INCREMENT,
  `description` VARCHAR(45) NOT NULL,
  `capacity` INT NOT NULL DEFAULT 1,
  `ownerType_label_id` INT NOT NULL,
  PRIMARY KEY (`room_id`),
  UNIQUE INDEX `room_id_UNIQUE` (`room_id` ASC),
  INDEX `fk_room_label1_idx` (`ownerType_label_id` ASC),
  CONSTRAINT `fk_room_label1`
    FOREIGN KEY (`ownerType_label_id`)
    REFERENCES `cjrp`.`label` (`label_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `cjrp`.`hotelrating`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `cjrp`.`hotelrating` (
  `hotelRating_id` INT NOT NULL AUTO_INCREMENT,
  `company_id` INT NOT NULL,
  `perDay` DOUBLE(8,2) NOT NULL,
  `taxe` DOUBLE(5,4) NOT NULL,
  `government` DOUBLE(8,2) NOT NULL,
  `fee` DOUBLE(6,2) NOT NULL,
  `room_id` INT NOT NULL,
  PRIMARY KEY (`hotelRating_id`),
  INDEX `fk_rating_company1_idx` (`company_id` ASC),
  UNIQUE INDEX `rating_id_UNIQUE` (`hotelRating_id` ASC),
  INDEX `fk_hotelRating_room1_idx` (`room_id` ASC),
  CONSTRAINT `fk_rating_company10`
    FOREIGN KEY (`company_id`)
    REFERENCES `cjrp`.`company` (`company_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_hotelRating_room1`
    FOREIGN KEY (`room_id`)
    REFERENCES `cjrp`.`room` (`room_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `cjrp`.`taxe`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `cjrp`.`taxe` (
  `taxe_id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) NULL,
  `value` DOUBLE(6,2) NULL,
  `isPercent` TINYINT(1) NULL,
  `carRating_id` INT NOT NULL,
  `hotelRating_id` INT NOT NULL,
  PRIMARY KEY (`taxe_id`),
  UNIQUE INDEX `taxe_id_UNIQUE` (`taxe_id` ASC),
  INDEX `fk_taxe_carRating1_idx` (`carRating_id` ASC),
  INDEX `fk_taxe_hotelRating1_idx` (`hotelRating_id` ASC),
  CONSTRAINT `fk_taxe_carRating1`
    FOREIGN KEY (`carRating_id`)
    REFERENCES `cjrp`.`carrating` (`carRating_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_taxe_hotelRating1`
    FOREIGN KEY (`hotelRating_id`)
    REFERENCES `cjrp`.`hotelrating` (`hotelRating_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `cjrp`.`news`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `cjrp`.`news` (
  `news_id` INT NOT NULL AUTO_INCREMENT,
  `iswhen` DATETIME NOT NULL,
  `title` VARCHAR(70) NOT NULL,
  `content` LONGTEXT NOT NULL,
  PRIMARY KEY (`news_id`))
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
