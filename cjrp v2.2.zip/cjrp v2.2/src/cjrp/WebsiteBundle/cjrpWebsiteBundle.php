<?php

namespace cjrp\WebsiteBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class cjrpWebsiteBundle extends Bundle
{
}
