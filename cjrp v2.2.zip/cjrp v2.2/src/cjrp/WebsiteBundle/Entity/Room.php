<?php

namespace cjrp\WebsiteBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Room
 *
 * @ORM\Table(name="room")
 * @ORM\Entity
 */
class Room
{
    /**
     * @var integer
     *
     * @ORM\Column(name="room_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var integer
     *
     * @ORM\Column(name="capacity", type="integer", nullable=false)
     */
    private $capacity;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="string", length=45, nullable=true)
     */
    private $description;

    /**
     * @var \Label
     *
     * @ORM\ManyToOne(targetEntity="Label")
     * @ORM\JoinColumn(name="ownerType_label_id", referencedColumnName="label_id")
     */
    private $ownerType;

    /**
     * Set id
     *
     * @param integer $id
     * @return Room
     */
    public function setId($id)
    {
        $this->id = $id;
    
        return $this;
    }

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set capacity
     *
     * @param integer $capacity
     * @return Room
     */
    public function setCapacity($capacity)
    {
        $this->capacity = $capacity;
    
        return $this;
    }

    /**
     * Get capacity
     *
     * @return integer 
     */
    public function getCapacity()
    {
        return $this->capacity;
    }

    /**
     * Set type
     *
     * @param string $type
     * @return Room
     */
    public function setDescription($description)
    {
        $this->description = $description;
    
        return $this;
    }

    /**
     * Get type
     *
     * @return string 
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set ownerType
     *
     * @param \cjrp\WebsiteBundle\Entity\Label $ownerType
     * @return Room
     */
    public function setOwnerType(\cjrp\WebsiteBundle\Entity\Label $ownerType)
    {
        $this->ownerType = $ownerType;
    
        return $this;
    }

    /**
     * Get island
     *
     * @return \cjrp\WebsiteBundle\Entity\Label 
     */
    public function getOwnerType()
    {
        return $this->ownerType;
    }    
}