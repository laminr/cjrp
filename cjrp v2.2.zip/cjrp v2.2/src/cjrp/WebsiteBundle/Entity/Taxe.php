<?php

namespace cjrp\WebsiteBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Taxe
 *
 * @ORM\Table(name="taxe")
 * @ORM\Entity
 */
class Taxe
{
    /**
     * @var integer
     *
     * @ORM\Column(name="taxe_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=45, nullable=true)
     */
    private $name;

    /**
     * @var float
     *
     * @ORM\Column(name="value", type="float", nullable=true)
     */
    private $value;

    /**
     * @var boolean
     *
     * @ORM\Column(name="isPercent", type="boolean", nullable=true)
     */
    private $isPercent;

    /**
     * @var \Carrating
     *
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     * @ORM\OneToOne(targetEntity="Carrating")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="carRating_id", referencedColumnName="rating_id")
     * })
     */
    private $carRating;

    /**
     * @var \Hotelrating
     *
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     * @ORM\OneToOne(targetEntity="Hotelrating")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="hotelRating_id", referencedColumnName="rating_id")
     * })
     */
    private $hotelRating;



    /**
     * Set id
     *
     * @param integer $id
     * @return Taxe
     */
    public function setId($id)
    {
        $this->id = $id;
    
        return $this;
    }

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return Taxe
     */
    public function setName($name)
    {
        $this->name = $name;
    
        return $this;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set value
     *
     * @param float $value
     * @return Taxe
     */
    public function setValue($value)
    {
        $this->value = $value;
    
        return $this;
    }

    /**
     * Get value
     *
     * @return float 
     */
    public function getValue()
    {
        return $this->value;
    }

    /**
     * Set isPercent
     *
     * @param boolean $isPercent
     * @return Taxe
     */
    public function setIsPercent($isPercent)
    {
        $this->isPercent = $isPercent;
    
        return $this;
    }

    /**
     * Get isPercent
     *
     * @return boolean 
     */
    public function getIsPercent()
    {
        return $this->isPercent;
    }

    /**
     * Set carRating
     *
     * @param \cjrp\WebsiteBundle\Entity\Carrating $carRating
     * @return Taxe
     */
    public function setCarRating(\cjrp\WebsiteBundle\Entity\Carrating $carRating)
    {
        $this->carRating = $carRating;
    
        return $this;
    }

    /**
     * Get carRating
     *
     * @return \cjrp\WebsiteBundle\Entity\Carrating 
     */
    public function getCarRating()
    {
        return $this->carRating;
    }

    /**
     * Set hotelRating
     *
     * @param \cjrp\WebsiteBundle\Entity\Hotelrating $hotelRating
     * @return Taxe
     */
    public function setHotelRating(\cjrp\WebsiteBundle\Entity\Hotelrating $hotelRating)
    {
        $this->hotelRating = $hotelRating;
    
        return $this;
    }

    /**
     * Get hotelRating
     *
     * @return \cjrp\WebsiteBundle\Entity\Hotelrating 
     */
    public function getHotelRating()
    {
        return $this->hotelRating;
    }
}