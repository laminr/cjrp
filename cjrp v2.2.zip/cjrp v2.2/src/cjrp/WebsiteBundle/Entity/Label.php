<?php

namespace cjrp\WebsiteBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Label
 *
 * @ORM\Table(name="label")
 * @ORM\Entity(repositoryClass="cjrp\WebsiteBundle\Entity\LabelRepository")
 */
class Label
{
    /**
     * @var integer
     *
     * @ORM\Column(name="label_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="type", type="string", length=45, nullable=true)
     */
    private $type;

    /**
     * @var string
     *
     * @ORM\Column(name="value", type="string", length=45, nullable=true)
     */
    private $value;

    const COMP_HOUSING = "HOUSING";
    const COMP_VEHICULE = "VEHICULE";

    const ROOM_VILLA = "VILLA";
    const ROOM_HOTEL = "HOTEL";
    
    const TYPE_CITY = "CITY";
    const TYPE_ISLAND = "ISLAND";
    const TYPE_COMP_TYPE = "COMP_TYPE";
    const TYPE_ROOM_TYPE = "ROOM_TYPE";

    const CAR_TYPE = "CAR_TYPE";
    const CAR_MAKE = "CAR_MAKE";

    public function __construct($type = '') {
        if (isset($type)) {
            $this->type = $type;
        }
    }
    /*
    public function __toString() {
    	return $this->value;
    }
    //*/

    /**
     * Set type
     *
     * @param integer $id
     * @return Label
     */
    public function setId($id)
    {
    	$this->id = $id;
    
    	return $this;
    }
    
    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set type
     *
     * @param string $type
     * @return Label
     */
    public function setType($type)
    {
        $this->type = $type;
    
        return $this;
    }

    /**
     * Get type
     *
     * @return string 
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * Set value
     *
     * @param string $value
     * @return Label
     */
    public function setValue($value)
    {
        $this->value = $value;
    
        return $this;
    }

    /**
     * Get value
     *
     * @return string 
     */
    public function getValue()
    {
        return $this->value;
    }
}