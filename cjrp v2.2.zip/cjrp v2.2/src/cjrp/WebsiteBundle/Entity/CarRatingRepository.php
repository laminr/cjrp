<?php
namespace cjrp\WebsiteBundle\Entity;

use Doctrine\ORM\EntityRepository;
use Doctrine\Common\Collections\Collection;

use cjrp\WebsiteBundle\Entity\Company;

class CarRatingRepository extends EntityRepository
{
	public function findAllRatingForAType($type, $island)
	{
		// var_dump($type);
		// var_dump($island);
		
		$isForAll = ($type == Car::TYPE_ALL);
		
		$sqlAll ='SELECT cr 
					FROM cjrpWebsiteBundle:CarRating cr 
						JOIN cr.company company 
						JOIN company.island island 
					WHERE island.value = :island
					ORDER BY company.name ASC, cr.perDay ASC';
		
		$sqlType = 'SELECT cr 
					FROM cjrpWebsiteBundle:CarRating cr 
						JOIN cr.company company 
						JOIN company.island island
						JOIN cr.car car 
						JOIN car.type type
					WHERE island.value = :island
						AND type.value = :type
					ORDER BY company.name ASC, cr.perDay ASC';
		
		$em = $this->getEntityManager();
		$query = $em->createQuery(
				$isForAll ? $sqlAll : $sqlType
		);
		$query->setParameter('island', $island);
		if (!$isForAll) {
			$query->setParameter('type', $type);
		}
		
		$ratings = $query->getResult();
		//var_dump($ratings);
		
		$companies = array();
		$company = new Company();
		
		for ($i = 0; $i < count($ratings); $i++) {
			if ($ratings[$i]->getCompany()->getName() != $company->getName()) {
				// if not first round
				if ($company->getName() != '') {
					$companies[] = $company;
					$company = new Company();
				}
				// premier tour transmets le CarRating en meme temps !!!
				$company->setId($ratings[$i]->getCompany()->getId());
				$company->setName($ratings[$i]->getCompany()->getName());
				$company->setIsland($ratings[$i]->getCompany()->getIsland());
				$company->setRating($ratings[$i]->getCompany()->getRating());
			}
			$company->addCarRating($ratings[$i]);
		}
		
		if ($company->getName() != '') {
			$companies[] = $company;
		}
		
		return $companies;
	}
}