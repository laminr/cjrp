<?php

namespace cjrp\WebsiteBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

use cjrp\WebsiteBundle\Entity\Room;
use cjrp\WebsiteBundle\Entity\Company;

/**
 * HotelRating
 *
 * @ORM\Table(name="hotelrating")
 * @ORM\Entity
 */
class HotelRating
{
    /**
     * @var integer
     *
     * @ORM\Column(name="hotelrating_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var float
     *
     * @ORM\Column(name="perDay", type="float", nullable=false)
     */
    private $perDay;

    /**
     * @var float
     *
     * @ORM\Column(name="taxe", type="float", nullable=false)
     */
    private $taxe;

    /**
     * @var float
     *
     * @ORM\Column(name="government", type="float", nullable=false)
     */
    private $government;

    /**
     * @var float
     *
     * @ORM\Column(name="fee", type="float", nullable=false)
     */
    private $fee;

    /**
     * @var \Room
     *
     * @ORM\ManyToOne(targetEntity="Room")
     * @ORM\JoinColumn(name="room_id", referencedColumnName="room_id")
     */
    private $room;

    /**
     * @var \Company
     *
     * @ORM\ManyToOne(targetEntity="Company", inversedBy="hotelRatings", cascade={"remove"})
     * @ORM\JoinColumn(name="company_id", referencedColumnName="company_id")
     *
     * @ORM\ManyToOne(targetEntity="Company")
     * @ORM\JoinColumn(name="company_id", referencedColumnName="company_id")
     */
    private $company;

    private $totalWithoutFee;
    private $taxValue;
    private $fullTaxValue;

    public function __construct() {
        $this->room = new Room();
        $this->company = new Company();
    }

    /**
     * Set id
     *
     * @param integer $id
     * @return HotelRating
     */
    public function setId($id)
    {
        $this->id = $id;
    
        return $this;
    }

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set perDay
     *
     * @param float $perDay
     * @return HotelRating
     */
    public function setPerDay($perDay)
    {
        $this->perDay = $perDay;
    
        return $this;
    }

    /**
     * Get perDay
     *
     * @return float 
     */
    public function getPerDay()
    {
        return $this->perDay;
    }

    /**
     * Set taxe
     *
     * @param float $taxe
     * @return HotelRating
     */
    public function setTaxe($taxe)
    {
        $this->taxe = $taxe;
    
        return $this;
    }

    /**
     * Get taxe
     *
     * @return float 
     */
    public function getTaxe()
    {
        return $this->taxe;
    }

    /**
     * Set government
     *
     * @param float $government
     * @return HotelRating
     */
    public function setGovernment($government)
    {
        $this->government = $government;
    
        return $this;
    }

    /**
     * Get government
     *
     * @return float 
     */
    public function getGovernment()
    {
        return $this->government;
    }

    /**
     * Set fee
     *
     * @param float $fee
     * @return HotelRating
     */
    public function setFee($fee)
    {
        $this->fee = $fee;
    
        return $this;
    }

    /**
     * Get fee
     *
     * @return float 
     */
    public function getFee()
    {
        return $this->fee;
    }

    /**
     * Set type
     *
     * @param \cjrp\WebsiteBundle\Entity\Room $type
     * @return HotelRating
     */
    public function setRoom(\cjrp\WebsiteBundle\Entity\Room $room)
    {
        $this->room = $room;
    
        return $this;
    }

    /**
     * Get type
     *
     * @return \cjrp\WebsiteBundle\Entity\Room 
     */
    public function getRoom()
    {
        return $this->room;
    }

    /**
     * Set company
     *
     * @param \cjrp\WebsiteBundle\Entity\Company $company
     * @return HotelRating
     */
    public function setCompany(\cjrp\WebsiteBundle\Entity\Company $company)
    {
        $this->company = $company;
    
        return $this;
    }

    /**
     * Get company
     *
     * @return \cjrp\WebsiteBundle\Entity\Company 
     */
    public function getCompany()
    {
        return $this->company;
    }

    public function getTotalWithoutFee() {
        $this->totalWithoutFee = $this->perDay + ($this->perDay * $this->taxe) + $this->government;
        return $this->totalWithoutFee;
    }

    public function getTaxValue() {
        $this->taxValue = ($this->perDay * $this->taxe);
        return $this->taxValue;
    }  

    public function getFullTaxValue() {
        $this->fullTaxValue = ($this->perDay * $this->taxe) + $this->government;
        return $this->fullTaxValue;
    } 

}