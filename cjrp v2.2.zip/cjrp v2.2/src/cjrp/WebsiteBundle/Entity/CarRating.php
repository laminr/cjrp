<?php

namespace cjrp\WebsiteBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

use cjrp\WebsiteBundle\Entity\Car;
use cjrp\WebsiteBundle\Entity\Company;

/**
 * Carrating
 *
 * @ORM\Table(name="carrating")
 * @ORM\Entity(repositoryClass="cjrp\WebsiteBundle\Entity\CarRatingRepository")
 */
class CarRating
{
    /**
     * @var integer
     *
     * @ORM\Column(name="carrating_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var float
     *
     * @ORM\Column(name="perDay", type="float", nullable=false)
     */
    private $perDay;
    
    /**
     * @var float
     *
     * @ORM\Column(name="perWeek", type="float", nullable=false)
     */
    private $perWeek;

    /**
     * @var float
     *
     * @ORM\Column(name="feeWeek", type="float", nullable=false)
     */
    private $feeWeek;

    /**
     * @var float
     *
     * @ORM\Column(name="feeDay", type="float", nullable=false)
     */
    private $feeDay;

    /**
     * @var \Car
     * 
     * @ORM\ManyToOne(targetEntity="Car")
     * @ORM\JoinColumn(name="car_id", referencedColumnName="car_id")
     */
    private $car;

    /**
     * @var \Company
     * @ORM\ManyToOne(targetEntity="Company", inversedBy="carRatings")
     * @ORM\JoinColumn(name="company_id", referencedColumnName="company_id")
     * 
     * @ORM\ManyToOne(targetEntity="Company")
     * @ORM\JoinColumn(name="company_id", referencedColumnName="company_id")
     * 
     */
    private $company;

    public function __construct() {
        $this->car = new Car();
        $this->company = new Company();
    }

    /**
     * Set id
     *
     * @param integer $id
     * @return CarRating
     */
    public function setId($id)
    {
        $this->id = $id;
    
        return $this;
    }


    /**
     * Get idd
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set perDay
     *
     * @param float $perDay
     * @return CarRating
     */
    public function setPerDay($perDay)
    {
        $this->perDay = $perDay;
    
        return $this;
    }

    /**
     * Get perDay
     *
     * @return float 
     */
    public function getPerDay()
    {
        return $this->perDay;
    }

    /**
     * Set perWeek
     *
     * @param float $perWeek
     * @return CarRating
     */
    public function setPerWeek($perWeek)
    {
    	$this->perWeek = $perWeek;
    
    	return $this;
    }
    
    /**
     * Get perWeek
     *
     * @return float
     */
    public function getPerWeek()
    {
    	return $this->perWeek;
    }
    
    /**
     * Set feeWeek
     *
     * @param float $perWeekRatio
     * @return CarRating
     */
    public function setFeeWeek($feeWeek)
    {
        $this->feeWeek = $feeWeek;
    
        return $this;
    }

    /**
     * Get feeWeek
     *
     * @return float 
     */
    public function getFeeWeek()
    {
        return $this->feeWeek;
    }

    /**
     * Set feeDay
     *
     * @param float $feeDay
     * @return CarRating
     */
    public function setFeeDay($feeDay)
    {
        $this->feeDay = $feeDay;
    
        return $this;
    }

    /**
     * Get fee
     *
     * @return float 
     */
    public function getFeeDay()
    {
        return $this->feeDay;
    }

    /**
     * Set car
     *
     * @param \cjrp\WebsiteBundle\Entity\Car $car
     * @return CarRating
     */
    public function setCar(\cjrp\WebsiteBundle\Entity\Car $car)
    {
        $this->car = $car;
    
        return $this;
    }

    /**
     * Get car
     *
     * @return \cjrp\WebsiteBundle\Entity\Car 
     */
    public function getCar()
    {
        return $this->car;
    }

    /**
     * Set company
     *
     * @param \cjrp\WebsiteBundle\Entity\Company $company
     * @return CarRating
     */
    public function setCompany(\cjrp\WebsiteBundle\Entity\Company $company)
    {
        $this->company = $company;
    
        return $this;
    }

    /**
     * Get company
     *
     * @return \cjrp\WebsiteBundle\Entity\Company 
     */
    public function getCompany()
    {
        return $this->company;
    }
}