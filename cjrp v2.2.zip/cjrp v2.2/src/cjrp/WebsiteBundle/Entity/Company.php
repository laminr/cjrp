<?php

namespace cjrp\WebsiteBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

use cjrp\WebsiteBundle\Entity\Label;
use Doctrine\Common\Collections\ArrayCollection;

/**
 * Company
 *
 * @ORM\Table(name="company")
 * @ORM\Entity
 */
class Company
{
    /**
     * @var integer
     *
     * @ORM\Column(name="company_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=45, nullable=true)
     */
    private $name;

    /**
     * @var float
     *
     * @ORM\Column(name="rating", type="float", nullable=true)
     */
    private $rating;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="text", nullable=true)
     */
    private $description;

    /**
     * @var \Label
     *
     * @ORM\ManyToOne(targetEntity="Label")
     * @ORM\JoinColumn(name="island_label_id", referencedColumnName="label_id")
     */
    private $island;

    /**
     * @var \Label
     *
     * @ORM\ManyToOne(targetEntity="Label")
     * @ORM\JoinColumn(name="city_label_id", referencedColumnName="label_id")
     */
    private $city;

    /**
     * @var \Label
     *
     * @ORM\ManyToOne(targetEntity="Label")
     * @ORM\JoinColumn(name="type_label_id", referencedColumnName="label_id")
     */
    private $type;

    /**
    * @ORM\OneToMany(targetEntity="HotelRating", mappedBy="company", cascade={"remove", "persist"})
    * @ORM\OrderBy({"perDay" = "ASC"})
    */
    private $hotelRatings;

    /**
     * @ORM\OneToMany(targetEntity="CarRating", mappedBy="company", cascade={"remove", "persist"})
     * @ORM\OrderBy({"perDay" = "ASC"})
     */
    private $carRatings;
    
    private $nameAndIsland;
    
    public function __construct() {
        
        $this->hotelRatings = new ArrayCollection();
        $this->carRatings = new ArrayCollection();
        
        $this->island = new Label(Label::TYPE_ISLAND);
        $this->city = new Label(Label::TYPE_CITY);
        $this->type = new Label(Label::TYPE_COMP_TYPE);
        
    }
    
    /*
    public function __toString() {
    	return $this->name;
    }
	*/
    
    /**
     * Set id
     *
     * @param integer $id
     * @return Company
     */
    public function setId($id)
    {
        $this->id = $id;
    
        return $this;
    }

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return Company
     */
    public function setName($name)
    {
        $this->name = $name;
    
        return $this;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set rating
     *
     * @param float $rating
     * @return Company
     */
    public function setRating($rating)
    {
        $this->rating = $rating;
    
        return $this;
    }

    /**
     * Get rating
     *
     * @return float 
     */
    public function getRating()
    {
        return $this->rating;
    }

    /**
     * Set description
     *
     * @param string $description
     * @return Company
     */
    public function setDescription($description)
    {
        $this->description = $description;
    
        return $this;
    }

    /**
     * Get description
     *
     * @return string 
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set island
     *
     * @param \cjrp\WebsiteBundle\Entity\Label $island
     * @return Company
     */
    public function setIsland(\cjrp\WebsiteBundle\Entity\Label $island)
    {
        $this->island = $island;
    
        return $this;
    }

    /**
     * Get island
     *
     * @return \cjrp\WebsiteBundle\Entity\Label 
     */
    public function getIsland()
    {
        return $this->island;
    }

    /**
     * Set city
     *
     * @param \cjrp\WebsiteBundle\Entity\Label $city
     * @return Company
     */
    public function setCity(\cjrp\WebsiteBundle\Entity\Label $city)
    {
        $this->city = $city;
    
        return $this;
    }

    /**
     * Get city
     *
     * @return \cjrp\WebsiteBundle\Entity\Label 
     */
    public function getCity()
    {
        return $this->city;
    }

    /**
     * Set type
     *
     * @param \cjrp\WebsiteBundle\Entity\Label $type
     * @return Company
     */
    public function setType(\cjrp\WebsiteBundle\Entity\Label $type)
    {
        $this->type = $type;
    
        return $this;
    }

    /**
     * Get type
     *
     * @return \cjrp\WebsiteBundle\Entity\Label 
     */
    public function getType()
    {
        return $this->type;
    }


    /**
     * Add HotelRating
     *
     * @param \cjrp\WebsiteBundle\Entity\HotelRating $hotelRatings
     */
    public function addHotelRating(\cjrp\WebsiteBundle\Entity\HotelRating $hotelRatings)
    {
        $this->hotelRatings[] = $hotelRatings;
    }

    /**
     * Get comments
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getHotelRatings()
    {
        return $this->hotelRatings;
    }
    
    /**
     * Get comments
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getCarRatings()
    {
    	return $this->carRatings;
    }    
    
    /**
     * Set CarRatings
     *
     * @param \Doctrine\Common\Collections\ArrayCollection $cr
     * @return Company
     */
    public function setCarRatings(\Doctrine\Common\Collections\ArrayCollection $carRatings)
    {
    	$this->carRatings = $carRatings;
    
    	return $this;
    }    
    
    /**
     * add CarRating
     *
     * @return Company
     */
    public function addCarRating(\cjrp\WebsiteBundle\Entity\CarRating $carRating)
    {
    	$this->carRatings[] = $carRating;
    	
    	return $this;
    }    
    
    public function getNameAndIsland()
    {
    	return $this->name . ' ('.$this->getIsland()->getValue().')';	
    }
}