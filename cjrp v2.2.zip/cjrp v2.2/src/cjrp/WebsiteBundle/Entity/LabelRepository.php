<?php
namespace cjrp\WebsiteBundle\Entity;

use Doctrine\ORM\EntityRepository;
use Doctrine\Common\Collections\Collection;

use cjrp\WebsiteBundle\Entity\Label;

class LabelRepository extends EntityRepository
{
	public function findAllIslands()
	{
		return $this->findBy(array('type'=> Label::TYPE_ISLAND), array('value'=>'ASC'));
	}
	
	public function findAllCarMakes()
	{
		return $this->findBy(array('type'=> Label::CAR_MAKE), array('value'=>'ASC'));
	}

	public function findAllCarTypes()
	{
		return $this->findBy(array('type'=> Label::CAR_TYPE), array('value'=>'ASC'));
	}
	
	public function findAllCarTypesValue() 
	{
		$all = $this->findBy(array('type'=> Label::CAR_TYPE), array('value'=>'ASC'));
		$types = array();
		foreach ($all as $value) {
			$types[$value->getValue()] = $value->getValue();
		}
		return $types;
	}
	
	public function findAllCities()
	{
		return $this->findBy(array('type'=> Label::TYPE_CITY), array('value'=>'ASC'));
	}
	
	public function findAllCompanyTypes()
	{
		return $this->findBy(array('type'=>Label::TYPE_COMP_TYPE), array('value'=>'ASC'));
	}
			
}