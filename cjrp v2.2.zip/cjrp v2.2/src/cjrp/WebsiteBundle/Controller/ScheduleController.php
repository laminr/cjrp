<?php

namespace cjrp\WebsiteBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use cjrp\WebsiteBundle\Data\routes as Routes;

class ScheduleController extends Controller
{
    public function indexAction()
    {
    	$routes = Routes::getValues();
    	
        return $this->render('cjrpWebsiteBundle:Schedule:schedule.html.twig', 
        	array('routes' => $routes));
    }
}
