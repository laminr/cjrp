<?php

namespace cjrp\WebsiteBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use cjrp\WebsiteBundle\Data\ads as Ads;

class AdsController extends Controller
{
    public function indexAction($pageName = 'schedule')
    {
    	$ads = Ads::getValues();
        return $this->render('cjrpWebsiteBundle:Ads:ads.html.twig', array('ads' => $ads[$pageName]));
    }
}
