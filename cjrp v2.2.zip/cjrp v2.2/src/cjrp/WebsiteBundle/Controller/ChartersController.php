<?php

namespace cjrp\WebsiteBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Form\FormBuilder;
use \Swift_Message;

use cjrp\WebsiteBundle\Data\charters as Charters;
use cjrp\WebsiteBundle\Form\ChartersForm;


class ChartersController extends Controller
{
    public function indexAction(Request $request)
    {
    	$charters = Charters::getValues();
    	$chartersForm = new ChartersForm();
    	$isGettingEmail = false;

    	$form = $this->createFormBuilder($chartersForm)
                    ->add('isRoundtrip', 'text')
		            ->add('departureDate', 'text', array('required' => true))
                    ->add('departureTime', 'text', array('required' => true))
                    ->add('returnDate', 'text')
                    ->add('returnTime', 'text') 
                    ->add('airportFrom', 'text', array('required' => true))
                    ->add('airportTo', 'text', array('required' => true))
                    ->add('nbrPax', 'integer', array('required' => true))
                    ->add('connecting', 'radio')
                    ->add('firstName', 'text', array('required' => true))
                    ->add('lastName', 'text', array('required' => true))
                    ->add('tel', 'text')
                    ->add('mobile', 'text')
                    ->add('fax', 'text')
                    ->add('email', 'email', array('required' => true))
                    ->add('comments', 'text', array('required' => true))
		            ->getForm();

    	/*
		{{ form_label(form.contenu, "Contenu de l'article") }}
	  	{{ form_errors(form.contenu) }}
	  	{{ form_widget(form.contenu) }}
    	*/
    	$request = $this->get('request');

		if ($request->getMethod() == 'POST') {
			
            $form->bind($request);
            //if ($form->isValid()) {
                $sendFrom = $this->container->getParameter('mailer_user');
                $sendTo = $this->container->getParameter('mailer_sendingTo');

                $message = Swift_Message::newInstance()
                    ->setSubject('CHARTERS FORM REQUEST')
                    ->setFrom(array($sendFrom => 'CJRP Website'))
                    ->setTo(array($sendTo => 'WEBMASTER'))
                    //->setFrom(array('noreply@cjrptravel.com' => 'CJRP Website'))
                    //->setTo(array('thibault.delambilly@gmail.com' => 'WEBMASTER'))
                    ->setBody(
                        $this->renderView('cjrpWebsiteBundle:Email:chartersBooking.html.twig', array('charter' => $chartersForm)),
                        'text/html'
                    );
                    //
                $result = $this->get('mailer')->send($message);
               // return $this->redirect($this->generateUrl('sdzblog_voir', array('id' => $article->getId())));
            	$isGettingEmail = $result > 0 ? true : false;
			//}
		}

        return $this->render('cjrpWebsiteBundle:Charters:charters.html.twig', 
        	array('charters' => $charters, 'form' => $form->createView(), 'isGettingEmail' => $isGettingEmail)
        );
    }
}
