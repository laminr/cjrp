<?php

namespace cjrp\WebsiteBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Form\FormBuilder;
use \Swift_Message;

use cjrp\WebsiteBundle\Form\HotelBookingForm;
use cjrp\WebsiteBundle\Form\ContactBookingForm;
use cjrp\WebsiteBundle\Entity\Label;

class HotelBookingController extends Controller
{

    public function indexAction(Request $request) {

        $hotelBookingForm = new HotelBookingForm();
		
        $fromHotelBooking = $request->get('isGettingEmailHotel');
        $isGettingEmailHotel = ($fromHotelBooking == null || $fromHotelBooking == false) ? false : true;

        $hotelform = $this->createForm('HotelBookingType', $hotelBookingForm);
		$em = $this->getDoctrine()->getManager();
		$query = $em->createQuery('SELECT label.value FROM cjrpWebsiteBundle:Label label WHERE label.type = :type ORDER BY label.value');
		$query->setParameter('type', Label::TYPE_ISLAND);
		
		$destinations = $query->getResult();
		
        return $this->render('cjrpWebsiteBundle:Hotel:hotelBooking.html.twig', 
            array(
                'hotelForm' => $hotelform->createView(),
            	'destinations' => $destinations,
                'isGettingEmailHotel' => $isGettingEmailHotel
            )
        );
    }

    public function searchHotelBookingAction(Request $request) {

        $hotelBookingForm = new HotelBookingForm();
        $hotelform = $this->createForm('HotelBookingType', $hotelBookingForm);

        $contactBookingForm = new ContactBookingForm();
        $contactform = $this->createForm('ContactBookingType', $contactBookingForm);

        //$request = $this->get('request');

        if ($request->getMethod() == 'POST') {

            //$hotelform->bind($request);
            $hotelform->handleRequest($request);
            
            try {
                $em = $this->getDoctrine()->getManager();
                $query = $em->createQuery(
                		'SELECT company
                        FROM cjrpWebsiteBundle:Company company
                            JOIN company.island island
                            JOIN company.type type
                        WHERE island.value = :island AND type.value = :type
                		AND SIZE(company.hotelRatings) >= 1
                        ORDER BY company.name ASC'
                )->setParameters(array('island' => $hotelBookingForm->getCountry(), 'type' => Label::COMP_HOUSING));
                $hotels = $query->getResult();

                return $this->render('cjrpWebsiteBundle:Hotel:hotelSearchResults.html.twig', 
                    array('booking' => $hotelBookingForm, 'hotels' => $hotels, 'contact' => $contactform->createView())
                );
            } catch (\Exception $e) {
                $logger = $this->get('logger');
                $logger->error('ERREUR');
                $logger->error($e->getMessage());
            }
        }
        return $this->redirect($this->generateUrl('_hotelBooking'));
    }

    public function finalHotelBookingAction(Request $request) {

        $contactBookingForm = new ContactBookingForm();
        $contactform = $this->createForm('ContactBookingType', $contactBookingForm);

        $request = $this->get('request');
        if ($request->getMethod() == 'POST') {

            $contactform->bind($request);

            // TODO: need exceptoin handling:
            try {
                $hotelRatingTaken = $this->getDoctrine()
                    ->getRepository('cjrpWebsiteBundle:HotelRating')
                    ->find($contactBookingForm->getRatingId());    
            } catch (\Exception $e) {
               // $this->get('session')->getFlashBag()->add('hotelBookingEmailError','busted!');
            }

            $subjet = ' HOTEL BOOKING FORM';
                        
            //if ($form->isValid()) {
                $sendFrom = $this->container->getParameter('mailer_user');
                $sendTo = $this->container->getParameter('mailer_sendingTo');

                $message = Swift_Message::newInstance()
                    ->setSubject($subjet)
                    ->setFrom(array($sendFrom => 'CJRP Website'))
                    ->setTo(array($sendTo => 'WEBMASTER'))
                    ->setBody(
                        $this->renderView( 'cjrpWebsiteBundle:Email:finalHotelBooking.html.twig', 
                            array('contact' => $contactBookingForm, 'rating' => $hotelRatingTaken)
                        ), 'text/html'
                    );

                $result = $this->get('mailer')->send($message);
                $isGettingEmailHotel = $result > 0 ? true : false;
            //}
        }

        return $this->redirect($this->generateUrl('_hotelBooking', array('isGettingEmailHotel'=> $isGettingEmailHotel)));
    }

    public function requestHotelBookingAction(Request $request) {

        $contactBookingForm = new ContactBookingForm();
        $contactform = $this->createForm('ContactBookingType', $contactBookingForm);

        //$request = $this->get('request');
        if ($request->getMethod() == 'POST') {

            $contactform->bind($request);
            
            $subjet = ' HOTEL REQUEST FORM';
                        
            //if ($form->isValid()) {
                $sendFrom = $this->container->getParameter('mailer_user');
                $sendTo = $this->container->getParameter('mailer_sendingTo');

                $message = Swift_Message::newInstance()
                    ->setSubject($subjet)
                    ->setFrom(array($sendFrom => 'CJRP Website'))
                    ->setTo(array($sendTo => 'WEBMASTER'))
                    ->setBody(
                        $this->renderView( 'cjrpWebsiteBundle:Email:requestHotelBooking.html.twig', 
                            array('contact' => $contactBookingForm)
                        ), 'text/html'
                    );

                $result = $this->get('mailer')->send($message);
                $isGettingEmailHotel = $result > 0 ? true : false;
            //}
        }

        return $this->redirect($this->generateUrl('_hotelBooking', array('isGettingEmailHotel'=> $isGettingEmailHotel)));
    }
}