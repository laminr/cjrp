<?php

namespace cjrp\WebsiteBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

class NewsController extends Controller
{
    public function indexAction(Request $request)
    {
        $em = $this->getDoctrine()->getManager();
        $query = $em->createQuery(
                'SELECT news FROM cjrpWebsiteBundle:News news ORDER BY news.when DESC'
            );
        $news = $query->getResult();

        return $this->render('cjrpWebsiteBundle:Standalone:news.html.twig',
            array('news' => $news)
        );
    }
}
