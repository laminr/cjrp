<?php

namespace cjrp\WebsiteBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Form\FormBuilder;
use \Swift_Message;

use cjrp\WebsiteBundle\Form\HotelBookingForm;
use cjrp\WebsiteBundle\Form\CarBookingForm;
use cjrp\WebsiteBundle\Form\ContactBookingForm;

#use cjrp\WebsiteBundle\Form\Type\CarBookingType;
#use cjrp\WebsiteBundle\Form\Type\HotelBookingType;

class CarController extends Controller
{

    public function indexAction(Request $request) {

        $carBookingForm = new CarBookingForm();
        
        $isGettingEmailCar = false;

        $carform = $this->createForm('CarBookingType', $carBookingForm);

        //$request = $this->get('request');

        if ($request->getMethod() == 'POST') {
            /*
            $carform->bind($request);
            $repository = $this->getDoctrine()->getRepository('cjrpWebsiteBundle:HotelBooking');
            $hotels = $repository->findAll();

            return $this->render('cjrpWebsiteBundle:CarAndHotelBooking:hotelSearchResults.html.twig', 
                array('hotels' => $hotels, 'booking' => $hotelBookingForm)
            );
            */
        }

        return $this->render('cjrpWebsiteBundle:Car:carBooking.html.twig', 
            array( 
                'carForm' => $carform->createView(), 
                'isGettingEmailCar' => $isGettingEmailCar
            )
        );
    }

    public function emailAction(Request $request) {

        $carBookingForm = new CarBookingForm();
        $isGettingEmailCar = false;

        $carform = $this->createForm('CarBookingType', $carBookingForm);

        $request = $this->get('request');

        if ($request->getMethod() == 'POST') {

            $carform->bind($request);

            $emailView = '';
            $subjet = ' FORM REQUEST';
             
                $emailView = 'cjrpWebsiteBundle:Email:carBooking.html.twig';
                $subjet = 'CAR'.$subjet;
            
            //if ($form->isValid()) {
                $sendFrom = $this->container->getParameter('mailer_user');
                $sendTo = $this->container->getParameter('mailer_sendingTo');

                //*
                $message = Swift_Message::newInstance()
                    ->setSubject($subjet)
                    ->setFrom(array($sendFrom => 'CJRP Website'))
                    ->setTo(array($sendTo => 'WEBMASTER'))
                    ->setBody(
                        $this->renderView( $emailView, 
                            array('car' => $carBookingForm)
                        ), 'text/html'
                    );
                    //

                $result = $this->get('mailer')->send($message);
                $isGettingEmailCar = $result > 0 ? true : false;
                //*/
            //}
        }

        return $this->render('cjrpWebsiteBundle:Car:carBooking.html.twig', 
            array( 
                'carForm' => $carform->createView(), 
                'isGettingEmailCar' => $isGettingEmailCar
            )
        );
    }
}