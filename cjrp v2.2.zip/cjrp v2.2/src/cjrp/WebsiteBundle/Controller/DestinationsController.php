<?php

namespace cjrp\WebsiteBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class DestinationsController extends Controller
{
    public function indexAction($whereTo)
    {    	
        return $this->render('cjrpWebsiteBundle:Destinations:destinations.html.twig', 
        	array('whereTo' => $whereTo));
    }
}
