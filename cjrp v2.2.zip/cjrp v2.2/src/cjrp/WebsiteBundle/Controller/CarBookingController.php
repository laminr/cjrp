<?php

namespace cjrp\WebsiteBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Form\FormBuilder;
use \Swift_Message;

use cjrp\WebsiteBundle\Form\Type\CarBookingType;
use cjrp\WebsiteBundle\Form\CarBookingForm;
use cjrp\WebsiteBundle\Form\CarContactBookingForm;
use cjrp\WebsiteBundle\Form\Type\CarContactBookingType;
use cjrp\WebsiteBundle\Entity\Label;
use cjrp\WebsiteBundle\Entity\Car;

class CarBookingController extends Controller
{

    public function indexAction(Request $request) {

        $carBookingForm = new CarBookingForm();
		
        $fromCarBooking = $request->get('isGettingEmailHotel');
        $isGettingEmailCar = ($fromCarBooking == null || $fromCarBooking == false) ? false : true;
		
        $carform = $this->createForm(new CarBookingType($this->getDoctrine()), $carBookingForm);
        
        $repo = $this->getDoctrine()->getRepository('cjrpWebsiteBundle:Label');        
		//$destinations = $repo->findAllIslands();		
		$carTypes = $repo->findAllCarTypes();
		$allType = new Label(Label::CAR_TYPE);
		$allType->setValue(Car::TYPE_ALL);
		
		// add at start
		array_unshift($carTypes, $allType);
		
        return $this->render('cjrpWebsiteBundle:Car:carBooking.html.twig', 
            array(
                'carForm' => $carform->createView(),
            	'allTypeLabel' => Car::TYPE_ALL,
                'isGettingEmailCar' => $isGettingEmailCar
            )
        );
    }

    public function searchCarBookingAction(Request $request) {

        $carBookingForm = new CarBookingForm();
        $carform = $this->createForm(new CarBookingType($this->getDoctrine()) , $carBookingForm);

        $contactBookingForm = new CarContactBookingForm();
        $contactform = $this->createForm(new CarContactBookingType(), $contactBookingForm);
				
		$carform->handleRequest($request);
		if ($carform->isValid()) {
            try {
                $em = $this->getDoctrine()->getManager();
                
                $companies = $em->getRepository('cjrpWebsiteBundle:CarRating')
            			->findAllRatingForAType(
            					$carBookingForm->getCarType(), 
            					$carBookingForm->getCarAirport()->getValue()
        				);
                
                $where = $carBookingForm->getIsAirport() ? "airport" : "seaport";
                
                $data = "Dear CJRP Travel, \r\n I confirm this reservation with #companie#, for a #car# ";
                $data .= $carBookingForm->getCarAirport()->getValue() . " @ the " . $where;
                $data .= ", for the period starting from ";
                $data .= $carBookingForm->getPickUpdate() ." to ". $carBookingForm->getDropOffDate();
                $data .= ' ('.$carBookingForm->getTimeInWeekAndDay().')';
                
                // setup some value hidden
                $contactform->get("comment")->setData($data);
                $contactform->get("where")->setData($where);
                
                return $this->render('cjrpWebsiteBundle:Car:carSearchResults.html.twig', 
                    array('booking' => $carBookingForm, 'companies' => $companies, 'contact' => $contactform->createView())
                );
                
            } catch (\Exception $e) {
                $logger = $this->get('logger');
                $logger->error('CarBookingController:searchCarBookingAction --> ERREUR');
                $logger->error($e->getMessage());
                
                $this->get('session')->getFlashBag()->add('error', 'An error has occured during process');

            }
		}
		
        return $this->redirect($this->generateUrl('_carBooking'));
    }

    public function finalCarBookingAction(Request $request) {

        $contactBookingForm = new CarContactBookingForm();
        $contactform = $this->createForm(new CarContactBookingType(), $contactBookingForm);

        $contactform->handleRequest($request);
        if ($contactform->isValid()) {
            try {
                $carRatingTaken = $this->getDoctrine()
                    ->getRepository('cjrpWebsiteBundle:CarRating')
                    ->find($contactBookingForm->getRatingId()); 
            } catch (\Exception $e) {
                $logger = $this->get('logger');
                $logger->error('CarBookingController:finalCarBookingAction:Get $carRatingTaken --> ERREUR');
                $logger->error($e->getMessage());
            }

            $subjet = 'CAR BOOKING FORM';
                        
           	$sendFrom = $this->container->getParameter('mailer_user');
            $sendTo = $this->container->getParameter('mailer_sendingTo');

            $message = Swift_Message::newInstance()
                    ->setSubject($subjet)
                    ->setFrom(array($sendFrom => 'CJRP Website'))
                    ->setTo(array($sendTo => 'WEBMASTER'))
                    ->setBody(
                        $this->renderView( 'cjrpWebsiteBundle:Email:finalCarBooking.html.twig', 
                            array('contact' => $contactBookingForm, 'rating' => $carRatingTaken)
                        ), 'text/html'
                    );

          	$result = $this->get('mailer')->send($message);
            if ($result > 0) {
            	$flash = $this->get('session')->getFlashBag();
            	$flash->add('carBookingHtml', 'get email');
            	$flash->add('carBookingJs', 'get email');
            }
        }
        return $this->redirect($this->generateUrl('_carBooking'));
    }

    public function requestCarBookingAction(Request $request) {

        $contactBookingForm = new CarContactBookingForm();
        $contactform = $this->createForm(new CarContactBookingType(), $contactBookingForm);
        
        if ($request->getMethod() == 'POST') {

            $contactform->bind($request);
            
            $subjet = 'CAR REQUEST FORM';
                        
            //if ($form->isValid()) {
                $sendFrom = $this->container->getParameter('mailer_user');
                $sendTo = $this->container->getParameter('mailer_sendingTo');

                $message = Swift_Message::newInstance()
                    ->setSubject($subjet)
                    ->setFrom(array($sendFrom => 'CJRP Website'))
                    ->setTo(array($sendTo => 'WEBMASTER'))
                    ->setBody(
                        $this->renderView( 'cjrpWebsiteBundle:Email:requestCarBooking.html.twig', 
                            array('contact' => $contactBookingForm)
                        ), 'text/html'
                    );

                $result = $this->get('mailer')->send($message);
                if ($result > 0) {
	            	$flash = $this->get('session')->getFlashBag();
	            	$flash->add('carBookingHtml', 'get email');
	            	$flash->add('carBookingJs', 'get email');
            	}
            //}
        }

        return $this->redirect($this->generateUrl('_carBooking'));
    }
}