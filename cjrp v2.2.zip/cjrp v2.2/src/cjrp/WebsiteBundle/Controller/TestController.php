<?php

namespace cjrp\WebsiteBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;

use Symfony\Component\HttpFoundation\Response;

use cjrp\WebsiteBundle\Entity\CarBooking;


class TestController extends Controller
{
    public function indexAction(Request $request)
    {
    	$car = new CarBooking();

        $car->setCompany("Gubsie");
        $car->setIsland("Anguilla");
        $car->setType("Jeep");
        $car->setMake("Suzuki");
        $car->setModel("Vitara");
        $car->setSeats("5/7");
        $car->setPerday(123.45);
        $car->setPerweek(541.23);
        $car->setChargePerDay(10);
        $car->setRatioChargePerWeek(3);

        $em = $this->getDoctrine()->getManager();
        $em->persist($car);
        $em->flush();

        return new Response('<html><body>DONE</body></html>');
    }
}
