<?php

namespace cjrp\WebsiteBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Response;

class SecurityController extends Controller
{
    public function indexAction($env)
    {
    	echo __DIR__;
    	
    	if ($env != 'all') {
    		$path = explode('src', __DIR__);
    		$dir = $path[0].'app/cache/'.$env;
    		echo $dir;
    	} else {
    		$path = explode('Controller', __DIR__);
    		$dir = $path[0].'Resources/views';
    		echo $dir;
    	}
    	
    	try {
    		$this->recursiveRemove($dir);
    		return new Response('<html><body><div>DONE!</div></body></html>');
    	} catch (Exception $e) {
    		return new Response('<html><body><div>'.$e->getCode().'</div></body></html>');
    	}
			
    }

    function recursiveRemove($dir) {
    	$structure = glob(rtrim($dir, "/").'/*');
    	if (is_array($structure)) {
    		foreach($structure as $file) {
    			if (is_dir($file)) {
    				$this->recursiveRemove($file);
    			} elseif (is_file($file)) {
    				var_dump($file);
    				unlink($file);
    			}
    		}
    	}
    	rmdir($dir);
    }

}
