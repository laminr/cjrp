<?php 
namespace cjrp\WebsiteBundle\Form;

class ContactBookingForm {

    private $ratingId;
    private $nbrRoom;
    private $bookDates;
    private $nbrPerson;
    private $name;
    private $phone;
    private $email;
    private $comment;

    function setRatingId($ratingId) {
        $this->ratingId = $ratingId; 
    }

    function getRatingId() {
        return $this->ratingId; 
    }

    function setBookDates($bookDates) {
        $this->bookDates = $bookDates; 
    }

    function getBookDates() {
        return $this->bookDates; 
    }

    function setNbrRoom($nbrRoom) {
        $this->nbrRoom = $nbrRoom; 
    }

    function getNbrRoom() {
        return $this->nbrRoom; 
    }

    function setNbrPerson($nbrPerson) {
        $this->nbrPerson = $nbrPerson; 
    }

    function getNbrPerson() {
        return $this->nbrPerson; 
    }

    function setName($name) {
        $this->name = $name; 
    }

    function getName() {
        return $this->name; 
    }

    function setPhone($phone) {
        $this->phone = $phone; 
    }

    function getPhone() {
        return $this->phone; 
    }

    function setEmail($email) {
        $this->email = $email; 
    }

    function getEmail() {
        return $this->email; 
    }

    function setComment($comment) {
        $this->comment = $comment; 
    }

    function getComment() {
        return $this->comment; 
    }    

}