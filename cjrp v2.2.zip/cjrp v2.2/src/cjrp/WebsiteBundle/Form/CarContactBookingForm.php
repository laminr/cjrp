<?php 
namespace cjrp\WebsiteBundle\Form;

class CarContactBookingForm {

    private $ratingId;
    private $bookDates;
    private $where;
    private $totalPrice;
    private $name;
    private $phone;
    private $email;
    private $comment;

    function setRatingId($ratingId) {
        $this->ratingId = $ratingId; 
    }

    function getRatingId() {
        return $this->ratingId; 
    }

    function setBookDates($bookDates) {
        $this->bookDates = $bookDates; 
    }

    function getBookDates() {
        return $this->bookDates; 
    }

    function setWhere($where) {
    	$this->where = $where;
    }
    
    function getWhere() {
    	return $this->where;
    }    
    
    function setTotalPrice($totalPrice) {
    	$this->totalPrice = $totalPrice;
    }
    
    function getTotalPrice() {
    	return $this->totalPrice;
    }    
    
    function setName($name) {
        $this->name = $name; 
    }

    function getName() {
        return $this->name; 
    }

    function setPhone($phone) {
        $this->phone = $phone; 
    }

    function getPhone() {
        return $this->phone; 
    }

    function setEmail($email) {
        $this->email = $email; 
    }

    function getEmail() {
        return $this->email; 
    }

    function setComment($comment) {
        $this->comment = $comment; 
    }

    function getComment() {
        return $this->comment; 
    }    

}