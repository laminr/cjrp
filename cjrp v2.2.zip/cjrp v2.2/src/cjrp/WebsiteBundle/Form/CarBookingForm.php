<?php
namespace cjrp\WebsiteBundle\Form;

use Symfony\Component\Validator\Constraints as Assert;

class CarBookingForm {
	
	private $carAirport;
	
	/**
	 * @Assert\Choice(choices= {0,1})
	 * @var unknown
	 */
	private $isAirport;

	/**
	 * @Assert\Date(message = "The date is not valid.")
	 */	
	private $pickUpDate;
	
	/**
	 * @Assert\Date(message = "The date is not valid.")
	 */
	private $dropOffDate;
	private $carType;
	private $carSubmit;

	function setCarAirport($carAirport) {
		$this->carAirport = $carAirport; 
	}

	function getCarAirport() {
		return $this->carAirport; 
	}

	function setIsAirport($isAirport) {
		$this->isAirport = $isAirport; 
	}

	function getIsAirport() {
		return $this->isAirport; 
	}

	function setPickUpDate($pickUpDate) {
		$this->pickUpDate = $pickUpDate; 
	}

	function getPickUpDate() {
		return $this->pickUpDate; 
	}

	function setDropOffDate($dropOffDate) {
		$this->dropOffDate = $dropOffDate; 
	}

	function getDropOffDate() {
		return $this->dropOffDate; 
	}

	function setCarType($carType) {
		$this->carType = $carType; 
	}

	function getCarType() {
		return $this->carType; 
	}
	
	function setCarSubmit($carSubmit) {
		$this->carSubmit = $carSubmit; 
	}

	function getCarSubmit() {
		return $this->carSubmit; 
	}
	
	function getNbrDay() {
		$in = new \DateTime($this->pickUpDate);
		$out = new \DateTime($this->dropOffDate);
		//var_dump($in);
		//var_dump($out);
		$interval = $in->diff($out);
		return $interval->days;
	}
	
	function getNbrWeek() {
		return (int)floor($this->getNbrDay() / 7);
	}
	
	function getNbrDayOverWeek() {
		return $this->getNbrDay() % 7;
	}
	
	function getTimeInWeekAndDay() {
		$timeInWeekAndDay = '';
		$isOverWeek = $this->getNbrWeek() >=1;
		
		if ($isOverWeek ) {
			$timeInWeekAndDay = $this->getNbrWeek() . ' Week';
			if ($this->getNbrWeek() > 1) {
				$timeInWeekAndDay .= 's';
			}
		} 

		if ($this->getNbrDayOverWeek() > 0) {
			$timeInWeekAndDay .= ' '.$this->getNbrDayOverWeek() . ' day';
			if ($this->getNbrDayOverWeek() > 1) {
				$timeInWeekAndDay .= 's';
			}
				
		}
		return $timeInWeekAndDay;
	}
}