<?php 
namespace cjrp\WebsiteBundle\Form;

class HotelBookingForm {

	private $country;
	private $checkInDate;
	private $checkOutDate;
	private $hotelAdults;
	private $hotelChildren;
	private $hotelMinor;
	private $nbrRooms;
	private $contactName;
	private $contactPhone;
	private $contactEmail;
	private $hotelSubmit;
	
	private $nbrNight;

	function setCountry($country) {
		$this->country = $country; 
	}

	function getCountry() {
		return $this->country; 
	}

	function setCheckInDate($checkInDate) {
		$this->checkInDate = $checkInDate; 
	}

	function getCheckInDate() {
		return $this->checkInDate; 
	}

	function setCheckOutDate($checkOutDate) {
		$this->checkOutDate = $checkOutDate; 
	}

	function getCheckOutDate() {
		return $this->checkOutDate; 
	}

	function setHotelAdults($hotelAdults) {
		$this->hotelAdults = $hotelAdults; 
	}

	function getHotelAdults() {
		return $this->hotelAdults; 
	}

	function setHotelChildren($hotelChildren) {
		$this->hotelChildren = $hotelChildren; 
	}

	function getHotelChildren() {
		return $this->hotelChildren; 
	}

	function setHotelMinor($hotelMinor) {
		$this->hotelMinor = $hotelMinor; 
	}

	function getHotelMinor() {
		return $this->hotelMinor; 
	}

	function setNbrRooms($nbrRooms) {
		$this->nbrRooms = $nbrRooms; 
	}

	function getNbrRooms() {
		return $this->nbrRooms; 
	}

	function setContactName($contactName) {
		$this->contactName = $contactName; 
	}

	function getContactName() {
		return $this->contactName; 
	}

	function setContactPhone($contactPhone) {
		$this->contactPhone = $contactPhone; 
	}

	function getContactPhone() {
		return $this->contactPhone; 
	}

	function setContactEmail($contactEmail) {
		$this->contactEmail = $contactEmail; 
	}

	function getContactEmail() {
		return $this->contactEmail; 
	}

	function setHotelSubmit($hotelSubmit) {
		$this->hotelSubmit = $hotelSubmit; 
	}

	function getHotelSubmit() {
		return $this->hotelSubmit; 
	}
	
	function getNbrNight() {
		$in = new \DateTime($this->checkInDate);
		$out = new \DateTime($this->checkOutDate);
		$interval = $in->diff($out);
		
		return $interval->format('%d');
	}
}