<?php 
namespace cjrp\WebsiteBundle\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class CarContactBookingType extends AbstractType {
    
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->add('ratingId', 'hidden')
        		->add('where', 'hidden')
                ->add('bookDates', 'hidden')
                ->add('totalPrice', 'hidden')
                ->add('name', 'text')
                ->add('phone', 'text')
                ->add('email', 'email')
                ->add('comment', 'textarea');
    }

    public function getName()
    {
        return 'CarContactBookingType'; //must be unique.
    }

    //Symfony can guess the type but it is a good practice to always set de data_class because embedding forms is necessary.
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'cjrp\WebsiteBundle\Form\CarContactBookingForm',
            'csrf_protection' => true,
            'csrf_field_name' => '_carContactBookingtoken', // a unique key to help generate the secret token
            'intention' => 'carContactBooking_item',
        ));
    }

}