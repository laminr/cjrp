<?php 
namespace cjrp\WebsiteBundle\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class CarType extends AbstractType {
    
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->add('country', 'text')
                ->add('make', 'text', array('required' => true))
                ->add('model', 'text', array('required' => true))
                ->add('type', 'text')
                ->add('seats', 'text')
                ->add('addCarSubmit', 'submit');
    }

    public function getName()
    {
        return 'CarType'; //must be unique.
    }

    //Symfony can guess the type but it is a good practice to always set de data_class because embedding forms is necessary.
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'cjrp\WebsiteBundle\Entity\Car',
            'cascade_validation' => false, //needed to validate embeed forms.
            'validation_groups' => array('HotelBooking'), //use of validation groups.
            'csrf_protection' => true,
            'csrf_field_name' => '_addCartoken', // a unique key to help generate the secret token
            'intention' => 'addCar_item',
        ));
    }

}