<?php 
namespace cjrp\WebsiteBundle\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

use Symfony\Bridge\Doctrine\RegistryInterface;
use cjrp\WebsiteBundle\Entity\Label;
use cjrp\WebsiteBundle\Entity\Car;

class CarBookingType extends AbstractType {
    
	private $doctrine;
	
	public function __construct(RegistryInterface $doctrine)
	{
		$this->doctrine = $doctrine;
	}
	
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
    	$repo = $this->doctrine->getRepository('cjrpWebsiteBundle:Label');

    	$islands = $repo->findAllIslands();
    	
    	$types = $repo->findAllCarTypesValue();    	
    	// add at start
    	$allTypes = array_merge(array(Car::TYPE_ALL => Car::TYPE_ALL), $types);
    	 
    	
        $builder->add('carAirport', 'entity', array(
						'choices' => $islands,
						'class' => 'cjrpWebsiteBundle:Label',
						'property' => 'value',
        				'empty_value' => '',
						'multiple'  => false,
						'required' => true)
				)
                ->add('isAirport', 'choice', array(
                		"choices" => array(1 => "Airport", 0 => "Seaport"),
                		"expanded" => true,
                		"multiple" => false,
                		"data" => 1)
                )
                ->add('pickUpDate', 'text', array('required' => true))
                ->add('dropOffDate', 'text')
                ->add('carType', 'choice',  array(
                		'choices' => $allTypes,
                		'empty_value' => '',
                		'multiple'  => false,
                		'required' => true)
                )
                ->add('carSubmit', 'submit', array('label' => 'Submit'));
    }

    public function getName()
    {
        return 'CarBookingType'; //must be unique.
    }

    //Symfony can guess the type but it is a good practice to always set de data_class because embedding forms is necessary.
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'cjrp\WebsiteBundle\Form\CarBookingForm',
            'cascade_validation' => false, //needed to validate embeed forms.
            'validation_groups' => array('carBooking'), //use of validation groups.
            'csrf_protection' => true,
            'csrf_field_name' => '_carBookingtoken', // a unique key to help generate the secret token
            'intention' => 'carBooking_item',
        ));
    }

}