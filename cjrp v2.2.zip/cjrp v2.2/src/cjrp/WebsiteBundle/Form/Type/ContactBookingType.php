<?php 
namespace cjrp\WebsiteBundle\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class ContactBookingType extends AbstractType {
    
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->add('ratingId', 'integer')
                ->add('nbrRoom', 'integer')
                ->add('bookDates', 'text')
                ->add('nbrPerson', 'text')
                ->add('name', 'text')
                ->add('phone', 'text')
                ->add('email', 'email')
                ->add('comment', 'textarea');
    }

    public function getName()
    {
        return 'ContactBookingType'; //must be unique.
    }

    //Symfony can guess the type but it is a good practice to always set de data_class because embedding forms is necessary.
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'cjrp\WebsiteBundle\Form\ContactBookingForm',
            'csrf_protection' => true,
            'csrf_field_name' => '_contactBookingtoken', // a unique key to help generate the secret token
            'intention' => 'contactBooking_item',
        ));
    }

}