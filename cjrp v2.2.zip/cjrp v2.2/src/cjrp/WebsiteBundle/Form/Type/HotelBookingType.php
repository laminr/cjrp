<?php 
namespace cjrp\WebsiteBundle\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class HotelBookingType extends AbstractType {
    
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->add('country', 'text')
                ->add('checkInDate', 'text', array('required' => true))
                ->add('checkOutDate', 'text', array('required' => true))
                ->add('hotelAdults', 'text')
                ->add('hotelChildren', 'text')
                ->add('hotelMinor', 'text')
                ->add('nbrRooms', 'text')
                ->add('contactName', 'text', array('required' => true))
                ->add('contactPhone', 'text')
                ->add('contactEmail', 'text')
                ->add('hotelSubmit', 'submit');
    }

    public function getName()
    {
        return 'HotelBookingType'; //must be unique.
    }

    //Symfony can guess the type but it is a good practice to always set de data_class because embedding forms is necessary.
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'cjrp\WebsiteBundle\Form\HotelBookingForm',
            'cascade_validation' => false, //needed to validate embeed forms.
            'validation_groups' => array('HotelBooking'), //use of validation groups.
            'csrf_protection' => true,
            'csrf_field_name' => '_hotelBookingtoken', // a unique key to help generate the secret token
            'intention' => 'hotelBooking_item',
        ));
    }

}