<?php
namespace cjrp\WebsiteBundle\Form;

class ChartersForm {

	private $isRoundtrip;
	private $airportFrom;
	private $airportTo;
	private $nbrPax;
	private $departureDate;
	private $departureTime;
	private $returnDate;
	private $returnTime;
	private $connecting;
	private $firstName;
	private $lastName;
	private $tel;
	private $mobile;
	private $email;
	private $fax;
	private $comments;
	private $hour;
	private $minute;

	public function setIsRoundtrip($isRoundtrip) {
		$this->isRoundtrip = $isRoundtrip; 
	}

	public function getIsRoundtrip() {
		return $this->isRoundtrip; 
	}

	public function setAirportFrom($airportFrom) {
		$this->airportFrom = $airportFrom; 
	}

	public function getAirportFrom() {
		return $this->airportFrom; 
	}

	public function setAirportTo($airportTo) {
		$this->airportTo = $airportTo; 
	}

	public function getAirportTo() {
		return $this->airportTo; 
	}

	public function setNbrPax($nbrPax) {
		$this->nbrPax = $nbrPax; 
	}

	public function getNbrPax() {
		return $this->nbrPax; 
	}

	public function setDepartureDate($departureDate) {
		$this->departureDate = $departureDate; 
	}

	public function getDepartureDate() {
		return $this->departureDate; 
	}

	public function setDepartureTime($departureTime) {
		$this->departureTime = $departureTime; 
	}

	public function getDepartureTime() {
		return $this->departureTime; 
	}

	public function setReturnDate($returnDate) {
		$this->returnDate = $returnDate; 
	}

	public function getReturnDate() {
		return $this->returnDate; 
	}

	public function setReturnTime($returnTime) {
		$this->returnTime = $returnTime; 
	}

	public function getReturnTime() {
		return $this->returnTime; 
	}

	public function setConnecting($connecting) {
		$this->connecting = $connecting; 
	}

	public function getConnecting() {
		return $this->connecting; 
	}

	public function setFirstName($firstName) {
		$this->firstName = $firstName; 
	}

	public function getFirstName() {
		return $this->firstName; 
	}

	public function setLastName($lastName) {
		$this->lastName = $lastName; 
	}

	public function getLastName() {
		return $this->lastName; 
	}

	public function setTel($tel) {
		$this->tel = $tel; 
	}

	public function getTel() {
		return $this->tel; 
	}

	public function setMobile($mobile) {
		$this->mobile = $mobile; 
	}

	public function getMobile() {
		return $this->mobile; 
	}

	public function setEmail($email) {
		$this->email = $email; 
	}

	public function getEmail() {
		return $this->email; 
	}

	public function setFax($fax) {
		$this->fax = $fax; 
	}

	public function getFax() {
		return $this->fax; 
	}

	public function setComments($comments) {
		$this->comments = $comments; 
	}

	public function getComments() {
		return $this->comments; 
	}

}
