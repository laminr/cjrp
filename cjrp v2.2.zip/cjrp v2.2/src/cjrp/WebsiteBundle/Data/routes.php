<?php
namespace cjrp\WebsiteBundle\Data;

class Routes {

        private static $route_1 = array(
        	array('Tortola', 'St. Kitts'),
        	array('Monday', '08:10', '09:00', 'CJ231', 'Direct', '15/12/13', '30/04/14'),
            array('Wednesday', '08:10', '09:00', 'CJ508', 'Direct', '15/11/13', '15/07/14'),
            array('Friday', '08:10', '09:00', 'CJ231', 'Direct', '15/12/13', '30/04/14'),
        	array('Saturday', '08:10', '09:00', 'CJ508', 'Direct', '15/11/13', '15/07/14')
        );

        // PHP Solution 2
        private static $route_2 = array(
        	array('St. Kitts', 'Tortola'),
        	array('Monday', '11:00', '11:50', 'CJ232', 'Direct', '15/12/13', '30/04/14'),
            array('Wednesday', '11:00', '11:50', 'CJ509', 'Direct', '15/11/13', '15/07/14'),
            array('Friday', '11:00', '11:50', 'CJ232', 'Direct', '15/12/13', '30/04/14'),
        	array('Saturday', '11:00', '00:50', 'CJ509', 'Direct', '15/11/13', '15/07/14')
        );

        private static $route_3 = array(
        	array('St. Maarten', 'St. Kitts'),
        	array("Monday", "10:20", "10:40", "CJ232", "Direct","15/12/13","30/04/14"),
            array("Wednesday", "10:20", "10:40", "CJ509", "Direct","15/11/13","15/07/14"),
            array("Friday", "10:20", "10:40", "CJ232", "Direct","15/12/13","30/04/14"),
        	array("Saturday", "10:20", "10:40", "CJ509", "Direct","15/11/13","15/07/14")
        );
        
        private static $route_4 = array(
        	array('St. Kitts', 'St. Maarten'),
        	array("Monday", "09:15", "09:35", "CJ231", "Direct","15/12/13","30/04/14"),
            array("Wednesday", "09:15", "09:35", "CJ508", "Direct","15/11/13","15/07/14"),
            array("Friday", "09:15", "09:35", "CJ231", "Direct","15/12/13","30/04/14"),
        	array("Saturday", "09:15", "09:35", "CJ508", "Direct","15/11/13","15/07/14")
        );
        
        private static $route_5 = array(
        	array('Anguilla', 'St. Kitts'),
                array("Monday", "10:00", "10:30", "CJ722", "Direct","01/11/13","30/04/14"),
                array("Monday", "15:50", "16:20", "CJ730", "Direct","13/12/13","30/04/14"), 
                array("Wednesday", "10:00", "10:30", "CJ722", "Direct","13/12/13","30/04/14"),
                array("Wednesday", "15:50", "16:20", "CJ730", "Direct","13/12/13","30/04/14"),
                array("Friday", "10:00", "10:30", "CJ722", "Direct","13/12/13","30/04/14"),
                array("Friday", "15:50", "16:20", "CJ730", "Direct","01/11/13","30/04/14"),                                                                                             array("Saturday", "10:00", "10:30", "CJ722", "Direct","13/12/13","30/04/14"),
                array("Saturday", "15:50", "16:20", "CJ730", "Direct","13/12/13","30/04/14"),         
        );

        private static $route_6 = array(
        	array('St. Kitts', 'Anguilla'),
            array("Monday", "10:55", "11:25", "CJ723", "Direct","01/11/13","30/04/14"),
            array("Monday", "16:35", "17:55", "CJ733", "Direct","13/12/13","30/04/14"),
            array("Wednesday", "10:55", "11:25", "CJ723", "Direct","13/12/13","30/04/14"),
            array("Wednesday", "16:35", "17:55", "CJ733", "Direct","13/12/13","30/04/14"),
            array("Friday", "10:55", "11:25", "CJ723", "Direct","13/12/13","30/04/14"),
            array("Friday", "16:35", "17:55", "CJ733", "Direct","01/11/13","30/04/14"),
            array("Saturday", "10:55", "11:25", "CJ723", "Direct","13/12/13","30/04/14"),
            array("Saturday", "16:35", "17:55", "CJ733", "Direct","13/12/13","30/04/14"),
        ); 

        private static $routes = array();

        public static function getValues() {
            
            self::$routes[] = self::$route_1;
            self::$routes[] = self::$route_2;
            self::$routes[] = self::$route_3;
            self::$routes[] = self::$route_4;
            self::$routes[] = self::$route_5;
            self::$routes[] = self::$route_6;

            return self::$routes;
        }
}