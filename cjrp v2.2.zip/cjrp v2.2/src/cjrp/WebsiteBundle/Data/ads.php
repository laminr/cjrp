<?php
namespace cjrp\WebsiteBundle\Data;

class Ads {

	private static $adsSchedule = array(
		array("dolphin-large.jpg" , "dolphin-small.jpg", "Dolphin swim special"),
		array("blank" , "blank", "blank"),
		array("blank" , "blank", "blank"),
		array("blank" , "blank", "blank")
	);

	private static $adsNews = array(
		array("blank" , "blank", "blank"),
		array("blank" , "blank", "blank"),
		array("blank" , "blank", "blank"),
		array("blank" , "blank", "blank")
	);

	private static $adsCharter = array(
		array("blank" , "blank", "blank"),
		array("blank" , "blank", "blank"),
		array("blank" , "blank", "blank")
	);

	private static $ads;

	public static function getValues() {
		self::$ads = array(
			'schedule' => self::$adsSchedule,
			'news' => self::$adsNews,
			'charters' => self::$adsCharter
		);
		return self::$ads;
	}

}