<!DOCTYPE html>
<html lang="en">
  <head>
    <title><?php include 'title.php' ?></title>
    <?php include 'meta-keywords.php' ?>
    
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet" media="screen">
    <link href="css/smoothness/jquery-ui-1.10.3.custom.min.css" rel="stylesheet" media="screen"/>

    <link href="css/before-you-fly.css" rel="stylesheet" media="screen">
    <link href="css/commons.css" rel="stylesheet" media="screen">

    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,300' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css'>

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="js/assets/html5shiv.js"></script>
      <script src="js/assets/respond.min.js"></script>
    <![endif]-->
  </head>
  <body id="b4Ufly">
    
    <div id="login" class="Box">
      <?php include 'login.php' ?>
    </div>
    <header class="container">
      <?php include 'navbar.php' ?>
    </header>
    <div class="content">
    <div id="checkIn">
      <section class="container">
        <div class="col-xs-12">
          <h1>Check In</h1>
          <p>
            If you obtained an <em>e-ticket</em>, you should proceed directly to the check-in desk and present your confirmation/itinerary with booking reference together with your passport.
          </p>
          <p>Passengers are required to be <em>at the airport</em> to check-in at a minimum of <em>two hours prior</em> to your scheduled time of departure.</p>
          <p>
            All checked and carry-on baggage must be presented at the check-in desk, at the time of check-in. 
          </p>
          <p>
            Check-in closes forty five (45) minutes before departure. CJRP Travel reserves the right to cancel passenger reservations if not check-in at least forty five minutes (45) prior to the scheduled or posted departure time of the flight.
          </p>
          <p>
            When making bookings, passengers are responsible for allowing adequate time for baggage claim and rechecking if connecting to another carrier. We recommend at least 180 minutes, (3 Hours) between international connecting flights.
          </p>
          <p>
            Passengers who have checked-in for a flight and have received a boarding pass must present themselves at the departure gate and be ready to board their flight no later than thirty (30) minutes prior to departure. Passengers not in the boarding area by this specified time prior to scheduled departure are subject to seat cancellation.
          </p>
        </div>
      </section>
      <!-- IMG LINE -->
      <div class="img-line"></div>
    </div>
    <div id="documentation" class="odd">
      <section class="container">
        <div class="col-xs-12">
          <h1>Documentation</h1>
          <p>
            All passengers, including children, <em>are required a valid passport</em>, which must be presented at time of check-in.
          </p>
          <p>
            Passengers are advised to print out a copy of their e-ticket or itinerary as Immigration officials may require proof of an onward or return journey.
          </p>
          <p>
            <em>CJRP Travel</em>, Open Charter Flights are considered, International travel. 
          </p>
          <p>All customers are required to present proof of identity such as:</p>
          <ul>
            <li>Proof of citizenship such as a passport at the check-in counter.</li>
            <li>Visas as appropriate.  </li>
          </ul>
          <p>Passengers must also be in possession of a copy of their itinerary as proof of their onward or return journey.</p>
          <p>Passengers must keep proper documentation on their person during travel.</p>
          <p class="col-xs-12 col-md-6 col-md-offset-3">
            <strong>
              It is the passenger's responsibility to ensure that they have in their possession the correct documents needed for travel to any destination.
            </strong>
          </p>
        </div>
      </section>
      <!-- IMG LINE -->
      <div class="img-line"></div>
    </div>
    <div class="section" id="resa-change">
        <section class="container">
          <div class="col-xs-12">
            <h1>Reservation changes</h1>
            <p>
              <em>CJRP Travel</em> fares are non-refundable. Should you need to cancel your reservation, you may do so at least 24 hours prior to departure. You will be given credit in the amount paid for future travel on CJRP TRAVEL, subject to a USD $100 cancellation fee per person, each way.
            </p>
            <p>
              Should you need to change your reservation, you may do so at least 3 hours prior to departure, subject to a USD $45 change fee per person. Fare differences may apply. The amount originally paid will be applied to the purchase price of the new itinerary.
            </p>
            <p>
              24 HOUR CUT-OFF <br>
              <em>CJRP Travel</em> does not over sell flights. As such, your ticket comes directly out of inventory. Should you need to change or cancel your itinerary, it must be done within 3 hours of departure. Inside 3 hours prior to departure, your ticket is considered used and is not eligible for change or credit. Similarly, should you not show for your flight, your ticket is considered used and is not eligible for change, or credit.
          </p>
        </div>
        </section>
        <!-- IMG LINE -->
        <div class="img-line"></div>
    </div>
    <!-- SPECIAL SERVICES REQUEST -->
    <div class="odd" id="special-request">
      <section class="container">
        <div class="col-xs-12">
          <h1>Special Services Request</h1>
          <h3>Unaccompanied Minors</h3>
          <p>A child under the age of 12, travelling unaccompanied, requires a notarized letter from his/her parent or legal guardian giving permission for the minor to stay with host/hostess. The full name, the address and telephone number of the host/hostess must be included in the letter.</p>
          <p>Please note that no male other than a Father is allowed to receive minors and he must produce proof of paternity. A female occupant of the household is required to meet them.</p>

          <h3>Pets and Service Animals</h3>
          <p>Pets are defined as dogs, cats and domestic birds are not accepted on CJRP Travel Flights. </p>
        </div>
      </section>
      <!-- IMG LINE -->
      <div class="img-line"></div>
    </div>
    <!-- BAGGAGE -->
    <div class="" id="baggage">
        <section class="container">
          <h1>Baggage</h1>
          <div class="col-xs-12">  
              Checked baggage will, whenever possible, be carried on the same aircraft as you, unless we decide for safety, security or operational reasons to carry it on an alternative flight.              
          </div>
          <div class="col-xs-12 col-md-6">
            <h3>Baggage allowances</h3>
            <p>
              CJRP Travel baggage allowances and excess baggage policy is as follows; charges are calculated per-flight and will be collected at time of check-in.
            </p>
            <table class="table">
              <tbody>
                <tr>
                  <td rowspan="2" class="vert-middle">Checked bags</td>
                  <td>up to 50 lbs/23kg</td>
                  <td>51-70 lbs/23-32kg</td>
                </tr>
                <tr>
                  <td>Standard</td>
                  <td>Over Weight or Oversized</td>
                </tr>
                <tr>
                  <td>1st checked bag</td>
                  <td>Free</td>
                  <td rowspan="2" class="vert-middle">USD 40.00 flat rate</td>
                </tr>
                <tr>
                  <td>Extra bag(s)</td>
                  <td>USD 40.00</td>
                </tr>
              </tbody>
            </table>
          </div>

          <div class="col-xs-12 col-md-6">
            <h3>Check In &amp; cutoff times</h3>
            <table class="table">
              <tbody>
                <tr>
                  <td class="col-xs-6">Anguilla,(AXA)</td>
                  <td rowspan="3" class="col-xs-6 vert-middle"><strong>45 minutes</strong></td>
                </tr>
                <tr>
                  <td class="col-xs-6">St Kitts (SKB)</td>
                </tr>
                <tr>
                  <td class="col-xs-6">Tortola,(AXA)</td>
                </tr>
              </tbody>
            </table>
          </div>
  
          <div class="clearfix"></div>

          <h3>Baggage Limits &amp; allowances</h3>
          <div class="row">
            <div class="col-md-6">
              <p><strong>BAGGAGE RESTRICTIONS STRICTLY ENFORCED</strong></p>
              <p>BAGGAGE LIMITS: <em>ONE pieces</em> with a WEIGHT of <em>50 POUNDS</em></p>
            </div>
            <div class="col-md-6">
              BAGGAGE IN EXCESS OF THE PIECE AND/OR WEIGHT LIMIT WILL BE CARRIED ON A SPACE AVAILABLE/STANDBY BASIS AT A FLAT RATE OF <em>USD $40</em>.
            </div>
          </div>
          <br>
          <div class="row">
            <p class="col-xs-12 col-md-6 col-md-offset-3">
              <strong>CJRP TRAVEL WILL NOT BE RESPONSIBLE FOR THE COST OF TRANSPORTATION AND DELIVERY OF UNACCOMMODATED EXCESS BAGGAGE.</strong>
            </p>
          </div>
          <div class="row">
            <div class="col-md-6">
              <h3>Carry On</h3>
              <p>
                CARRY ON BAGGAGE CARRY ON ITEMS ARE LIMITED TO ONE PIECE. (BABY/CHILD CARE ITEMS EXCEPTED) CARRY ON ITEMS MUST BE OF REASONABLE SIZE (FULL SIZE LUGGAGE IS NOT ACCEPTABLE AS A "CARRY-ON" ITEM, FOR INSTANCE)
              </p>
              <p>
                ACCEPTANCE OF CARRY ON ITEMS IS SOLEY AT THE DISCRETION OF CJRP TRAVEL. 
              </p>
              <p>
                UNACCEPTABLE CARRY-ON ITEMS MUST BE CHECKED AS BAGGAGE AND ARE SUBJECT TO CJRP TRAVEL' CHECKED BAGGAGE LIMITS AND RESTRICTIONS.
              </p>
            </div>
            <div class="col-md-6">
              <h3>Limit of baggage liability</h3>
              <p>
                For most international travel (including domestic portions of international journeys) the liability limit is approximately <em>$9.07 USD per pound</em> ($20 USD per kilogram) for checked baggage and <em>$400 USD per passenger</em> for unchecked baggage (if attributable to the negligence of the carrier) unless a higher value is declared in advance and additional charges are paid.
              </p>
              <p>
                In addition, CJRP TRAVEL liability is limited to <em>30 pounds</em> (66 kilograms) ($272 USD) per checked bag.
              </p>
            </div>
          </div>
        </section>
        <div class="img-line"></div> 
    </div>
    <!-- BAGGAGE -->
    <div class="odd" id="security-tips">
        <section class="container">
          <h1>Security Tips</h1>

          <p>
            Know your carry on allowances and remember the facts with this quick-reference chart. 
            <a href="http://www.tsa.gov/traveler-information/3-1-1-carry-ons">3-1-1 for carry-on</a>.
          </p>
          <p>Please be aware that both your checked baggage and carry-on baggage may be subjected to security screening. </p>
          <p>There are some items which are prohibited in carry-on baggage and some items which are prohibited in checked baggage.</p>
          <p class="col-xs-12 col-sm-4"><em>Generally you are prohibited from carrying:</em></p>
            
          <ul class="col-xs-12 col-sm-8">
            <li><strong>Dangerous goods</strong></li>
            <li><strong>Restricted items such as flammable liquids</strong></li>
            <li><strong>Compressed gases</strong></li>
            <li><strong>Corrosive, magnetized or radioactive materials</strong></li>
            <li><strong>Toxic and infectious substances</strong></li>
            <li><strong>Sharp or other dangerous objects which could be used as weapons aboard the aircraft</strong></li>
          </ul>

          <p>
            To avoid delays during the passenger screening process, we recommend that you place items such as jewellery, keys, cell phones etc. in your carry on baggage and not on your person.
          </p>
          <p>
            Pack appropriately to avoid inconvenience and delays at security check points.
          </p>
        </section>
        <div class="img-line"></div> 
    </div>
    </div>
    <footer>
      <?php include 'footer.php' ?>
    </footer>

    <script src="js/jquery-1.10.1.min.js"></script>

    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>

    <script src="js/assets/respond.min.js"></script>
    <script src="js/jquery-ui-1.10.3.custom.min.js"></script>
    <script src="js/img-line.js"></script>
    <script src="js/b4ufly.js"></script>
    <!-- Placed at the end of the document so the pages load faster
    <script src="../../assets/js/holder.js"></script> -->
    <?php include_once("analyticstracking.php") ?>
  </body>
</html>