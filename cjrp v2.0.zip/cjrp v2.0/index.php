<!DOCTYPE html>
<html lang="en">
  <head>
    <title><?php include 'title.php' ?></title>
    <?php include 'meta-keywords.php' ?>
    
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet" media="screen">
    <link href="css/smoothness/jquery-ui-1.10.3.custom.min.css" rel="stylesheet" media="screen"/>
    <link href="css/index.css" rel="stylesheet" media="screen">
    <link href="css/commons.css" rel="stylesheet" media="screen">

    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,300' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css'>
    
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="js/assets/html5shiv.js"></script>
      <script src="js/assets/respond.min.js"></script>
    <![endif]-->
  </head>
  <body id="index">
    
    <div id="login" class="Box">
      <?php include 'login.php' ?>
    </div>
    <header class="container">
      <!-- Static navbar -->
      <?php include 'navbar.php' ?>
	<div class="pull-right" style="margin-top:-15px; margin-bottom:-10px;">
		<div class="g-plusone" data-size="medium" data-annotation="none"></div>
        <div class="fb-like" data-href="https://www.facebook.com/flycjrp" data-ref="cjrp_website" data-width="The pixel width of the plugin" data-height="The pixel height of the plugin" data-colorscheme="light" data-layout="button_count" data-action="like" data-show-faces="true" data-send="false"></div>
    </div>
    </header>
    <div class="container">
      <section class="row">
        <div class="col-xs-12 col-sm-6 col-md-4">
          <div class="" id="booking-form" >
            <div class="row">
              <ul id="booking-tab">
                <li class="active col-xs-4"><a href="#flight-tab">Flights</a></li>
                <li class="col-xs-4"><a href="#ferry-tab">Ferry</a></li>
                <li class="col-xs-4"><a href="#check-online">CheckIn</a></li>
              </ul>
            </div>
            <div class="tab-content">
              <div class="tab-pane active fade in" id="flight-tab">
                <!-- BOOKING FORM -->
                <?php include 'flight-booking.php' ?>
              </div>
              <div class="tab-pane fade" id="ferry-tab">
                 <?php include 'ferry-booking.php' ?>
              </div>
              <div class="tab-pane fade" id="check-online">
                  <?php include 'checkin.php' ?>
              </div>
            </div>            
          </div>
        </div> 
        <!--
        <div class="clearfix visible-sm"></div>    
        -->
        <div id="myCarousel" class="hidden-xs col-sm-6 col-md-8" >
          <div class="carousel slide">
            <ol class="carousel-indicators">
              <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
              <li data-target="#myCarousel" data-slide-to="1"></li>
              <li data-target="#myCarousel" data-slide-to="2"></li>
              <li data-target="#myCarousel" data-slide-to="3"></li>
              <li data-target="#myCarousel" data-slide-to="4"></li>           
            </ol>
            <!-- Carousel items -->
            <div class="carousel-inner">
              <div class="active item">
                <img src="img/slide/slide1.jpg">
                <div class="carousel-caption">
                      <div>The cheaper way to book..</div>
                      <div class="small">Some people dream of  success. We make it happen.</div>
                  </div>
              </div>
              <div class="item">
                <img src="img/slide/slide2.jpg">
                <div class="carousel-caption">
                      <div>The cheaper way to book..</div>
                      <div class="small">Some people dream of  success. We make it happen.</div>
                  </div>            
              </div>
              <div class="item">
                <img src="img/slide/slide3.jpg">
                <div class="carousel-caption">
                      <div>The cheaper way to book..</div>
                      <div class="small">Some people dream of  success. We make it happen.</div>
                  </div>            
              </div>
              <div class="item">
                <img src="img/slide/slide4.jpg">
                <div class="carousel-caption">
                      <div>The cheaper way to book..</div>
                      <div class="small">Some people dream of  success. We make it happen.</div>
                  </div>            
              </div>
              <div class="item">
                <img src="img/slide/slide5.jpg">
                <div class="carousel-caption">
                      <div>The cheaper way to book..</div>
                      <div class="small">Some people dream of  success. We make it happen.</div>
                  </div>            
              </div>        
            </div>
            <!-- Carousel nav -->
            <a class="left carousel-control hidden-sm" href="#myCarousel" data-slide="prev"><span class="glyphicon glyphicon-chevron-left"></span></a>
            <a class="right carousel-control hidden-sm" href="#myCarousel" data-slide="next"><span class="glyphicon glyphicon-chevron-right"></span></a>
          </div>
        </div>
      </section>
      <section id="other-booking" class="row">
        <div class="col-md-12">
          <h1>Our services</h1>          
        </div>  
        <div class="col-md-4">
          <div class="thumbnails">
            <div class="imgOtherBooking">
              <img src="img/booking-hotel.jpg" alt="hotel booking" class="img-thumbnail img-responsive">
            </div>
            <div class="caption">
              <h2 class="container longer">Hotels &amp; Villas</h2>
              <p>You have an idea about where you want your vacation to be? Need some help getting a hotel? </p>
              <p>We are the experts at helping our clients make their vacation a reality. We  look forward to recommending a hotel that suits your needs and caters to your expectations</p>
            </div>
            <a href="car-and-hotel-booking.php" class="btn btn-default">Book now</a>
          </div>
        </div>
        <div class="col-md-4">
          <div class="thumbnails">
            <div class="imgOtherBooking">
              <img src="img/booking-car.jpg" alt="car rental" class="img-thumbnail img-responsive">
            </div>
            <div class="caption">
              <h2 class="container">Cars</h2>
              <p>CJRP Travel has partnered with several car rental brands to offer discounted rental rates anywhere in the world, to our clients.</p>
              <p> Book your next regional travel ticket with us and enjoy discounted vehicle rental rates from our partners.</p>
            </div>
            <a href="car-and-hotel-booking.php" class="btn btn-default">Book now</a>
          </div>          
        </div>
        <div class="col-md-4">
          <div class="thumbnails">
            <div class="imgOtherBooking">
              <img src="img/booking-cruise.jpg" alt="cruise booking" class="img-thumbnail img-responsive">
            </div>
            <div class="caption">
              <h2 class="container">Cruises</h2>
              <p>Because it's more than just another vacation vacation -it's an experience like none other. </p>
              <p>Not only are there lots of amazing things to do onboard but there are also an endless number of fun onshore activities, too. On one cruise you will visit different destinations.</p>
            </div>
           <a href="car-and-hotel-booking.php" class="btn btn-default">Book now</a>
          </div>
        </div>
      </section>
      <section>
        <div class="row">
          <div class="col-xs-12 col-sm-6 col-md-8">
            <h2 class="col-md-12">The caribbean can be yours!</h2>
            <div class=" clearfix" id="news">
              <div class="visible-md visible-lg col-md-6">
                <img src="img/caribbean.jpg" alt="offices" class="img-responsive img-thumbnail">
              </div>
              <div class="col-sm-12 col-md-6">
                <p>CJRP travel, now offering daily flight to :</p>
                <p>
                  <em>Anguilla</em>, <em>St Kitts</em>, &amp; <em>Tortola</em>
                </p>
                <br>
                <p>
                  <em>One way's</em> starting from <strong><em>$69.99 USD</em></strong> <br/>
                  <em>Round trip's</em> starting from <strong><em>$189.99 USD.</em></strong>
                </p>            
              </div>
            </div>
          </div>
          <!--
          <div class="clearfix visible-xs">&nbsp;</div> 
-->
          <div class="col-xs-12 col-sm-6 col-md-4" id="testimonial">
            <h2>Slogan</h2>
              <div class="col-md-12">
                <div id="quote">
                  <em>
                    &laquo; Need an airline to get you there on time? <br> Choose CJRP Travel where it's safe, affordable and worth every dime &raquo;
                  </em>
                </div>
                <div id="written-by">
                  Written by <strong>Karece Webster</strong>
                </div>
              </div>
          </div>
        </div>
      </section>
    </div>
    <!-- IMG LINE -->
    <div class="img-line last"></div>
    <footer>
      <?php include 'footer.php' ?>
    </footer>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) 
    <script src="//code.jquery.com/jquery.js"></script>-->
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <!--
    <script src="js/jquery-1.10.1.min.js"></script>
    -->
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-ui-1.10.3.custom.min.js"></script>

    <script src="js/index.js"></script>
    <script src="js/flight-booking.js"></script>
    <script src="js/img-line.js"></script>

    <div id="fb-root"></div>
    <script>
    	// FACEBOOK
      (
        function(d, s, id) {
          var js, fjs = d.getElementsByTagName(s)[0];
          if (d.getElementById(id)) return;
          js = d.createElement(s); js.id = id;
          js.src = "//connect.facebook.net/en/all.js#xfbml=1";
          fjs.parentNode.insertBefore(js, fjs);
        }
        (document, 'script', 'facebook-jssdk')
      );
    </script>
    <!-- G+ > Place this tag after the last +1 button tag. -->
	<script type="text/javascript">
	  (function() {
	    var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
	    po.src = 'https://apis.google.com/js/plusone.js';
	    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
	  })();
	</script>
    <!-- Placed at the end of the document so the pages load faster
    <script src="../../assets/js/holder.js"></script> -->
    <?php include_once("analyticstracking.php") ?>
  </body>
</html>