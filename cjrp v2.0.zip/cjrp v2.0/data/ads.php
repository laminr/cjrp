<?php
$adsSchedule = Array(
	Array("dolphin-large.jpg" , "dolphin-small.jpg", "Dolphin swim special"),
	Array("blank" , "blank", "blank"),
	Array("blank" , "blank", "blank"),
	Array("blank" , "blank", "blank")
);

$adsNews = Array(
	Array("blank" , "blank", "blank"),
	Array("blank" , "blank", "blank"),
	Array("blank" , "blank", "blank"),
	Array("blank" , "blank", "blank")
);

$adsCharter = Array(
	Array("blank" , "blank", "blank"),
	Array("blank" , "blank", "blank"),
	Array("blank" , "blank", "blank")
);


$ads = Array(
	'schedule' => $adsSchedule,
	'news' => $adsNews,
	'charters' => $adsCharter
);