<?php
// PHP Solution 1
$route_1 = Array(
	Array('Tortola', 'St. Kitts'),
	Array('Monday', '08:10', '09:00', 'CJ231', 'Direct', '15/12/13', '30/04/14'),
        Array('Wednesday', '08:10', '09:00', 'CJ508', 'Direct', '15/11/13', '15/07/14'),
        Array('Friday', '08:10', '09:00', 'CJ231', 'Direct', '15/12/13', '30/04/14'),
	Array('Saturday', '08:10', '09:00', 'CJ508', 'Direct', '15/11/13', '15/07/14')
);

// PHP Solution 2
$route_2 = Array(
	Array('St. Kitts', 'Tortola'),
	Array('Monday', '11:00', '11:50', 'CJ232', 'Direct', '15/12/13', '30/04/14'),
        Array('Wednesday', '11:00', '11:50', 'CJ509', 'Direct', '15/11/13', '15/07/14'),
        Array('Friday', '11:00', '11:50', 'CJ232', 'Direct', '15/12/13', '30/04/14'),
	Array('Saturday', '11:00', '00:50', 'CJ509', 'Direct', '15/11/13', '15/07/14')
);
$route_3 = Array(
	Array('St. Maarten', 'St. Kitts'),
	Array("Monday", "10:20", "10:40", "CJ232", "Direct","15/12/13","30/04/14"),
        Array("Wednesday", "10:20", "10:40", "CJ509", "Direct","15/11/13","15/07/14"),
        Array("Friday", "10:20", "10:40", "CJ232", "Direct","15/12/13","30/04/14"),
	Array("Saturday", "10:20", "10:40", "CJ509", "Direct","15/11/13","15/07/14")
);
$route_4 = Array(
	Array('St. Kitts', 'St. Maarten'),
	Array("Monday", "09:15", "09:35", "CJ231", "Direct","15/12/13","30/04/14"),
        Array("Wednesday", "09:15", "09:35", "CJ508", "Direct","15/11/13","15/07/14"),
        Array("Friday", "09:15", "09:35", "CJ231", "Direct","15/12/13","30/04/14"),
	Array("Saturday", "09:15", "09:35", "CJ508", "Direct","15/11/13","15/07/14")
);
$route_5 = Array(
	Array('Anguilla', 'St. Kitts'),
        Array("Monday", "10:00", "10:30", "CJ722", "Direct","01/11/13","30/04/14"),
        Array("Monday", "15:50", "16:20", "CJ730", "Direct","13/12/13","30/04/14"), 
        Array("Wednesday", "10:00", "10:30", "CJ722", "Direct","13/12/13","30/04/14"),
        Array("Wednesday", "15:50", "16:20", "CJ730", "Direct","13/12/13","30/04/14"),
        Array("Friday", "10:00", "10:30", "CJ722", "Direct","13/12/13","30/04/14"),
        Array("Friday", "15:50", "16:20", "CJ730", "Direct","01/11/13","30/04/14"),                                                                                             Array("Saturday", "10:00", "10:30", "CJ722", "Direct","13/12/13","30/04/14"),
        Array("Saturday", "15:50", "16:20", "CJ730", "Direct","13/12/13","30/04/14"),         
);
$route_6 = Array(
	Array('St. Kitts', 'Anguilla'),
        Array("Monday", "10:55", "11:25", "CJ723", "Direct","01/11/13","30/04/14"),
        Array("Monday", "16:35", "17:55", "CJ733", "Direct","13/12/13","30/04/14"),
        Array("Wednesday", "10:55", "11:25", "CJ723", "Direct","13/12/13","30/04/14"),
        Array("Wednesday", "16:35", "17:55", "CJ733", "Direct","13/12/13","30/04/14"),
        Array("Friday", "10:55", "11:25", "CJ723", "Direct","13/12/13","30/04/14"),
        Array("Friday", "16:35", "17:55", "CJ733", "Direct","01/11/13","30/04/14"),
        Array("Saturday", "10:55", "11:25", "CJ723", "Direct","13/12/13","30/04/14"),
        Array("Saturday", "16:35", "17:55", "CJ733", "Direct","13/12/13","30/04/14"),
); 

$routes[] = $route_1;
$routes[] = $route_2;
$routes[] = $route_3;
$routes[] = $route_4;
$routes[] = $route_5;
$routes[] = $route_6;