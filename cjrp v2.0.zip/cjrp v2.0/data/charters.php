<?php

$charters = Array(
	'Barbados',
	'Jamaica',
	'Trinidad &amp; Tobago',
	'St Croix',
	'Guadeloupe',
	'Martinique',
	'Bahamas',
	'St. Barts',
	'Aruba',
	'Grenada',
	'St. Vincent',
	'Cayman Islands',
	'Antigua (ANU)',
	'Anegada Airport (NGD)',
	'Anguilla (AXA)',
	'Dominica (DOM)',
	'Puerto Rico (SJU)',
	'St. Kitts (SKB)',
	'Tortola (EIS)',
	'St. Maarten (SXM)',
	'St. Thomas (STT)',
	'Nevis (NEV)',
	'Virgin Gorda Airport (VIJ)',
	'USA',
	'Canada',
	'France',
	'United Kingdom'
);

sort($charters);