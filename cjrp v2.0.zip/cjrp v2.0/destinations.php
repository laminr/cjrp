<?php
	$where = '';
	if(isset($_GET['is'])) {
		$where = strip_tags($_GET['is']);
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title><?php include 'title.php' ?></title>
  <?php include 'meta-keywords.php' ?>
  
  <!-- Bootstrap -->
  <link href="css/bootstrap.min.css" rel="stylesheet" media="screen">
  <link href="css/commons.css" rel="stylesheet" media="screen">
  <link href="css/destinations.css" rel="stylesheet" media="screen">

  <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,300' rel='stylesheet' type='text/css'>
  <link href='http://fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css'>
  <link href='http://fonts.googleapis.com/css?family=Ruthie' rel='stylesheet' type='text/css'>

  <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="js/assets/html5shiv.js"></script>
      <script src="js/assets/respond.min.js"></script>
      <![endif]-->
    </head>
    <body id="<?php echo ($where=='' ? 'destinations' : 'dest-x'); ?>">

      <div id="login" class="Box">
        <?php include 'login.php' ?>
      </div>
      <header class="container">
        <?php include 'navbar.php' ?>
      </header>
      <div id="content" class="container">
        <div class="">
			<?php if($where != '') {  
				include "destination-".$where.".php";
			} else { ?>
			<div class="col-xs-12 col-md-12">			
				<h1>Destinations</h1>
				<!-- generic part -->
				<div class="onePlace col-md-4" id="saintbarth">
				  <h3>Saint Barth</h3>
				  <div class="row">
					<div class="col-md-12">
					  <div class="row">
						<div class="col-md-6">Capital </div><div class="col-md-6">Gustavia</div>
						<div class="col-md-6">Airport </div><div class="col-md-6">St Barthelemy</div>
						<div class="col-md-6">Land Area </div><div class="col-md-6">8.5 sq. miles</div>
						<div class="col-md-6">Population </div><div class="col-md-6">8,902</div>
						<div class="col-md-6">Currency </div><div class="col-md-6">Euro</div>
						<div class="col-md-6">St. Barths Tourism Board</div>
						<div class="col-md-6">0590 27 8727</div>
						<div class="col-md-8 col-md-offset-2">www.saintbarth-tourisme.com</div>
					  </div>
					</div>
				  </div>                          
				</div>                 
				<div class="onePlace col-md-4" id="stkitts">
				  <h3>St. Kitts</h3>
				  <div class="row">
					<div class="col-md-12">
					  <div class="row">
						<div class="col-md-6">Capital </div><div class="col-md-6">Basseterre</div>
						<div class="col-md-6">Airport </div><div class="col-md-6">Robert L. Bradshaw</div>
						<div class="col-md-6">Land Area </div><div class="col-md-6">68 sq. miles</div>
						<div class="col-md-6">Population </div><div class="col-md-6">Approx 35,000</div>
						<div class="col-md-6">Currency </div><div class="col-md-6">EC dollar</div>
						<div class="col-md-6">St Kitts Dept. of Tourism</div>
						<div class="col-md-6">(869) 465-4040</div>
						<div class="col-md-6 col-md-offset-3">www.stkitts-tourism.com</div>
					  </div>
					</div>
				  </div>
				</div>
				<div class="onePlace col-md-4" id="stmaarten">
				  <h3>Sint Maarten</h3>
				  <div class="row">
					<div class="col-md-12">
					  <div class="row">
						<div class="col-md-6">Capital </div><div class="col-md-6">Phillipsburg</div>
						<div class="col-md-6">Airport </div><div class="col-md-6">Princess Juliana Intl.</div>
						<div class="col-md-6">Land Area </div><div class="col-md-6">16 sq. miles</div>
						<div class="col-md-6">Population </div><div class="col-md-6">Approx. 39,00</div>
						<div class="col-md-6">Currency </div><div class="col-md-6">Netherlands Ant. Guilder</div>
						<div class="col-md-7">St. Maarten Tourist Bureau</div>
						<div class="col-md-5">011 (599) 542 2337</div>
						<div class="col-md-6 col-md-offset-3">www.st-maarten.com</div>
					  </div>
					</div>
				  </div>
				</div>
				<div class="onePlace col-md-4" id="tortola">
				  <h3>Tortola</h3>
				  <div class="row">
					<div class="col-md-12">
					  <div class="row">
						<div class="col-md-6">Capital </div><div class="col-md-6">Road Town</div>
						<div class="col-md-6">Airport </div><div class="col-md-6">T.B. Lettsome Intl.</div>
						<div class="col-md-6">Land Area </div><div class="col-md-6">24 sq. miles</div>
						<div class="col-md-6">Population </div><div class="col-md-6">20,000</div>
						<div class="col-md-6">Currency </div><div class="col-md-6">U.S. dollar</div>
						<div class="col-md-6">The BVI Tourist Board</div>
						<div class="col-md-6">(284) 494-3134</div>
						<div class="col-md-8 col-md-offset-2">www.bvitourism.com</div>
					  </div>
					</div>
				  </div>
				</div>
			</div>		
			<?php } ?>
		</div>
      </div>
      <!-- IMG LINE -->
      <div class="img-line last"></div>
      <footer>
        <?php include 'footer.php' ?>
      </footer>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) 
    <script src="//code.jquery.com/jquery.js"></script>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>-->
    <!---->
    <script src="js/jquery-1.10.1.min.js"></script>

    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/img-line.js"></script>
    <!-- Placed at the end of the document so the pages load faster
    <script src="../../assets/js/holder.js"></script> -->
    <?php include_once("analyticstracking.php") ?>
  </body>
  </html>