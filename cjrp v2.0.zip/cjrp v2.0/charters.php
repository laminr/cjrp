<?php 
  require 'class/tools.class.php';
  require 'class/handleCharterForm.class.php';

  include_once 'data/ads.php';
  $pageName = 'charters';
	
  session_start ();

  // adresse de la page
  $current_url = explode("?", $_SERVER['REQUEST_URI']);;
  $webPageUrl = 'http://'.$_SERVER['HTTP_HOST'] . $current_url[0] ;

  $isGettingEmail = false;

  if ( isset ($_POST['airport-from']) 
    AND isset ($_POST['airport-to'])  
    AND isset ($_POST['departure-date']) 
    AND isset ($_POST['last-name'])
    ) {
      $handleCharterForm = new handleCharterForm();
      $isGettingEmail = $handleCharterForm->processEmail('charter-request-form');
  }
    //var_dump($isGettingEmail);
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title><?php include 'title.php' ?></title>
    <?php include 'meta-keywords.php' ?>
    
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet" media="screen">

    <link href="css/charters.css" rel="stylesheet" media="screen">
    <link href="css/commons.css" rel="stylesheet" media="screen">

    <link href="css/smoothness/jquery-ui-1.10.3.custom.min.css" rel="stylesheet" media="screen"/>
    <link href="css/bootstrap-timepicker.min.css" rel="stylesheet" media="screen"/>

    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,300' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css'>

    <script src="js/email.js"></script>

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="js/assets/html5shiv.js"></script>
      <script src="js/assets/respond.min.js"></script>
    <![endif]-->
    <?php 
      $newToken = Tools::generateFormToken('charter-request-form'); 
    ?>
  </head>
  <body id="charters">
    
    <div id="login" class="Box">
      <?php include 'login.php' ?>
    </div>
    <header class="container">
      <?php include 'navbar.php' ?>
    </header>
    <div class="container">
      <div class="row">
        <div class="col-xs-12 col-md-8">
          <h1>Charters</h1>
          <p>
            <em>CJRP Travel</em> can organise any charter, whether it be Air or Sea to suit your needs.
          </p>
          <p>
            Please fill out the request form below. We will get back to you within one to two business days.
          </p>
          <!-- CHARTER REQUEST FORM -->
          <?php include 'charter-request.php' ?>
        </div>
        <!-- ADS -->
        <div class="col-md-4 adsColumn">
          <h1>Partners</h1>
		  <?php 
		   if(isset($ads[$pageName])) {
			$theAds = $ads[$pageName];
			foreach($theAds as $value) {
				if ($value[0] == 'blank') { ?>
					<div class="advert well col-md-12">
            <div>
						  Your ads here <br/> 360 x 240 (thumbnail) <br/> 750 x 500 full screen
            </div>
					</div>
				<?php 
				} else { 
					$anAd = $value;
				?>
					<div class="advert col-md-12">
						<a class="fancybox" rel="ads" href="img/ads/<?php echo $anAd[0]; ?>" title="<?php echo $anAd[2]; ?>">
						  <img src="img/ads/<?php echo $anAd[1]; ?>" alt="<?php echo $anAd[2]; ?>" class="img-thumbnail" />
						</a>
					</div>
				<?php 
				} ?>
 		  <?php 
			}
		  }
		  ?>          
        </div>
      </div>
      
    </div>
    <!-- IMG LINE -->
    <div class="img-line"></div>    
    <footer>
      <?php include 'footer.php' ?>
    </footer>

    <!-- modal -->
    <div id="modal-message" class="modal fade">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" data-hidden="true">&times;</button>
            <h4 class="modal-title">Charter booking request</h4>
          </div>
          <div class="modal-body">
            <p>Thank you for choosing CJRP Travel.</p>
            <p>We have received your charter request. Please allow us 1 to 2 business days to complete your quotation.</p>
            <br/>
            <p>If this charter is an emergency, please contact us via phone, for immediate assistance.</p>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
          </div>
        </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->


    <script src="js/jquery-1.10.1.min.js"></script>

    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-ui-1.10.3.custom.min.js"></script>
    <script src="js/bootstrap-timepicker.min.js"></script>

    <script src="js/charters.js"></script>
    <script src="js/img-line.js"></script>


    <?php if ($isGettingEmail==true) { ?>
      <script type="text/javascript">
        //$('#modal-message').modal();
        $('#modal-message').modal({
          keyboard: true
        });
      </script>
    <?php } ?>

    <?php include_once("analyticstracking.php") ?>
  </body>
</html>