<!DOCTYPE html>
<html lang="en">
<head>
  <title><?php include 'title.php' ?></title>
  <?php include 'meta-keywords.php' ?>
  
  <!-- Bootstrap -->
  <link href="css/bootstrap.min.css" rel="stylesheet" media="screen">
  <link href="css/commons.css" rel="stylesheet" media="screen">

  <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,300' rel='stylesheet' type='text/css'>
  <link href='http://fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css'>

  <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="js/assets/html5shiv.js"></script>
      <script src="js/assets/respond.min.js"></script>
      <![endif]-->
    </head>
    <body id="about-us">

      <div id="login" class="Box">
        <?php include 'login.php' ?>
      </div>
      <header class="container">
        <?php include 'navbar.php' ?>
      </header>
      <div class="container">
        <div class="row">
          <div id="handling-agent">
            <div class="col-xs-12 col-md-12">
              <h1>Handling Agent</h1>
              <p>
                CJRP Travel Aviation Services has been established since November 15th, 2012.                
              </p>
              <p>
                The purpose for the formation of the company was to provide complete passenger handling services to CJRP Travel Flights &amp; CJRP Travel Partners Operations.
              </p>
              <h3>Mission Statement</h3>
              <p>
                The mission of our company is to provide quality customer service to our clients by applying all resources available to achieve a higher customer service standard.
              </p>
            </div>
            <div class="col-md-4">
              <h3>Employees</h3>
              <strong>
                Required Employee Training
              </strong>
              <ul>
                <li>Dangerous Good Training</li>
                <li>NATA Training</li>
                <li>Security Training</li>
                <li>Customer Service Training</li>
                <li>Basic Check-in Training </li>
              </ul>          
            </div>
            <div class="col-md-4">
              <h3>Airline Business Partners</h3>
              <ul>
                <li>Anguilla Air Services</li>
                <li>BVI Airways</li>
                <li>Fly Bvi</li>
                <li>Tradewind Aviation</li>
                <li>Vi Airlink</li>
              </ul>
            </div>
            <div class="col-md-4">
              <h3>Offices</h3>
              <strong><em>CJRP Travel</em></strong>
              <div>RLB International Airport</div>
              <div>Tel: 869-465-2577</div>
            </div>
          </div>
        </div>
      </div>
      <!-- IMG LINE -->
      <div class="img-line"></div>

      <div class="container">      
        <!-- TRAVEL AGENCY -->
        <div id="travel-agency">
          <div class="col-xs-12 col-md-8">
            <h1>Travel Agency</h1>
            <p>
              CJRP Travel Agency was formed in 2012 on the beautiful island of Anguilla. Since then, we have become one of the leading travel agencies in Anguilla.
            </p>
            <p>
              Our offices are located in South Hill, making a left at Greig's Trucking, onto the Spanish Town Road,(if travelling from the east and vice versa from the opposite direction).
            </p>
            <h3>Our team</h3>
            <p>
              We have a dedicated team of travel professionals with a combined experience in the tourism industry for over 20 years, who are always ready and willing to assist.
            </p>

            <h3>Ownership</h3>
            <p> 
              CJRP Travel is owned and operated by CJRP Group Anguilla Limited. We have a combined experience of over 10 years in the industry. Running CJRP Travel has been both our business and our hobby; we are reliable and trustworthy and have earned a reputation for excellence.
            </p>
          </div>
          <div class="col-xs-12 col-md-4" id="travel-agency">
            <h3>What we do</h3>
            <p>
              We are a full service travel agency and provide the following services:
            </p>
            <ol>
              <li>Airline Tickets</li>
              <li>Car Rentals</li>
              <li>Transfer Services</li>
              <li>Hotels</li>
              <li>Limousine Service</li>
              <li>Cruises</li>
              <li>Group Travel</li>
              <li>Incoming and Outgoing Tours</li>
              <li>Destination Management Services</li>
              <li>Weddings</li>
              <li>Special Events</li>
            </ol>
          </div>
        </div>
      </div>
        <!-- IMG LINE -->
      <div class="img-line"></div>

      <div class="container">
        <!-- TOUR OPERATOR -->
        <div id="tour-operator">
          <div class="col-xs-12">
            <h1>Tour Operator</h1>
            <p><em>CJRP Travel Tours</em> was created to respond to the expanding charter holiday industry and demand for faster travel in the Caribbean. </p>
            <p>
              <em>CJRP Travel Tour Operator Department</em> was formed in July 2012 and started its open charter operation, November 2012.  <em>CJRP Travel Tours</em> is now one of the leading scheduled business &amp; leisure tour operators at its key base in the Caribbean.
            </p>
              Over the past few months, our services have expanded tremendously, offering direct flight services to <em>Anguilla</em>, <em>Antigua</em>, <em>St. Maarten</em>, <em>St. Kitts </em>&amp; <em>Tortola</em>, with occasional direct charter services to <em>Barbados</em>, <em>St. Lucia</em> &amp; <em>Dominica</em>.
          </div>
        </div>
      </div>
	<!-- IMG LINE -->
	<div class="img-line last"></div>
	
	<footer>
	  <?php include 'footer.php' ?>
	</footer>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) 
    <script src="//code.jquery.com/jquery.js"></script>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>-->
    <!---->
    <script src="js/jquery-1.10.1.min.js"></script>

    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/img-line.js"></script>
    <!-- Placed at the end of the document so the pages load faster
    <script src="../../assets/js/holder.js"></script> -->
    <?php include_once("analyticstracking.php") ?>
  </body>
  </html>