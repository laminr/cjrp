<div class="row col-xs-12">
  <h1>Welcome to <span class="title-cursive">Puerto Rico</span></h1>
</div>
<div class="row">
  <div class="col-md-8">
	<p>
	  <em>Puerto Rico</em>, officially known as the <em>Commonwealth of Puerto Rico</em> (Estado Libre Asociado de Puerto Rico), is an unincorporated territory of the United States
	</p>
	<p>
	  Puerto Rico (Spanish for "rich port") cosists of an archipelago that includes the main island of Puerto Rico and several islands: <em>Vieques</em>, <em>Culebra</em>, <em>Mona</em> and numerous islets.
	</p>
	<p>
	  The island of Puerto Rico is a very popular tourist destination because of its location, rich history and warm atmostphere.
	</p>
	<p>
	  The territory is very mountainous (covering about 60%), except in the regional coasts, but Puerto Rico offers <em>astonishing variety</em>: rain forest, deserts, beaches, caves, oceans and rivers.
	</p>
	<p>
	  It is almost rectangular in shape, approximately 100 miles long by 35 miles wide and is the smallest and the most eastern island of the Greater Antilles (Cuba, Hispaniola, Jamaica and Puerto Rico).  
	</p>
	<p>
	  Puerto Rico is close to the <em>deepest submarine depression</em> in the North Atlantic Ocean. The deepest point in the Atlantic Ocean, the Milwaukee Depth, lies within the Puerto Rico Trench, at a depth of 27,493 feet (8,380 meters)
	</p>
	
	<div class="row dest-info">
	  <div class="col-xs-12">
		<div class="row">
		  <div class="col-xs-6">Capital: </div><div class="col-xs-6">San Juan</div>
		  <div class="col-xs-6">Airport: </div><div class="col-xs-6">Luis Munoz Marin Intl</div>
		  <div class="col-xs-6">Land Area: </div><div class="col-xs-6">3514 sq. Miles</div>
		  <div class="col-xs-6">Population: </div><div class="col-xs-6">Approx. 3,900,000</div>
		  <div class="col-xs-6">Currency: </div><div class="xs-md-6">U.S. dollar</div>
		  <div class="col-xs-12">Puerto Rico Tourism Company</div>
		  <div class="col-sm-6 col-sm-offset-3">
		  	<a href="http://www.gotopuertorico.com" target="_blank">www.gotopuertorico.com</a>
		  </div>
		</div>
	  </div>
	</div>
  </div>
  <div class="col-sm-12 col-md-4">
	<div class="row">
	  <div class="dest-img-line col-xs-6 col-md-12">
		<img src="img/destinations/puertorico_1.jpg" alt="Anguilla hotel" class="img-thumbnail"/>
	  </div>
	  <div class="dest-img-line col-xs-6 col-md-12">
		<img src="img/destinations/puertorico_2.jpg" alt="Anguilla beach" class="img-thumbnail"/>
	  </div> 
	</div>
  </div>
</div>