<!-- https://booksecure.cjrptravel.com/process/search -->
<form role="form" class="form-horizontal" id="ferry-booking-form" action="https://booksecure.cjrptravel.com/process/search" method="post">
  <div id="ferry-route" class="row lines">
    <div>
      <div class="col-md-4 control-label"> Ferrying from</div>
      <div class="col-md-8">
        <select name="origin" id="origin"  class="form-control" onchange="javascript:updateDestination(this.value)">
          <option value=''></option>
          <option value="BPF" selected="selected">Anguilla (BPF)</option>
          <option value="SXM">St. Maarten (SXM)</option>
        </select>
      </div>
    </div>
    <div>
      <div class="col-md-4 control-label">Going to</div>
      <div class="col-md-8">
        <select name="dest" id="dest" class="form-control">
          <option value=''></option>
          <option value="BPF">Anguilla (BPF)</option>
          <option value="SXM" selected="selected">St. Maarten (SXM)</option>
        </select>
      </div>
    </div>
  </div>
  <div class="row lines">
    <div class="col-xs-12 col-md-4 control-label">Trip</div>
    <div class="checkbox col-xs-6 col-md-4">
      <label>
        <input type="radio" name="return" value="1" checked="checked" />&nbsp;round trip
      </label>
    </div>
    <div class="checkbox col-xs-6 col-md-4">
      <label>
        <input type="radio" name="return" value="0" />&nbsp; One-Way
      </label>
    </div>
  </div>
  <div class="row lines">
      <div class="col-xs-12 col-md-4 control-label">Flexible</div>
      <div class="checkbox col-xs-6 col-md-4">
        <label>
          <input type="radio" name="selectedSearchType" value="FLEXIBLE" checked="checked"/>&nbsp;Yes
        </label>
      </div>
      <div class="checkbox col-xs-6 col-md-4">
        <label>
          <input type="radio" name="selectedSearchType" value="FIXED"  />&nbsp;No
        </label>
      </div>
  </div>
  <div id="dates" class="row lines">
    <div class="col-md-4 control-label">Dates</div>
    <div class="col-xs-12 col-md-4 date-selection-depart">
      <!-- departing date 
      <div for="depart_date">Outbound</div>-->
      <input id="ferry-depart-date" name="depart_date" class="col-xs-12 form-control datepicker" size="16" type="text" autocomplete="off" placeholder="departing">
    </div>
    <div class="col-xs-12 col-md-4 date-selection-return">
      <!-- returning date 
      <div for="return_date">Return</div>-->
      <input id="ferry-return-date" name="return_date" class="col-xs-12 form-control datepicker" size="16" type="text" autocomplete="off" placeholder="returning">
    </div>
  </div>
  <div id="pax" class="row lines">
      <input type="hidden" name="passengers" id="passengers" value="" />
      <div class="col-md-3">
          <label>Adults</label>
          <select name="adult_passengers" id="adult_passengers" class="form-control" onchange="javascript:udpatePaxTotalNbr()">
            <?php for ($i=1; $i <= 10; $i++) { ?>
              <option value="<?php echo $i ?>"><?php echo $i ?></option>
            <?php } ?>
          </select>
      </div>
      <div class="col-md-3">
          <label data-toggle="tooltip" title="2-11 years">Children*</label>
          <select name="child_passengers" id="child_passengers" class="form-control" onchange="javascript:udpatePaxTotalNbr()">
            <?php for ($i=0; $i <= 10; $i++) { ?>
              <option value="<?php echo $i ?>"><?php echo $i ?></option>
            <?php } ?>
          </select>                      
      </div>
      <div class="col-md-3">
          <label data-toggle="tooltip" title="60 or greater">Seniors*</label>
          <select name="senior_passengers" id="senior_passengers" class="form-control" onchange="javascript:udpatePaxTotalNbr()">
            <?php for ($i=0; $i <= 10; $i++) { ?>
              <option value="<?php echo $i ?>"><?php echo $i ?></option>
            <?php } ?>
          </select>                      
      </div>
      <div class="col-md-3">
          <label data-toggle="tooltip" title="under 2 years">Infant*</label>
          <select name="infant_passengers" id="infant_passengers" class="form-control" onchange="javascript:udpatePaxTotalNbr()">
            <?php for ($i=0; $i <= 10; $i++) { ?>
              <option value="<?php echo $i ?>"><?php echo $i ?></option>
            <?php } ?>

          </select>                      
      </div>
  </div>
  <div class="row lines">
    <div class="col-md-4 control-label">Promo code</div>
    <div class="col-md-8">
      <input type="text" name="promo_code" class="form-control" />
    </div>
  </div>
  <div id="submit-flight">
    <button type="submit" class="btn btn-default pull-right">Submit</button>
  </div>
</form>