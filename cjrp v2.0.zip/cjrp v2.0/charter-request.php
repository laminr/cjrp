<?php include_once 'data/charters.php'; ?>

<div>
  <form role="form" class="form-horizontal" id="charter-request-form" action="" method="POST">
    <h2>
      Travel information
      <div id="btn-roundtrip" class="btn-group pull-right">
        <button id="roundtrip-choice" type="button" class="btn btn-primary" onclick="javascript:chooseRoundtrip(true)">Roundtrip</button>
        <button id="oneway-choice" type="button" class="btn btn-default" onclick="javascript:chooseRoundtrip(false)">One-Way</button>
      </div>
    </h2>
    <input type="hidden" name="isRoundtrip" id="isRoundtrip" value="true" />
    <div class="row">
      <div class="col-md-6">
        <h3>Departing</h3>
        <div class="row">
          <div class="col-md-5 control-label">Departure date</div>
          <div class="col-xs-12 col-md-7">
            <input id="departureDate" name="departure-date" class="form-control datepicker" autocomplete="off" size="16" type="text" value="" placeholder="Departure date" required="required">
          </div>
        </div>
        <div class="row">
          <div class="col-md-5 control-label">Departure time</div>
          <div class="col-xs-12 col-md-7">
            <div class="input-group bootstrap-timepicker">
                <input id="departure-time" name="departure-time" class="form-control timespinner" autocomplete="off" size="16" type="text" value="" placeholder="Departure time" />
                <span class="input-group-addon"><i class="glyphicon glyphicon-time"></i></span>
            </div>
          </div>
        </div>        
      </div>

      <h3 class="col-xs-12">Returning</h3>
      <div class="col-md-6">
        <div id="unable"></div>
        <div class="row">
          <div class="col-md-5 control-label">Returning date</div>
          <div class="col-xs-12 col-md-7">
            <input id="returnDate" name="return-date" class="form-control datepicker" autocomplete="off" size="16" type="text" value="" placeholder="Returning date">
          </div>
        </div>
        <div class="row">
          <div class="col-md-5 control-label">Returning time</div>
          <div class="col-xs-12 col-md-7">
            <div class="input-group bootstrap-timepicker">
                <input id="return-time" name="return-time" class="form-control timespinner" autocomplete="off" size="16" type="text" value="" placeholder="Returning time" />
                <span class="input-group-addon"><i class="glyphicon glyphicon-time"></i></span>
            </div>            
          </div>
        </div>
      </div>
    </div> <!-- end row -->
    <div class="row line">
      <div class="col-md-6">
        <div class="row">
          <div class="col-xs-12 col-md-5 control-label">From</div>
          <div class="col-xs-12 col-md-7">
            <select name="airport-from"class="form-control" required="required">
              <option value=''></option>
              <?php
              foreach ($charters as $value) {
              ?>
                <option value="<?php echo $value ?>"><?php echo $value ?></option>
              <?php } ?>
            </select>
          </div>
        </div>
      </div>
      <div class="col-md-6">
        <div class="row">
          <div class="col-xs-12 col-md-5 control-label">To</div>
          <div class="col-xs-12 col-md-7">
            <select name="airport-to" class="form-control" required="required">
              <option value=''></option>
              <?php
              foreach ($charters as $value) {
              ?>
                <option value="<?php echo $value ?>"><?php echo $value ?></option>
              <?php } ?>
            </select>
          </div>
        </div>
      </div>
    </div> <!-- end row -->

    <div class="row line">
      <div class="col-md-6">
        <div class="row">
          <div class="col-xs-12 col-md-5 control-label">Nbr of passengers</div>
          <div class="col-xs-12 col-md-7">
            <select name="nbr-pax" id="nbr-pax" required="required" class="form-control">
              <option value=""></option>
              <?php 
              for($i=1; $i < 31; $i++) {
                ?> 
                <option value="<?php echo $i ?>" <?php echo ($i==1 ? 'selected="selected"' : '') ?> ><?php echo ($i < 10 ? "0".$i : $i) ?> passenger<?php echo $i == 1 ? "" : "s" ?></option>
                <?php } ?>
              </select>
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <div class="row">
            <div class="col-xs-12 col-md-5 control-label">Connection flight</div>
            <div class="col-xs-12 col-md-7 control-label">
              <div class="checkbox col-xs-6">
                <label>
                  <input type="radio" name="connecting" value="0" checked="checked" />&nbsp; No
                </label>
              </div>
              <div class="checkbox col-xs-6">
                <label>
                  <input type="radio" name="connecting" value="1" />&nbsp; Yes
                </label>
              </div>
            </div>
          </div>
        </div>
      </div>  <!-- end row -->
      
      <div class="row">
        <h2 class="col-xs-12">Contact information</h2>
        <div class="col-md-6">
          <div class="row">
            <div class="col-xs-12 col-md-5 control-label">First Name</div>
            <div class="col-md-7">
              <input id="" name="first-name" class="form-control" size="16" type="text" value="" placeholder="First Name" required="required">
            </div>
          </div>
        </div>
        <div class="col-md-6">        
          <div class="row">
            <div class="col-xs-12 col-md-5 control-label">Last Name</div>
            <div class="col-md-7">
              <input id="" name="last-name" class="form-control" size="16" type="text" value="" placeholder="Last Name" required="required">
            </div>
          </div>
        </div>
        <div class="col-md-6">          
          <div class="row">
            <div class="col-xs-12 col-md-5 control-label">Tel.</div>
            <div class="col-md-7">
              <input id="" name="tel" class="form-control" size="16" type="text" value="" placeholder="Tel.">
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <div class="row">
            <div class="col-xs-12 col-md-5 control-label">Mobile</div>
            <div class="col-md-7">
              <input id="" name="mobile" class="form-control" size="16" type="text" value="" placeholder="Mobile">
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <div class="row">
            <div class="col-xs-12 col-md-5 control-label">Email</div>
            <div class="col-md-7">
              <input id="" name="email" class="form-control" size="16" type="text" value="" placeholder="@" required="required">
            </div>
          </div>
        </div>
        <div class="col-md-6">          
          <div class="row">
            <div class="col-xs-12 col-md-5 control-label">Fax</div>
            <div class="col-md-7">
              <input id="" name="fax" class="form-control" size="16" type="text" value="" placeholder="Fax">
            </div>
          </div>
        </div>
      </div> <!-- end row -->
      <div class="row">
        <div class="col-md-12">
          <h2>Questions or additional information</h2>
          <textarea name="comments" id="" class="form-control" cols="" rows="5"></textarea>
        </div>
      </div> <!-- end row -->

      <!-- VALIDATION -->
      <div class="col-md-12" id="submit-charter">
        <button type="submit" class="btn btn-default">Submit</button>
      </div>

      <input type="hidden" name="URL-main" value="<?php echo $webPageUrl ?>">
      <input type="hidden" name="token" value="<?php echo $newToken; ?>">
    </form>
  </div>