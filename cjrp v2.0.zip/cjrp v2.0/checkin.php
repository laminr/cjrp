<!-- https://booksecure.cjrptravel.com/process/search -->
<form role="form" class="form-horizontal" id="checkIn-form" action="https://booksecure.cjrptravel.com/checkin/checkin" method="post">

  <div class="row lines">
      <p>To check in, please enter the confirmation number of your reservation below, followed by the last name of the first passenger on the reservation.</p>
      <p>You may check in up to 24 hours prior to the scheduled departure of your flight.</p>
      <div class="form-label">Confirmation Number:</div>
      <input type="text" class="form-control" name="conf_number" />

      <div class="form-label">Last Name:</div>
      <input type="text" class="form-control" name="name_last" />
  </div>
  <div id="submit-flight">
    <button type="submit" class="btn btn-default pull-right">Submit</button>
  </div>
</form>