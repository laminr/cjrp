<div class="row col-xs-12">
  <h1>Welcome to <span class="title-cursive">Anguilla</span></h1>
</div>
<div class="row">
  <div class="col-md-8">
	<p>
	  A warm and welcoming island destination tucked away in the northern Caribbean. Embraced by unrivaled white beaches and breathtaking turquoise seas, <em>Anguilla</em> is casual and easy, a unique blend of high style and low-key elegance, and the best of the good life set to a slow and casual island tempo.  
	</p>          
	<p>
	  <em>Anguilla</em> is an experience that captivates our visitors and creates friendships and memories that last a lifetime. Come visit Anguilla this fall and enjoy our endless Summer with near perfect weather, blue waters and balmy trade winds. Quiet, and low key from the end of August to October, the island is yours to explore and experience. 
	</p>
	<p id="quote">
	  &ldquo; Come visit Anguilla, where feeling is believing! &rdquo;
	</p>
	<div class="row dest-info">
	  <div class="col-xs-12">
		<div class="col-xs-6">Capital: </div><div class="col-xs-6">The Valley</div>
		<div class="col-xs-6">Airport: </div><div class="col-xs-6">Clayton J Lloyd Int'l Airport</div>
		<div class="col-xs-6">Land Area: </div><div class="col-xs-6">36 sq. Miles</div>
		<div class="col-xs-6">Population: </div><div class="col-xs-6">Approx. 12,000</div>
		<div class="col-xs-6">Currency: </div><div class="col-xs-6">E.C &amp; U.S. dollar</div>
		<div class="col-xs-6">The Anguilla Tourist Board</div>
		<div class="col-xs-6">(264) 497-2759</div>
		<div class="col-sm-6 col-sm-offset-3">
		  <a href="http://www.anguilla-vacation.com" target="_blank">www.anguilla-vacation.com</a>
		</div>
	  </div>
	</div>
  </div>
  <div class="col-sm-12 col-md-4">
	<div class="row">
	  <div class="dest-img-line col-xs-6 col-md-12">
		<img src="img/destinations/anguilla_1.jpg" alt="Anguilla hotel" class="img-thumbnail"/>
	  </div>
	  <div class="dest-img-line col-xs-6 col-md-12">
		<img src="img/destinations/anguilla_2.jpg" alt="Anguilla beach" class="img-thumbnail"/>
	  </div>
	</div>
  </div>
</div>