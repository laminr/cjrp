<div class="row col-xs-12">
  <h1>Welcome to <span class="title-cursive">Nevis</span></h1>
</div>
<div class="row">
  <div class="col-md-8">
	<p>
	  <em>Nevis</em> part of the <em>Federation of St. Kitts and Nevis</em>, located two miles southeast of its sister island, in the Leeward Islands of the Caribbean. With a population of approximately 11,200, Nevis is approximately 1,200 miles from Miami
	</p>
	<p>
	  <em>Nevis</em> enjoy a very pleasant tropical marine climate, with temperatures ranging between 18&deg;C and 32&deg;C (63&deg;F and 90&deg;F). The humidity is low and the northeast trade winds keep the island comfortable. November to May are the driest months
	</p>
	<p>
	  <em>Columbus</em> sailed to the shores of Nevis in 1493. He decided to call the island <em>&quot;Nuestra Se&ntilde;ora de las Nieves&quot;</em> which means <em>&quot;Our Lady of the Snows&quot;</em>. Over the years, this name has been simplified to Nevis and is pronounced "Nee-vis".
	</p>
	<p>Today, Nevis is still referred to as <em>Queen of the Caribbees</em></p>
	<div class="row dest-info">
	  <div class="col-xs-12">
		<div class="row">
			<div class="col-xs-6">Capital </div><div class="col-xs-6">Charlestown</div>
			<div class="col-xs-6">Airport </div><div class="col-xs-6">Vance W. Amory</div>
			<div class="col-xs-6">Land Area </div><div class="col-xs-6">36 sq. miles</div>
			<div class="col-xs-6">Population </div><div class="col-xs-6">Approx 11,000</div>
			<div class="col-xs-6">Currency </div><div class="col-xs-6">EC dollar</div>
			<div class="col-xs-6">Nevis Tourism Authority</div>
			<div class="col-xs-6">(869) 469 7550</div>
			<div class="col-sm-6 col-sm-offset-3"><a href="http://www.nevisisland.com" target="_blank">www.nevisisland.com</a></div>
			<div class="col-sm-6 col-sm-offset-3"><a href="http://www.nevisisland.com/Brochure/NevisBrochure.pdf" target="_blank">Nevis Tourism brochure</a></div>
		</div>
	  </div>
	</div>
  </div>
  <div class="col-sm-12 col-md-4">
	<div class="row">
	  <div class="dest-img-line col-xs-6 col-md-12">
		<img src="img/destinations/nevis_1.jpg" alt="Anguilla hotel" class="img-thumbnail"/>
	  </div>
	  <div class="dest-img-line col-xs-6 col-md-12">
		<img src="img/destinations/nevis_2.jpg" alt="Anguilla beach" class="img-thumbnail"/>
	  </div> 
	</div>
  </div>
</div>