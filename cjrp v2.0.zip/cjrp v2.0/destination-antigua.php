<div class="row col-xs-12">
  <h1>Welcome to <span class="title-cursive">Antigua</span></h1>
</div>
<div class="row">
  <div class="col-sm-8">
	<p>
	  The Caribbean islands of <em>Antigua &amp; Barbuda</em> enjoy cooling trade winds which ensure the weather is perfect for the world famous sailing regattas like <em>Antigua Sailing Week</em> and <em>Antigua Classic Yacht Charter Week</em>.
	</p>
	<p>
	  <em>Antigua</em> is one of the top Caribbean holiday and vacation destinations with 365 white sand beaches, and a huge choice of things to do, places to stay and services.
	</p>
	<p>
	  <em>Antigua</em> is an island in the West Indies, in the Leeward Islands in the Caribbean region the main island of the country of Antigua and Barbuda.
	</p>
	<p>
	   <em>Antigua</em> means "ancient" in Spanish and was named by <em>Christopher Columbus</em> after an icon in Seville Cathedral, Santa Maria de la Antigua-St. Mary of the Old Cathedral.
	</p>
	<p>
	   The name Wadadli comes from the native Indian inhabitants and means approximately "our own". 
	</p>
	<p>
	  The island's circumference is roughly 87 km (54 mi) and its area 281 km2 (108 sq mi). Its population was 80,161 (at the 2011 Census). The economy is mainly reliant on tourism, with the agricultural sector serving the domestic market.
	</p>
	<div class="row dest-info">
	  <div class="col-xs-12">
		  <div class="row">
			<div class="col-xs-6">Capital: </div><div class="col-xs-6">San John's</div>
			<div class="col-xs-6">Airport: </div><div class="col-xs-6">VC Bird Intl</div>
			<div class="col-xs-6">Land Area: </div><div class="col-xs-6">108 sq. Miles</div>
			<div class="col-xs-6">Population: </div><div class="col-xs-6">Approx. 68,000</div>
			<div class="col-xs-6">Currency: </div><div class="col-xs-6">E.C. dollar</div>
			<div class="col-xs-6">Ministry of Tourism</div>
			<div class="col-xs-6">(268) 462-0480</div>
			<div class="col-sm-6 col-sm-offset-3">
				<a href="http://www.antigua-barbuda.org" target="_blank">www.antigua-barbuda.org</a>
			</div>
		  </div>
	   </div>
	</div>
  </div>
  <div class="col-sm-12 col-md-4">
	<div class="row">
	  <div class="dest-img-line col-xs-6 col-md-12">
		<img src="img/destinations/antigua_1.jpg" alt="Antigua beach" class="img-thumbnail"/>
	  </div>
	  <div class="dest-img-line col-xs-6 col-md-12">
		<img src="img/destinations/antigua_2.jpg" alt="Antigua hotel" class="img-thumbnail"/>
	  </div>
	</div>
  </div>
</div>