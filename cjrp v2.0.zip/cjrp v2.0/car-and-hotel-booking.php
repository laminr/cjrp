<?php 
  require 'class/tools.class.php';
  require 'class/handleHotelForm.class.php';
  require 'class/handleCarForm.class.php';

  session_start ();

  // adresse de la page
  $current_url = explode("?", $_SERVER['REQUEST_URI']);;
  $webPageUrl = 'http://'.$_SERVER['HTTP_HOST'] . $current_url[0] ;

  $isGettingEmailHotel = false;
  $isGettingEmailCar = false;

  if ( isset ($_POST['country']) 
    AND isset ($_POST['check-in-date']) 
    AND isset ($_POST['check-out-date'])
    ) {
      $hotelBookingEmail = new handleHotelForm();
      $isGettingEmailHotel = $hotelBookingEmail->processEmail('hotel-booking-form');
  }

  if (isset($_POST['car-airport']) 
    AND isset ($_POST['pick-up-date']) 
    AND isset ($_POST['drop-off-date'] )
    AND isset ($_POST['car-type'] )
  ) {
      $carBookingEmail = new handleCarForm();
      $isGettingEmailCar = $carBookingEmail->processEmail('car-booking-form');
  }
    //var_dump($isGettingEmail);
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title><?php include 'title.php' ?></title>
    <?php include 'meta-keywords.php' ?>
    
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet" media="screen">
    <link href="css/smoothness/jquery-ui-1.10.3.custom.min.css" rel="stylesheet" media="screen"/>

    <link href="css/car-hotel-booking.css" rel="stylesheet" media="screen">
    <link href="css/commons.css" rel="stylesheet" media="screen">

    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,300' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css'>
    <!--avant la balise-->
    <script src="js/email.js"></script>
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="js/assets/html5shiv.js"></script>
      <script src="js/assets/respond.min.js"></script>
    <![endif]-->
    <?php 
      $newTokenHotel = Tools::generateFormToken('hotel-booking-form'); 
      $newTokenCar = Tools::generateFormToken('car-booking-form'); 
    ?>
  </head>
  <body id="car-hotel-booking">
    
    <div id="login" class="Box">
      <?php include 'login.php' ?>
    </div>
    <header class="container">
      <?php include 'navbar.php' ?>
    </header>
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <div class="clearfix">
            <h1>Hotel booking</h1>
            <?php include 'hotel-booking.php' ?>
          </div>
          <div class="clearfix">
            <h1>Cruise Booking</h1>
            <?php include 'cruise-booking.php' ?>
          </div>
        </div>
        <div class="col-md-6">
          <h1>Car rental</h1>
          <?php include 'car-booking-form.php' ?>
        </div>
      </div>
    </div>
    <!-- IMG LINE -->
    <div class="img-line"></div>    
    <footer>
      <?php include 'footer.php' ?>
    </footer>

    <!-- modal -->
    <div id="modal-message" class="modal fade">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" data-hidden="true">&times;</button>
            <h4 class="modal-title"><?php echo ($isGettingEmailHotel ? "Hotel" : "Car") ?> booking request</h4>
          </div>
          <div class="modal-body">
            <p>Thank you for choosing CJRP Travel.</p>
            <p>We have received your <?php echo ($isGettingEmailHotel ? "Hotel" : "Car") ?> request. Please allow us 1 to 2 business days to complete your quotation.</p>
            <br/>
            <p>If this charter is an emergency, please contact us via phone, for immediate assistance.</p>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
          </div>
        </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
    
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) 
    <script src="//code.jquery.com/jquery.js"></script>-->
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<!--
    <script src="js/jquery-1.10.1.min.js"></script>-->
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-ui-1.10.3.custom.min.js"></script>
    <script src="js/car-and-hotel-booking.js"></script>
    <script src="js/img-line.js"></script>

    <?php if ($isGettingEmailHotel == true || $isGettingEmailCar==true) { ?>
      <script type="text/javascript">
        //$('#modal-message').modal();
        $('#modal-message').modal({
          keyboard: true
        });
      </script>
    <?php } ?>

    <!-- Placed at the end of the document so the pages load faster
    <script src="../../assets/js/holder.js"></script> -->
    <?php include_once("analyticstracking.php") ?>
  </body>
</html>