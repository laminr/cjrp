<?php
  include_once 'data/routes.php';
  include_once 'data/ads.php';
  $pageName = 'schedule';
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title><?php include 'title.php' ?></title>
    <?php include 'meta-keywords.php' ?>
    
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet" media="screen">
    <link href="css/commons.css" rel="stylesheet" media="screen">

    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,300' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css'>
    
    <!-- Add fancyBox -->
    <link rel="stylesheet" href="css/jquery.fancybox.css?v=2.1.5" type="text/css" media="screen" />


    <style>
      
    </style>
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="js/assets/html5shiv.js"></script>
      <script src="js/assets/respond.min.js"></script>
    <![endif]-->
  </head>
  <body id="schedule">
    
    <div id="login" class="Box">
      <?php include 'login.php' ?>
    </div>
    <header class="container">
      <?php include 'navbar.php' ?>
    </header>
    <div class="container">
      <div class="row">
        <div class="col-xs-12 col-md-8">
          <h1>Schedule</h1>
          <?php for($routeIndex=0; $routeIndex < count($routes); $routeIndex++) { ?>
            <table class="table">
              <thead>
                <tr>
                  <th colspan="7"><?php echo $routes[$routeIndex][0][0].' to '.$routes[$routeIndex][0][1] ?></th>
                </tr>
                <tr>
                  <th>Days</th>
                  <th>Depart</th>
                  <th>Arrive</th>
                  <th>Flt No.</th>
                  <th>Via</th>
                  <th>Effective</th>
                  <th>Finishes</th>
                </tr>              
              </thead>
              <?php for ($indexSchedule=1; $indexSchedule <  count($routes[$routeIndex]); $indexSchedule++ ) { 
                  $oneSchedule = $routes[$routeIndex][$indexSchedule];
                  ?>
                  <tr>
                    <td><?php echo $oneSchedule[0] ?></td>
                    <td><?php echo $oneSchedule[1] ?></td>
                    <td><?php echo $oneSchedule[2] ?></td>
                    <td><?php echo $oneSchedule[3] ?></td>
                    <td><?php echo $oneSchedule[4] ?></td>
                    <td><?php echo $oneSchedule[5] ?></td>
                    <td><?php echo $oneSchedule[6] ?></td>
                  </tr>
              <?php } ?>
            </table>
          <?php } ?>
        </div>
        <div class="col-md-4 adsColumn">
          <h1>Partners</h1>
		  <?php 
		   if(isset($ads[$pageName])) {
			$theAds = $ads[$pageName];
			foreach($theAds as $value) {
				if ($value[0] == 'blank') { ?>
					<div class="advert well col-md-12">
            <div>
						  Your ads here <br/> 360 x 240 (thumbnail) <br/> 750 x 500 full screen
            </div>
					</div>
				<?php 
				} else { 
					$anAd = $value;
				?>
					<div class="advert col-md-12">
						<a class="fancybox" rel="ads" href="img/ads/<?php echo $anAd[0]; ?>" title="<?php echo $anAd[2]; ?>">
						  <img src="img/ads/<?php echo $anAd[1]; ?>" alt="<?php echo $anAd[2]; ?>" class="img-thumbnail" />
						</a>
					</div>
				<?php 
				} ?>
 		  <?php 
			}
		  }
		  ?>
        </div>
      </div>
    </div>
    <!-- IMG LINE -->
    <div class="img-line last"></div>    
    <footer>
      <?php include 'footer.php' ?>
    </footer>

    <script src="js/jquery-1.10.1.min.js"></script>

    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-ui-1.10.3.custom.min.js"></script>
    <script src="js/jquery.fancybox.pack.js?v=2.1.5" type="text/javascript"></script>
    
    <script src="js/img-line.js"></script>
    <!-- Placed at the end of the document so the pages load faster
    <script src="../../assets/js/holder.js"></script> -->
    <script>
    $(document).ready(function() {
      $(".fancybox").fancybox();
    });
    </script>
    <?php include_once("analyticstracking.php") ?>
  </body>
</html>