
<div class="col-md-10">
  <form role="form" class="form-horizontal" id="hotel-booking-form" action="" method="POST">
    <div>
      <div class="line clearfix">
        <div class="col-md-6 control-label">Destination</div>
        <div class="col-md-6">
          <select name="country" class="form-control" required="required">
              <option value=""></option> 
              <option value="Anguilla">Anguilla</option> 
              <option value="Antigua &amp; Barbuda">Antigua &amp; Barbuda</option> 
              <option value="Barbados">Barbados</option> 
              <option value="Dominica">Dominica</option> 
              <option value="Dominican Republic">Dominican Republic</option> 
              <option value="Grenada">Grenada</option> 
              <option value="Guadeloupe">Guadeloupe</option> 
              <option value="Jamaica">Jamaica</option> 
              <option value="Martinique">Martinique</option> 
              <option value="Puerto Rico">Puerto Rico</option> 
              <option value="Saint Kitts &amp; Nevis">Saint Kitts &amp; Nevis</option> 
              <option value="Saint Lucia">Saint Lucia</option> 
              <option value="Saint Martin">Saint Martin</option> 
              <option value="Saint Vincent">Saint Vincent</option>
              <option value="Trinidad &amp; Tobago">Trinidad &amp; Tobago</option> 
              <option value="US Virgin Islands">US Virgin Islands</option> 
              <option value="Trinidad">Trinidad (POS)</option> 
          </select>
        </div>
      </div>
      <div class="line clearfix">
        <div class="col-md-6">
          <div class="row">
            <div class="col-md-12 control-label">Check-In date</div>
            <div class="col-md-12">
              <input id="check-in-date" name="check-in-date" class="col-xs-12 form-control datepicker" size="16" type="text" value="" placeholder="Check In" required="required" autocomplete="off" />
            </div>
          </div>
          <div class="row">
            <div class="col-md-12 control-label">Check-Out date</div>
            <div class="col-md-12">
              <input id="check-out-date" name="check-out-date" class="col-xs-12 form-control datepicker" size="16" type="text" value="" placeholder="Check Out" required="required" autocomplete="off" />
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <div class="row"> 
            <div class="col-xs-4">Adults</div>
            <div class="col-xs-8">
              <select class="form-control" name="hotel-adults" required="required"> 
                <option value=""></option>
                <option value="1" selected="selected">1 Adult</option>  
                <option value="2">2 Adults</option>  
                <option value="3">3 Adults</option>  
                <option value="4">4 Adults</option>  
                <option value="5">5 Adults</option>  
                <option value="6">6 Adults</option>  
                <option value="7">7 Adults</option>
              </select>
            </div>
            <div class="col-xs-4">Children</div>
            <div class="col-xs-8">
              <select class="form-control" name="hotel-children"> 
                 <option value="0">0 Child</option>  
                 <option value="1">1 Childs</option>  
                 <option value="2">2 Childs</option>  
                 <option value="3">3 Childs</option>  
                 <option value="4">4 Childs</option>  
                 <option value="5">5 Childs</option>  
                 <option value="6">6 Childs</option>  
                 <option value="7">7 Childs</option>  
              </select>
            </div>
            <div class="col-xs-4">Infant</div>
            <div class="col-xs-8">
              <select class="form-control" name="hotel-minor"> 
                 <option value="0">0 Infant</option>  
                 <option value="1">1 Infants</option>  
                 <option value="2">2 Infants</option>  
                 <option value="3">3 Infants</option>  
                 <option value="4">4 Infants</option>  
                 <option value="5">5 Infants</option>  
                 <option value="6">6 Infants</option>  
                 <option value="7">7 Infants</option>  
              </select>
            </div>
            <div class="col-xs-4">Rooms</div>
            <div class="col-xs-8">
              <select class="form-control" name="nbr-rooms">
                 <option value="1">1</option>  
                 <option value="2">2</option>  
                 <option value="3">3</option>  
                 <option value="4">4</option>  
              </select>
            </div>
          </div>
        </div>
      </div>
      <div class="line clearfix">
          <div class="col-md-4 control-label">Contact name</div>
          <div class="col-md-8">
            <input id="" name="contact-name" class="col-xs-12 form-control" size="16" type="text" value="" placeholder="contact name">
          </div>
          <div class="col-md-4 control-label">Phone number</div>
          <div class="col-md-8">
            <input id="" name="contact-phone" class="col-xs-12 form-control" size="16" type="text" value="" placeholder="Phone number">
          </div> 
          <div class="col-md-4 control-label">email</div>
          <div class="col-md-8">
            <input id="" name="contact-email" class="col-xs-12 form-control" size="16" type="text" value="" placeholder="email">
          </div>  
      </div>
    </div>
    <div class="col-md-12">
      <button type="submit" class="btn btn-default pull-right">Submit</button>
    </div>
    <input type="hidden" name="URL-main" value="<?php echo $webPageUrl ?>">
    <input type="hidden" name="token" value="<?php echo $newTokenHotel ?>">
  </form>
</div>