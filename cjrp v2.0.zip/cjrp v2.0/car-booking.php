<!-- https://booksecure.cjrptravel.com/process/search -->
<form role="form" class="form-horizontal" id="car-booking" action="https://booksecure.cjrptravel.com/process/search" method="post">
  <div class="row">
    <div class="col-xs-12">
      <p>CJRP Travel can book car rental for you at really good price.</p>
      <p>Please contact us for more details</p>
      <div>
        <h3>Contacts</h3>
        <table class="table">
          <tr>
            <td>
              <span class="glyphicon glyphicon-earphone"></span>
              +1-264-497-2577
            </td>
            <td>from most destinations within the Caribbean Region.</td>
          </tr>
          <tr>
            <td>
              <span class="glyphicon glyphicon-earphone"></span>
              465-2577
            </td>
            <td>for customers calling from St. Kitts</td>
          </tr>
          <tr>
            <td colspan="2">
              <span class="glyphicon glyphicon-envelope"></span>
              Email: <script>mail("reservations","cjrptravel",0,"")</script>
            </td>
          </tr>
        </table>
      </div>
    </div>
  </div>
</form>