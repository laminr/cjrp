<div class="row col-xs-12">
  <h1>Welcome to <span class="title-cursive">St. Maarten/Martin</span></h1>
</div>
<div class="row">
  <div class="col-md-8">
	<p>
	The island of <em>Sint Maarten</em> - <em>Saint Martin</em> is the smallest land mass in the world to be shared by two different nations. 
	</p>
	<p>
	Only 37 square miles are owned by <em>France</em> and <em>the Netherlands Antilles</em>.
	</p>
	<p>
	The French territory covers about two thirds of the island and is technically a part of Europe and the European Community. 
	</p>
	<p>
	The Dutch side is a member island of the Netherlands Antilles and part of the Kingdom of the Netherlands, but not considered European territory. There is no real border, just modest monuments and signs. 
	</p>
	<p>
	The island is known as an almost perfect holiday environment; <em>beaches</em> and <em>nightlife</em> are spectacular, <em>shopping</em> and <em>dining</em> the best in the Caribbean.
	</p>
	<p>
	Without visiting, its impossible to imagine <em>the variety of landscape, cultures and entertainment</em> to be found here. 
	</p>
	<p>
	<em>St. Maarten / Martin</em> just doesn't FEEL that small... Its central mountain range provides for a rugged and interesting terrain, with winding roads up and down the hills, through small villages and still plenty of untouched land.
	</p>
	<div class="row dest-info">
		<div class="col-xs-12">
		  <div class="row">
			<div class="col-xs-6">Capital </div><div class="col-xs-6">Phillipsburg</div>
			<div class="col-xs-6">Airport </div><div class="col-xs-6">Princess Juliana Intl.</div>
			<div class="col-xs-6">Land Area </div><div class="col-xs-6">16 sq. miles</div>
			<div class="col-xs-6">Population </div><div class="col-xs-6">Approx. 39,00</div>
			<div class="col-xs-6">Currency </div><div class="col-xs-6">Netherlands Ant. Guilder</div>
			<div class="col-xs-6">St. Maarten Tourist Bureau</div>
			<div class="col-xs-6">011 (599) 542 2337</div>
			<div class="col-sm-6 col-sm-offset-3">
				<a href="http://www.st-maarten.com" target="_blank">www.st-maarten.com</a>
			</div>
		  </div>
		</div>
	</div>
  </div>
  <div class="col-sm-12 col-md-4">
	<div class="row">
	  <div class="dest-img-line col-xs-6 col-md-12">
		<img src="img/destinations/stmaarten_1.jpg" alt="St Barts view" class="img-thumbnail"/>
	  </div>
	  <div class="dest-img-line col-xs-6 col-md-12">
		<img src="img/destinations/stmaarten_2.jpg" alt="St Barts airport" class="img-thumbnail"/>
	  </div> 
	</div>
  </div>
</div>