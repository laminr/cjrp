<form role="form" class="form-inline" method="post" action="https://booksecure.cjrptravel.com/process/profile_login">
  <label for="profile_username">My Account :</label>
  <div class="form-group">
    <label class="sr-only" for="profile_username">Email address</label>
    <input name="profile_username" id="profile_username" type="email" value="" class="form-control" placeholder="Enter email">
  </div>
  <div class="form-group">
    <label class="sr-only" for="profile_username">Password</label> 
    <input name="profile_password" id="profile_password" type="password" value="" class="form-control" placeholder="Your password">
  </div>
  <button type="submit" class="btn btn-default btn-xs">Log in</button>
  <a href="https://booksecure.cjrptravel.com/profile_create">Register</a>
</form>