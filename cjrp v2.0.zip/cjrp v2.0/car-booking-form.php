
<div class="col-md-10">
  <form role="form" class="form-horizontal" id="car-booking-form" action="" method="POST">
    <div>
      <div class="line clearfix">
        <div class="col-xs-3 control-label">Pick car at</div>
        <div class="col-xs-6">
          <select name="car-airport" class="form-control" required="required">
            <option value=""></option>
            <option value="Anguilla">Anguilla</option> 
            <option value="Antigua">Antigua &amp; Barbuda</option> 
            <option value="Barbados">Barbados</option> 
            <option value="Dominica">Dominica</option> 
            <option value="Dominican Republic">Dominican Republic</option> 
            <option value="Grenada">Grenada</option> 
            <option value="Guadeloupe">Guadeloupe</option> 
            <option value="Jamaica">Jamaica</option> 
            <option value="Martinique">Martinique</option> 
            <option value="Puerto Rico">Puerto Rico</option> 
            <option value="Saint Kitts &amp; Nevis">Saint Kitts &amp; Nevis</option> 
            <option value="St Lucia">Saint Lucia</option> 
            <option value="Saint Martin">Saint Martin</option> 
            <option value="St Vincent">Saint Vincent</option>
            <option value="Trinidad">Trinidad &amp; Tobago</option> 
            <option value="US VI">US Virgin Islands</option> 
          </select>
        </div>
        <div class="col-xs-3 control-label" id="where">
          <div> 
            <input type="radio" name="isAirport" value="1" checked="checked" />&nbsp;Airport
          </div> 
          <div>
            <input type="radio" name="isAirport" value="0" />&nbsp;Seaport
          </div>
        </div>
      </div>
      <div class="line clearfix">
        <div class="row">
          <div class="col-md-6">
            <div class="control-label">Pick-Up date</div>
            <input id="pick-up-date" name="pick-up-date" class="col-xs-12 form-control datepicker" size="16" type="text" value="" placeholder="Pick up date" required="required" autocomplete="off" />
          </div>
          <div class="col-md-6">
            <div class="control-label">Drop-off date</div>
            <input id="drop-off-date" name="drop-off-date" class="col-xs-12 form-control datepicker" size="16" type="text" value="" placeholder="Drop off date" required="required" autocomplete="off" />
          </div>           
        </div>
      </div>
      <div class="line clearfix">
        <div class="row line">
          <div class="col-md-4 control-label">Car type</div>
          <div class="col-md-8">
            <select class="form-control" name="car-type" required="required">
             <option value="All Cars">All Cars</option>
             <option value="Convertibles">Convertibles</option>
             <option value="Green Car">Green Car</option>
             <option value="Pick Up">Pick Up</option>
             <option value="SUV">SUV</option>
             <option value="Mini Van">Mini Van</option>
             <option value="Station Wagon">Station Wagon</option>
             <option value="Compact">Compact</option>
             <option value="Economy">Economy</option>
             <option value="Full Size">Full Size</option>
             <option value="Intermediate">Intermediate</option>
             <option value="Luxury">Luxury</option>
             <option value="Premium">Premium</option>
             <option value="Standard">Standard</option> 
            </select>
          </div>
        </div>
      </div>
      <div class="line clearfix row">
          <div class="col-md-4 control-label">Contact name</div>
          <div class="col-md-8">
            <input id="" name="contact-name" class="col-xs-12 form-control" size="16" type="text" value="" placeholder="contact name">
          </div>
          <div class="col-md-4 control-label">Phone number</div>
          <div class="col-md-8">
            <input id="" name="contact-phone" class="col-xs-12 form-control" size="16" type="text" value="" placeholder="Phone number">
          </div> 
          <div class="col-md-4 control-label">email</div>
          <div class="col-md-8">
            <input id="" name="contact-email" class="col-xs-12 form-control" size="16" type="text" value="" placeholder="email">
          </div>  
      </div>
    </div>
    <div class="col-md-12">
      <button type="submit" class="btn btn-default pull-right">Submit</button>
    </div>
    <input type="hidden" name="URL-main" value="<?php echo $webPageUrl ?>">
    <input type="hidden" name="token" value="<?php echo $newTokenCar; ?>">
  </form>
</div>