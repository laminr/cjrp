<!-- https://booksecure.cjrptravel.com/process/search -->
<form role="form" class="form-horizontal" id="flight-booking-form" action="https://booksecure.cjrptravel.com/process/search" method="post">
  <div id="flight-route" class="row lines">
    <div>
      <div class="col-md-4 control-label">Flying from</div>
      <div class="col-md-8">
        <select name="origin" id="origin"  class="form-control" onchange="javascript:updateDestination('dest', this.value)">
          <option value=''></option>
          <option value="ANU">Antigua (ANU)</option>
          <option value="NGD">Anegada Airport (NGD)</option>
          <option value="AXA" selected="selected">Anguilla (AXA)</option>
          <option value="DOM">Dominica (DOM)</option>
          <option value="SJU">Puerto Rico (SJU)</option>
          <option value="SKB">St. Kitts (SKB)</option>
          <option value="EIS">Tortola (EIS)</option>
          <option value="SXM">St. Maarten (SXM)</option>
          <option value="STT">St. Thomas (STT)</option>
          <option value="NEV">Nevis (NEV)</option>
          <option value="VIJ">Virgin Gorda Airport (VIJ)</option> 
        </select>
      </div>
    </div>
    <div>
      <div class="col-md-4 control-label">Going to</div>
      <div class="col-md-8">
        <select name="dest" id="dest" class="form-control">
          <option value=''></option>
          <option value="ANU">Antigua (ANU)</option>
          <option value="NGD">Anegada Airport (NGD)</option>
          <option value="AXA">Anguilla (AXA)</option>
          <option value="DOM">Dominica (DOM)</option>
          <option value="SJU">Puerto Rico (SJU)</option>
          <option value="SKB" selected="selected">St. Kitts (SKB)</option>
          <option value="EIS">Tortola (EIS)</option>
          <option value="SXM">St. Maarten (SXM)</option>
          <option value="STT">St. Thomas (STT)</option>
          <option value="NEV">Nevis (NEV)</option>
          <option value="VIJ">Virgin Gorda Airport (VIJ)</option> 
        </select>
      </div>
    </div>
  </div>
  <div class="row lines">
    <div class="col-xs-12 col-md-4 control-label">Trip</div>
    <div class="checkbox col-xs-6 col-md-4">
      <label>
        <input type="radio" name="return" value="1" checked="checked" />&nbsp;round trip
      </label>
    </div>
    <div class="checkbox col-xs-6 col-md-4">
      <label>
        <input type="radio" name="return" value="0" />&nbsp; One-Way
      </label>
    </div>
  </div>
  <div class="row lines">
      <div class="col-xs-12 col-md-4 control-label">Flexible</div>
      <div class="checkbox col-xs-6 col-md-4">
        <label>
          <input type="radio" name="selectedSearchType" value="FLEXIBLE" checked="checked"/>&nbsp;Yes
        </label>
      </div>
      <div class="checkbox col-xs-6 col-md-4">
        <label>
          <input type="radio" name="selectedSearchType" value="FIXED"  />&nbsp;No
        </label>
      </div>
  </div>
  <div id="dates" class="row lines">
    <div class="col-md-4 control-label">Dates</div>
    <div class="col-xs-12 col-md-4 date-selection-depart">
      <!-- departing date 
      <div for="depart_date">Outbound</div>-->
      <input id="flight-depart-date" name="depart_date" class="col-xs-12 form-control datepicker" size="16" type="text" value="" placeholder="departing" autocomplete="off">
    </div>
    <div class="col-xs-12 col-md-4 date-selection-return">
      <!-- returning date 
      <div for="return_date">Return</div>-->
      <input id="flight-return-date" name="return_date" class="col-xs-12 form-control datepicker" size="16" type="text" value="" placeholder="returning" autocomplete="off">
    </div>
  </div>
  <div id="pax" class="row lines">
      <input type="hidden" name="passengers" id="passengers" value="" />
      <div class="col-md-3">
          <label>Adults</label>
          <select name="adult_passengers" id="adult_passengers" class="form-control" onchange="javascript:udpatePaxTotalNbr()">
            <?php for ($i=1; $i <= 10; $i++) { ?>
              <option value="<?php echo $i ?>"><?php echo $i ?></option>
            <?php } ?>
          </select>
      </div>
      <div class="col-md-3">
          <label class="flight-tooltip" data-toggle="tooltip" data-placement="top" data-original-title="2-11 years">Children*</label>
          <select name="child_passengers" id="child_passengers" class="form-control" onchange="javascript:udpatePaxTotalNbr()">
            <?php for ($i=0; $i <= 10; $i++) { ?>
              <option value="<?php echo $i ?>"><?php echo $i ?></option>
            <?php } ?>
          </select>                      
      </div>
      <div class="col-md-3">
          <label class="flight-tooltip" data-toggle="tooltip" data-placement="top" data-original-title="60 or greater">Seniors*</label>
          <select name="senior_passengers" id="senior_passengers" class="form-control" onchange="javascript:udpatePaxTotalNbr()">
            <?php for ($i=0; $i <= 10; $i++) { ?>
              <option value="<?php echo $i ?>"><?php echo $i ?></option>
            <?php } ?>
          </select>                      
      </div>
      <div class="col-md-3">
          <label class="flight-tooltip" data-toggle="tooltip" data-placement="top" data-original-title="under 2 years">Infant*</label>
          <select name="infant_passengers" id="infant_passengers" class="form-control" onchange="javascript:udpatePaxTotalNbr()">
            <?php for ($i=0; $i <= 10; $i++) { ?>
              <option value="<?php echo $i ?>"><?php echo $i ?></option>
            <?php } ?>

          </select>                      
      </div>
  </div>
  <div class="row lines">
    <div class="col-md-4 control-label">Promo code</div>
    <div class="col-md-8">
      <input type="text" name="promo_code" class="form-control" />
    </div>
  </div>
  <div id="submit-flight">
    <button type="submit" class="btn btn-default pull-right">Submit</button>
  </div>
</form>