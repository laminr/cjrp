<?php
require_once 'emailMessage.class.php';
require_once 'emailTools.class.php';


class handleCharterForm {

	public function processEmail ($emailform) {
		$emailTools = new emailTools();
		
		$success = false;

    	// VERIFY LEGITIMACY OF TOKEN 
		if ($emailTools->verifyFormToken($emailform)) {

        	// CHECK TO SEE IF THIS IS A MAIL POST
			if (isset($_POST['URL-main'])) {

            	// Building a whitelist array with keys which will send through the form, no others would be accepted later on
				$whitelist = array('isRoundtrip', 'airport-from', 'airport-to' , 'nbr-pax', 'departure-date', 'departure-time', 
					'return-date', 'return-time', 'connecting', 'first-name', 'last-name', 'tel', 'mobile', 'email', 'fax', 'comments' , 'URL-main', 'token',
					'hour', 'minute', 'meridian' ); // last one are created by timespinner (guess!)

            	// Building an array with the $_POST-superglobal 
				foreach ($_POST as $key=>$item) {

                    // Check if the value $key (fieldname from $_POST) can be found in the whitelisting array, if not, die with a short message to the hacker
					if (!in_array($key, $whitelist)) {

						$emailTools->writeLog('Unknown form fields >> '.$key);
						//echo 'Unknown > '.$key;
						die(" >>> Hack-Attempt detected. Please use only the fields in the form");

					}
				}

            	// Lets check the URL whether it's a real URL or not. if not, stop the script
				if(!filter_var($_POST['URL-main'],FILTER_VALIDATE_URL)) {
					$emailTools->writeLog('URL Validation');
					die('Hack-Attempt detected. Please insert a valid URL');
				}

            	// PREPARE THE BODY OF THE MESSAGE
				$isRoundtrip 	= strip_tags($_POST['isRoundtrip']);
				$from 			= strip_tags($_POST['airport-from']);
				$to 			= strip_tags($_POST['airport-to']);
				$nbrPax			= strip_tags($_POST['nbr-pax']);
				$departureDate 	= strip_tags($_POST['departure-date']);
				$departureTime 	= strip_tags($_POST['departure-time']);
				$returnDate 	= strip_tags($_POST['return-date']);
				$returnTime 	= strip_tags($_POST['return-time']);
				$connecting 	= strip_tags($_POST['connecting']);
				$firstName 		= strip_tags($_POST['first-name']);
				$lastName 		= strip_tags($_POST['last-name']);
				$tel 			= strip_tags($_POST['tel']);
				$mobile 		= strip_tags($_POST['mobile']);
				$email 			= strip_tags($_POST['email']);
				$fax 			= strip_tags($_POST['fax']);
				$comments		= strip_tags($_POST['comments']);
				$URLMain 		= strip_tags($_POST['URL-main']);
				$token 			= strip_tags($_POST['token']);

				$cleanedEmail = '';
            	//  MAKE SURE THE "FROM" EMAIL ADDRESS DOESN'T HAVE ANY NASTY STUFF IN IT           
				$pattern = "/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/i"; 
				if (preg_match($pattern, trim($email))) { 
					$cleanedEmail = trim($email); 
				} else { 
					return "The email address you entered was invalid. Please try again!"; 
				} 

				$subject = 'Charters Booking Request';
            	//$country, $checkIn, $checkOut, $adults, $children, $minor, $rooms, $contact, $phone, $email
				$message = EmailMessage::getChartersMessage($isRoundtrip, $from, $to, $nbrPax, $departureDate, $departureTime, $returnDate, $returnTime, 
					$connecting, $firstName, $lastName, $tel, $mobile, $cleanedEmail, $fax, $comments);
            	//echo 'message '. $message;
            
            	// SENDING EMAIL
				$success = $emailTools->sendEmail($subject, $message);
            
			}
		}
		return $success;
	}
}