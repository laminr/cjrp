<?php
require_once 'emailMessage.class.php';
require_once 'emailTools.class.php';


class handleCarForm {

	public function processEmail ($emailform) {
		$emailTools = new emailTools();
		
		$success = false;

    	// VERIFY LEGITIMACY OF TOKEN 
		if ($emailTools->verifyFormToken($emailform)) {

        	// CHECK TO SEE IF THIS IS A MAIL POST
			if (isset($_POST['URL-main'])) {

            	// Building a whitelist array with keys which will send through the form, no others would be accepted later on
				$whitelist = array('car-airport', 'isAirport', 'pick-up-date','drop-off-date','car-type','contact-name','contact-phone','contact-email', 'token', 'URL-main');

            	// Building an array with the $_POST-superglobal 
				foreach ($_POST as $key=>$item) {

                    // Check if the value $key (fieldname from $_POST) can be found in the whitelisting array, if not, die with a short message to the hacker
					if (!in_array($key, $whitelist)) {

						$emailTools->writeLog('Unknown form fields');
						echo 'Unknown > '.$key;
						die("Hack-Attempt detected. Please use only the fields in the form");

					}
				}

            	// Lets check the URL whether it's a real URL or not. if not, stop the script
				if(!filter_var($_POST['URL-main'],FILTER_VALIDATE_URL)) {
					$emailTools->writeLog('URL Validation');
					die('Hack-Attempt detected. Please insert a valid URL');
				}

            	// PREPARE THE BODY OF THE MESSAGE
            	$airport 	= strip_tags($_POST['car-airport']);
            	$isAirport	= strip_tags($_POST['isAirport']);
				$pickup 	= strip_tags($_POST['pick-up-date']);
				$dropoff 	= strip_tags($_POST['drop-off-date']);
				$cartype 	= strip_tags($_POST['car-type']);
				$name 		= strip_tags($_POST['contact-name']);
				$phone 		= strip_tags($_POST['contact-phone']);

				$cleanedEmail = '';
            	//  MAKE SURE THE "FROM" EMAIL ADDRESS DOESN'T HAVE ANY NASTY STUFF IN IT           
				$pattern = "/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/i"; 
				if (preg_match($pattern, trim(strip_tags($_POST['contact-email'])))) { 
					$cleanedEmail = trim(strip_tags($_POST['contact-email'])); 
				} else { 
					return "The email address you entered was invalid. Please try again!"; 
				} 

				$subject = 'Car Booking Request';
            	//$country, $checkIn, $checkOut, $adults, $children, $minor, $rooms, $contact, $phone, $email
				$message = EmailMessage::getCarMessage($airport, $isAirport, $pickup, $dropoff, $cartype, $name, $phone, $cleanedEmail);
            	//echo 'message '. $message;
            
            	// SENDING EMAIL
				$success = $emailTools->sendEmail($subject, $message);
            
			}

		} else {

			if (!isset($_SESSION[$emailform.'_token'])) {

			} else {
				echo "Hack-Attempt detected. Got ya!.";
				$emailTools->writeLog('Formtoken');
			}

		}

		return $success;
	}
}