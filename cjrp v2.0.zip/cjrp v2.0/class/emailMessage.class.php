<?php
class emailMessage {

	public static function getHotelMessage($country, $checkIn, $checkOut, $adults, $children, $minor, $rooms, $contact, $phone, $email) {
                $now = new DateTime('NOW');

                $message ='<html><body> <table rules="all" style="border-color: #666; border: 1px solid #000" cellpadding="10">';
                $message .='<tr><td style="background: #eee;"><strong>Time</strong></td><td>'.$now->format(DateTime::COOKIE).'</td></tr>';
                $message .='<tr><td style="background: #eee;"><strong>Country request</strong></td><td>'.$country.'</td></tr>';
                $message .='<tr><td style="background: #eee;"><strong>Check In date</strong></td><td>'.$checkIn.'</td></tr>';   
                $message .='<tr><td style="background: #eee;"><strong>Check Out date</strong></td><td>'.$checkOut.'</td></tr>';       
                $message .='<tr><td style="background: #eee;"><strong>Adult, children, infant:</strong></td><td>'.$adults.'|'.$children.'|'.$minor.'</td></tr>';
                $message .='<tr><td style="background: #eee;"><strong>Rooms:</strong></td><td>'.$rooms.'</td></tr>';
                $message .='<tr><td style="background: #eee;"><strong>Contact Name:</strong></td><td>'.$contact.'</td></tr>';
                $message .='<tr><td style="background: #eee;"><strong>Phone:</strong></td><td>'.$phone.'</td></tr>';
                $message .='<tr><td style="background: #eee;"><strong>Email:</strong></td><td>'.$email.'</td></tr>';
                $message .='</table></body></html>';
                return $message;
        }

        public static function getChartersMessage(
                $isRoundtrip, $from, $to, $nbrPax, $departureDate, $departureTime, $returnDate, $returnTime, $connecting, 
                $firstName, $lastName, $tel, $mobile, $email, $fax, $comments
                ) {
                $now = new DateTime('NOW');

                $message ='<html><body> <table rules="all" style="border-color: #666; border: 1px solid #000" cellpadding="10">';
                $message .='<tr><td style="background: #eee;"><strong>Time</strong></td><td>'.$now->format(DateTime::COOKIE).'</td></tr>';
                $message .='<tr><td style="background: #eee;"><strong>Charters request for</strong></td><td>'.($isRoundtrip == 'true' ? "Round Trip" : "One Way" ).'</td></tr>';
                $message .='<tr><td style="background: #eee;"><strong>Initial Departure</strong></td><td>'.$from.'</td></tr>';
                $message .='<tr><td style="background: #eee;"><strong>Initial Arrival</strong></td><td>'.$to.'</td></tr>';
                $message .='<tr><td style="background: #eee;"><strong>Number of passengers</strong></td><td>'.$nbrPax.'</td></tr>';

                $message .='<tr><td style="background: #eee;"><strong>Departure Date and Time</strong></td><td>'.$departureDate.' @ '.$departureTime.'</td></tr>';
                if ($isRoundtrip == 'true') {
                        $message .='<tr><td style="background: #eee;"><strong>Return Date and Time</strong></td><td>'.$returnDate.' @ '.$returnTime.'</td></tr>';
                }

                $message .='<tr><td style="background: #eee;"><strong>Allows connection</strong></td><td>'.($connecting == true ? "YES" : "NO").'</td></tr>';
                $message .='<tr><td style="background: #eee;"><strong>Contact name</strong></td><td>Last name: '.$lastName.' First name: '.$firstName.'</td></tr>';
                $message .='<tr><td style="background: #eee;"><strong>Contact phone</strong></td><td>'.$tel.'</td></tr>';
                $message .='<tr><td style="background: #eee;"><strong>Contact mobile</strong></td><td>'.$mobile.'</td></tr>';
                $message .='<tr><td style="background: #eee;"><strong>Contact email</strong></td><td>'.$email.'</td></tr>';
                $message .='<tr><td style="background: #eee;"><strong>Contact fax</strong></td><td>'.$fax.'</td></tr>';
                $message .='<tr><td style="background: #eee;"><strong>Comments</strong></td><td>'.(trim($comments)=='' ? 'No Comments' : $comments).'</td></tr>';
                $message .='</table></body></html>';
                return $message;
        } 

        public static function getCarMessage($airport, $isAirport, $pickup, $dropoff, $cartype, $name, $phone, $cleanedEmail) {
                $now = new DateTime('NOW');

                $message ='<html><body> <table rules="all" style="border-color: #666; border: 1px solid #000" cellpadding="10">';
                $message .='<tr><td style="background: #eee;"><strong>Time</strong></td><td>'.$now->format(DateTime::COOKIE).'</td></tr>';
                $message .='<tr><td style="background: #eee;"><strong>Taking @</strong></td><td>'.$airport.' '.($isAirport==1 ? 'airport' : 'seaport').'</td></tr>';
                $message .='<tr><td style="background: #eee;"><strong>Pick up date</strong></td><td>'.$pickup.'</td></tr>';
                $message .='<tr><td style="background: #eee;"><strong>Return date</strong></td><td>'.$dropoff.'</td></tr>';
                $message .='<tr><td style="background: #eee;"><strong>Car type</strong></td><td>'.$cartype.'</td></tr>';
                $message .='<tr><td style="background: #eee;"><strong>Contact name</strong></td><td>'.$name.'</td></tr>';
                $message .='<tr><td style="background: #eee;"><strong>Contact phone</strong></td><td>'.$phone.'</td></tr>';
                $message .='<tr><td style="background: #eee;"><strong>Contact email</strong></td><td>'.$cleanedEmail.'</td></tr>';
                $message .='</table></body></html>';
                return $message;
        }  

}