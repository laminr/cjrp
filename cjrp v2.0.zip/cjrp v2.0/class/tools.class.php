<?php
class Tools {
    
        public static function generateFormToken($form) {

                // generate a token from an unique value, took from microtime, you can also use salt-values, other crypting methods...
                $token = md5(uniqid(microtime(), true));  

                // Write the generated token to the session variable to check it against the hidden field when the form is sent
                $_SESSION[$form.'_token'] = $token; 

                return $token;
        }

}