<?php
require './email/class.phpmailer.php';

class emailTools {

    public function getRealIp() {
       if (!empty($_SERVER['HTTP_CLIENT_IP'])) {  //check ip from share internet
           $ip=$_SERVER['HTTP_CLIENT_IP'];
       } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {  //to check ip is pass from proxy
           $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
       } else {
           $ip=$_SERVER['REMOTE_ADDR'];
       }
       return $ip;
    }

    public function writeLog($where) {

        $ip = $this->getRealIp(); // Get the IP from superglobal
        $host = gethostbyaddr($ip);    // Try to locate the host of the attack
        $date = date("d M Y");
        
        // create a logging message with php heredoc syntax
        $logging = <<<LOG
        \n
        << Start of Message >>
        There was a hacking attempt on your form. \n 
        Date of Attack: {$date}
        IP-Adress: {$ip} \n
        Host of Attacker: {$host}
        Point of Attack: {$where}
        << End of Message >>
LOG;
    // Awkward but LOG must be flush left

            // open log file
        if($handle = fopen('hacklog.log', 'a')) {

            fputs($handle, $logging);  // write the Data to file
            fclose($handle);           // close the file

        } 
    }

    public function verifyFormToken($form) {
        // check if a session is started and a token is transmitted, if not return an error
        if(!isset($_SESSION[$form.'_token'])) {
            return false;
        }
        
        // check if the form is sent with token in it
        if(!isset($_POST['token'])) {
            return false;
        }
        
        // compare the tokens against each other if they are still the same
        if ($_SESSION[$form.'_token'] !== $_POST['token']) {
            return false;
        }
        
        return true;
    }

    public function sendEmail($subject, $message) {

        $isSend = false;

        $mail = new PHPMailer;

        $mail->SMTPDebug = 0;

        $mail->isSMTP();                                      // Set mailer to use SMTP
        $mail->Host = 'smtp.gmail.com';                       // Specify main and backup server
        $mail->Port = 465;
        $mail->SMTPAuth = true;                               // Enable SMTP authentication
        $mail->Username = 'noreply@cjrptravel.com';         // SMTP username
        $mail->Password = 'Wy7q87Khq7!bw';                    // SMTP password
        $mail->SMTPSecure = 'ssl';                            // Enable encryption, 'ssl' also accepted

        $mail->From = 'noreply@cjrptravel.com';
        $mail->FromName = 'CJRP Website - Booking Request';
        $mail->addAddress('reservations@cjrptravel.com', 'CJRP Reservations');  // Add a recipient
        //$mail->addAddress('tdelambilly@gmail.com', 'CJRP Reservations');      // Add a recipient
        
        //$mail->addAddress('ellen@example.com');                               // Name is optional
        //$mail->addReplyTo($to, $name);
        //$mail->addCC('cc@example.com');
        //$mail->addBCC('bcc@example.com');

        //$mail->WordWrap = 50;                                 // Set word wrap to 50 characters
        //$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
        //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
        $mail->isHTML(true);                                  // Set email format to HTML

        $mail->Subject = $subject;
        $mail->Body    = $message;
        //$mail->AltBody = 'Demande de contact de $name : $to';

        if(!$mail->send()) {
         echo 'Message could not be sent.';
         echo 'Mailer Error: ' . $mail->ErrorInfo;
     } else {
        $isSend = true;
    }
    return $isSend;
    }
}