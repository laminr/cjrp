<!DOCTYPE html>
<html lang="en">
  <head>
    <title><?php include 'title.php' ?></title>
    <?php include 'meta-keywords.php' ?>
    
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet" media="screen">
    <link href="css/commons.css" rel="stylesheet" media="screen">

    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,300' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css'>


    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="js/assets/html5shiv.js"></script>
      <script src="js/assets/respond.min.js"></script>
    <![endif]-->
  </head>
  <body id="terms">
    
    <div id="login" class="Box">
      <?php include 'login.php' ?>
    </div>
    <header class="container">
      <?php include 'navbar.php' ?>
    </header>
    <div class="container">
      <div class="row">
        <div class="col-xs-12">
          <h1>Terms and conditions</h1>
          <h3>Passenger contact information</h3>
          <p>
            A working contact telephone number must be provided when making your reservation so that the airline may contact you in the event of flight cancellation. Should a contact telephone number not be provided, or should the contact number provided be unusable, CJRP TRAVEL will only be liable for refund of the fare paid for the affected flight and disclaims any further liability including, but not limited to alternate transportation, meals, and hotel accommodations.
            All Fares and Charges listed on the Itinerary are in United States Dollars (USD). All Fares are non-refundable, and may not be retained in a Credit Facility. No Changes Allowed.
          </p>
          <p>
            NOTICE: CHILDREN UNDER THE AGE OF 5 ARE PROHIBITED FROM TRAVEL ON CJRP TRAVEL FLIGHTS UNLESS ACCOMPANIED ON ALL FLIGHTS BY A PARENT OR LEGAL GUARDIAN.
          </p>
          <p>
            NOTE: OTHER RESTRICTIONS AND FEES MAY APPLY TO UNACCOMPANIED CHILDREN AGED 6 to 17
          </p>
          <p> 
            TRANSPORTATION BETWEEN THE AIRPORTS LISTED IN THIS RESERVATION REPRESENTS THE ENTIRETY OF THIS SALE. No guarantees beyond this sale of transportation, including but not limited to connections to/from non-CJRP TRAVEL affiliated carriers; cancellation, delay, and/or baggage mishandling by non-CJRP TRAVEL affiliated carriers; or non-CJRP TRAVEL associated events, are either expressed or implied.
          </p>
          <p>
            TRANSPORTATION OF PETS OR LIVESTOCK ON CJRP TRAVEL FLIGHT IS PROHIBITED
          </p>

          <h3>Hazardous/dangerous materials </h3>
          <p>
            CJRP TRAVEL is a non-carrier of Hazardous, Dangerous, or Restricted materials in or as baggage or cargo. For the safety of our passengers and aircraft, passengers are prohibited from carrying the following items in either checked or hand baggage:
          </p>
          <p>
            Explosives, munitions, fireworks, and flares Security-type cases/boxes incorporating goods such as lithium batteries or pyrotechnics Compressed gases (flammable, non-flammable, or poisonous) such as butane, propane, aqualung cylinders, lighter fuels, or refills Oxidizing substances such as bleaching powder and peroxides Flammable liquids such as paints and adhesives Flammable solids such as safety matches and articles which are easily ignited Disabling devices such as mace or pepper sprays, with irritant properties Poisons such as arsenic, cyanides, or insecticides Radioactive materials Corrosive materials such as mercury (which may be contained in thermometers or blood pressure gauges,) acids, alkalis, and wet cell batteries Meals-Ready-to-Eat (MREs) Any other substances which, during a flight, present a danger not covered above, such as magnetized, offensive, or irritating materials Lighters (butane, absorbed fuel, electric, battery-powered, and novelty lighters) are not to be carried on the person, or in the carry-on and checked baggage. 
          </p>
          <p>
            CJRP TRAVEL, at its sole discretion, will not transport items of either checked or carry-on Baggage that it determines may be harmful or dangerous to a Passenger(s), the flight crew, or the aircraft.
          </p>

          <h3>Check in &amp; baggage acceptance cutoff times</h3>
          <div class="col-xs-12 col-md-6 col-md-offset-3">
            <table class="table">
              <tr>
                <td>Anguilla,(AXA)</td>
                <td>45 minutes</td>
              </tr>
              <tr>
                <td>Antigua,(ANU)</td>
                <td>45 minutes</td>
              </tr>
              <tr>
                <td>St Kitts (SKB)</td>
                <td>45 minutes</td>
              </tr>
              <tr>
                <td>Tortola,(AXA)</td>
                <td>45 minutes</td>
              </tr>
            </table>
          </div>
          <div class="clearfix"></div>
          
          <h3>Baggage limits and allowances</h3>
          <p>
            BAGGAGE RESTRICTIONS STRICTLY ENFORCED
          </p>
          <p>
            BAGGAGE LIMITS: ONE pieces with a WEIGHT of 50 POUNDS
          </p>
          <p>
            BAGGAGE IN EXCESS OF THE PIECE and/or WEIGHT LIMIT WILL BE CARRIED ON A SPACE AVAILABLE/STANDBY BASIS AT A FLAT RATE OF USD $40.
          </p>
          <p>
            CJRP TRAVEL WILL NOT BE RESPONSIBLE FOR THE COST OF TRANSPORTATION AND DELIVERY OF UNACCOMMODATED EXCESS BAGGAGE.
          </p>
          <p>
            CARRY ON BAGGAGE CARRY ON ITEMS ARE LIMITED TO ONE PIECE. (BABY/CHILD CARE ITEMS EXCEPTED) CARRY ON ITEMS MUST BE OF REASONABLE SIZE (FULL SIZE LUGGAGE IS NOT ACCEPTABLE AS A "CARRY-ON" ITEM, FOR INSTANCE)
          </p>
          <p>
            ACCEPTANCE OF CARRY ON ITEMS IS SOLEY AT THE DISCRETION OF CJRP TRAVEL. UNACCEPTABLE CARRY-ON ITEMS MUST BE CHECKED AS BAGGAGE AND ARE SUBJECT TO CJRP TRAVEL' CHECKED BAGGAGE LIMITS AND RESTRICTIONS.
          </p>

          <h3>Limit of baggage liability</h3>
          <p>
            For most international travel (including domestic portions of international journeys) the liability limit is approximately $9.07 USD per pound ($20 USD per kilogram) for checked baggage and $400 USD per passenger for unchecked baggage (IF attributable to the negligence of the carrier) unless a higher value is declared in advance and additional charges are paid. In addition, CJRP TRAVEL liability is limited to 30 pounds (66 kilograms) ($272 USD) per checked bag.
          </p>
          <h3>Baggage claim</h3>
          <p>
            Checked baggage may be claimed only by the holder of the baggage claim check. Baggage will not be released unless all sums due CJRP TRAVEL are paid. Baggage claim checks must be returned to CJRP TRAVEL on request. CJRP TRAVEL is not responsible to determine that the holder of the claim check is entitled to the baggage. If baggage claim checks are lost, proof of ownership may be required prior to release of the baggage.
          </p>
          <p>
            Acceptance of baggage by the bearer of a claim check without filing a written complaint shall constitute evidence of delivery by CJRP TRAVEL of your baggage, with all original contents, in good condition.
          </p>
        </div>
      </div>
    </div>
    <!-- IMG LINE -->
    <div class="img-line"></div>    
    <footer>
      <?php include 'footer.php' ?>
    </footer>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) 
    <script src="//code.jquery.com/jquery.js"></script>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>-->
<!---->
    <script src="js/jquery-1.10.1.min.js"></script>

    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-ui-1.10.3.custom.min.js"></script>
    <script src="js/img-line.js"></script>
 
    <?php include_once("analyticstracking.php") ?>
  </body>
</html>