
$(function (){

    $('#booking-tab a').click(function (e) {
      e.preventDefault();
      $(this).tab('show');
    })

    $('#check-out-date').datepicker({minDate: 0});
    $('#drop-off-date').datepicker({minDate: 0});

    $('#pick-up-date').datepicker({
    	minDate: 0,
    	onSelect : function(clickDate) {
			$('#drop-off-date').datepicker( "option", "minDate", clickDate );    		
    	}
    });

    $('#check-in-date').datepicker({
    	minDate: 0,
    	onSelect : function(clickDate) {
			$('#check-out-date').datepicker( "option", "minDate", clickDate );    		
    	}
    });

});