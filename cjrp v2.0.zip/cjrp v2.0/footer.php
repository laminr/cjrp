<div class="container">
  <div class="col-md-12">
    <div class="social">
      <a href="https://www.facebook.com/flycjrp">
        <img src="img/facebook.png" alt="facebook account">
      </a>
      <a href="http://www.twitter.com/cjrptravel">
        <img src="img/twitter.png" alt="twitter account">
      </a>
    </div>
    <ul id="footer-list" class="col-md-8 col-md-offset-2">  
      <li><a href="/">Home</a></li>
      <li><a href="http://login.cjrptravel.com/">Agent / Employee Log-In</a></li>
      <li><a href="job-vacancy.php">Job Vacancies</a></li>
      <li><a href="privacy.php">Privacy Policy</a></li>
      <li><a href="terms.php">Terms &amp; Conditions</a></li>
    </ul>
    <div id="proud">&copy; CJRP Travel - A Proud Member Of CJRP Group.</div>
  </div>
</div>