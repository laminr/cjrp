<div class="row col-xs-12">
  <h1>Welcome to <span class="title-cursive">Tortola</span></h1>
</div>
<div class="row">
  <div class="col-md-8">
	<p>
		<em>Tortola</em> is the largest and most populated island of the <em>British Virgin Islands</em> - <em>BVI</em>.
	</p>
	<p>
		Local tradition recounts that <em>Christopher Columbus</em> named it Tortola, meaning <em>&quot;land of the Turtle Dove&quot;</em>. 
	</p>
	<p>The principal settlement is <em>Road Town</em>, the capital of the British Virgin Islands</p>
	<p>
		Powdery <em>white-sand beaches</em>, <em>lush green mountains</em>, and a sheltered <em>yacht-filled harbour</em> characterize the island of Tortola, where the past of the West Indies meets the present of the BVI
	</p>
	<p>
		You can shop everything from local spices, jams, rums, and soaps to handcrafted jewelry, silk-screened fabrics, and local art, can be found on Main Street in the capital city of Road Town.
	</p>
	<p>
		Although the British Virgin Islands are under the <em>British flag</em>, it uses the <em>U.S. dollar</em> as its official currency due to its proximity to and frequent trade with the <em>US Virgin Islands</em>.
	</p>
	<p>
		The island is home to many offshore companies that do business worldwide.
	</p>
	<div class="row dest-info">
		<div class="col-xs-12">
		  <div class="row">
			<div class="col-md-6">Capital </div><div class="col-md-6">Road Town</div>
			<div class="col-md-6">Airport </div><div class="col-md-6">T.B. Lettsome Intl.</div>
			<div class="col-md-6">Land Area </div><div class="col-md-6">24 sq. miles</div>
			<div class="col-md-6">Population </div><div class="col-md-6">20,000</div>
			<div class="col-md-6">Currency </div><div class="col-md-6">U.S. dollar</div>
			<div class="col-md-6">The BVI Tourist Board</div>
			<div class="col-md-6">(284) 494-3134</div>
			<div class="col-md-8 col-md-offset-2">
				<a href="http://www.bvitourism.com" target="_blank">www.bvitourism.com</a>
			</div>
		  </div>
		</div>
	</div>
  </div>
  <div class="col-sm-12 col-md-4">
	<div class="row">
	  <div class="dest-img-line col-xs-6 col-md-12">
		<img src="img/destinations/tortola_1.jpg" alt="St Barts view" class="img-thumbnail"/>
	  </div>
	  <div class="dest-img-line col-xs-6 col-md-12">
		<img src="img/destinations/tortola_2.jpg" alt="St Barts airport" class="img-thumbnail"/>
	  </div> 
	</div>
  </div>
</div>