<div class="row col-xs-12">
  <h1>Welcome to <span class="title-cursive">Saint Kitts</span></h1>
</div>
<div class="row">
  <div class="col-md-8">
	<p>
		<em>Saint Kitts</em>, also known more formally as <em>Saint Christopher Island</em> - <em>Saint-Christophe</em> in French.
	</p>
	<p>
		A Spanish expedition under <em>Christopher Columbus</em> discovered and claimed the island for <em>Spain</em> in 1493.
	</p>
	<p>Then the island alternated repeatedly between <em>English</em> and <em>French</em> control during the 17th and 18th centuries.</p>
	<p>Parts of the island were heavily fortified, as exemplified by <em>Unesco World Heritage</em> sites</p>
	<p>
		<em>St. Kitts</em> combine <em>natural beauty</em>, <em>sunny skies</em>, <em>warm waters</em>, and <em>white sandy beaches</em> that makes it one of the most seductive spots in the Caribbean.
	</p>
	<p>
		Its strategic location and valuable sugar trade led to an advanced and luxurious development that was among the best in the Colonial Caribbean.
	</p>
	<div class="row dest-info">
		<div class="col-xs-12">
		  <div class="row">
			<div class="col-xs-6">Capital </div><div class="col-xs-6">Basseterre</div>
			<div class="col-xs-6">Airport </div><div class="col-xs-6">Robert L. Bradshaw</div>
			<div class="col-xs-6">Land Area </div><div class="col-xs-6">68 sq. miles</div>
			<div class="col-xs-6">Population </div><div class="col-xs-6">Approx 35,000</div>
			<div class="col-xs-6">Currency </div><div class="col-xs-6">EC dollar</div>
			<div class="col-xs-6">St Kitts Dept. of Tourism</div>
			<div class="col-xs-6">(869) 465-4040</div>
			<div class="col-sm-6 col-sm-offset-3">
				<a href="http://www.stkitts-tourism.com" target="_blank">www.stkitts-tourism.com</a>
			</div>
		  </div>
		</div>
	</div>
  </div>
  <div class="col-sm-12 col-md-4">
	<div class="row">
	  <div class="dest-img-line col-xs-6 col-md-12">
		<img src="img/destinations/stkitts_1.jpg" alt="St Barts view" class="img-thumbnail"/>
	  </div>
	  <div class="dest-img-line col-xs-6 col-md-12">
		<img src="img/destinations/stkitts_2.jpg" alt="St Barts airport" class="img-thumbnail"/>
	  </div> 
	</div>
  </div>
</div>