<div class="row col-xs-12">
  <h1>Welcome to <span class="title-cursive">Dominica</span></h1>
</div>
<div class="row">
  <div class="col-sm-8">
	<p>
	  I am beauty unspoilt. Culture preserved.  I am a dive's dream and hiker's paradise. I am the trailhead to adventure and discovery, unlike any other Caribbean destination. I am volcanic peaks, boiling waters and underwater champagne springs. Sparkling waterfalls, rushing streams and rainforest canopies. I am celebrations of music, art and flowers. I am nature's island. <em>I am Dominica</em>. Are You?
	</p>
	<p>
	  <em>Dominica</em> (pronounced Dom-in-eek-a) sits midway along the Eastern Caribbean archipelago, just a few miles from Martinique to the south and Guadeloupe to the north. 
	</p>
	<p>
	  The island's official name is the <em>Commonwealth of Dominica</em>, which is mostly referenced in official communique and to distinguish the island from its northerly Caribbean sister, the <em>Dominican Republic</em>. 
	</p>
	<p>
	  The island is sparsely populated with around 70,000 people inhabiting its 289.5 square miles. 
	</p>
	<p>
	  <em>Dominica</em> is an arcadia of unspoiled nature. Tropical forest coats two thirds of the island, which nourishes 1,200 plant species. 
	</p>
	<p>
	  Rivers, lakes, streams, and waterfalls abound, fed by the islands high annual rainfall. Its volcanic physique points to extensive geothermal activity above and below sea level.
	</p>
	<p>
	  The island is one of only a couple in the Caribbean still with populations of the pre-Columbian Carib Indians.
	</p>
	<div class="row dest-info">
	  <div class="col-xs-12">
		  <div class="row">
			<div class="col-xs-6">Capital </div><div class="col-xs-6">Roseau</div>
			<div class="col-xs-6">Airport </div><div class="col-xs-6">Canefield &amp; Melville Hall</div>
			<div class="col-xs-6">Land Area </div><div class="col-xs-6">289 sq. miles</div>
			<div class="col-xs-6">Population </div><div class="col-xs-6">Approx 77,000</div>
			<div class="col-xs-6">Currency </div><div class="col-xs-6">EC dollar</div>
			<div class="col-xs-12">Dominica National Development Corp.</div>
			<div class="col-sm-6 col-sm-offset-3">(767) 448 2045</div>
			<div class="col-sm-6 col-sm-offset-3">
				<a href="http://www.dominica.dm" target="_blank">www.dominica.dm</a>
			</div>
		  </div>
	   </div>
	</div>
  </div>
  <div class="col-sm-12 col-md-4">
	<div class="row">
	  <div class="dest-img-line col-xs-6 col-md-12">
		<img src="img/destinations/dominica_1.jpg" alt="Antigua beach" class="img-thumbnail"/>
	  </div>
	  <div class="dest-img-line col-xs-6 col-md-12">
		<img src="img/destinations/dominica_2.jpg" alt="Antigua hotel" class="img-thumbnail"/>
	  </div>
	</div>
  </div>
</div>