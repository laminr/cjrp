<nav class="navbar navbar-default Box">
  <div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
    </button>
    <a class="navbar-brand" href="/">
      <img src="img/cjrp-logo.png" id="img-nav-logo" alt="CJRP Travel logo" />
    </a>
  </div>
  <div class="navbar-collapse collapse">
    <ul class="nav navbar-nav">
      <li><a href="news.php">News</a></li>
      <li class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
          Before you Fly
          <b class="caret"></b>
        </a>
        <ul id="menu-b4ufly" class="dropdown-menu"> 
          <li><a href="before-you-fly.php#checkIn">Check In</a></li>
          <li><a href="before-you-fly.php#documentation">Documentation</a></li>
          <li><a href="before-you-fly.php#resa-change">Reservation Changes</a></li>
          <li><a href="before-you-fly.php#special-request">Special Service Request (SSR)</a></li>
          <li><a href="before-you-fly.php#baggage">Baggage</a></li>
          <li><a href="before-you-fly.php#security-tips">Security Tips</a></li>
        </ul>         
      </li>
      <li><a href="schedule.php">Schedule</a></li>
      <li><a href="charters.php">Charters</a></li>
      <li>
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">
            Destinations
            <b class="caret"></b>
          </a>
          <ul class="dropdown-menu"> 
            <li><a href="destinations.php?is=anguilla">Anguilla</a></li>
            <li><a href="destinations.php?is=antigua">Antigua</a></li>
            <li><a href="destinations.php?is=dominica">Dominica</a></li>
            <li><a href="destinations.php?is=nevis">Nevis</a></li>
            <li><a href="destinations.php?is=puertorico">Puerto Rico</a></li>
            <li><a href="destinations.php?is=stbarth">St. Barts</a></li>
            <li><a href="destinations.php?is=stkitts">St. Kitts</a></li>
            <li><a href="destinations.php?is=stmaarten">St. Maarten</a></li>
            <li><a href="destinations.php?is=tortola">Tortola</a></li>           
          </ul> 
      </li>
      <li>
        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
          About Us
          <b class="caret"></b>
        </a>
        <ul class="dropdown-menu"> 
          <li><a href="about-us.php#handling-agent">Handling Agent</a></li>
          <li><a href="about-us.php#travel-agency">Travel Agency</a></li>
          <li><a href="about-us.php#tour-operator">Tour Operator</a></li>
        </ul>                   
      </li>
      <li><a href="contact-us.php">Contact Us</a></li>
    </ul>
    <!--  -->
    <div class="navbar-right social">
      <a href="https://www.facebook.com/flycjrp">
        <img src="img/facebook_blue.png" alt="facebook account" />
      </a>
      <a href="http://www.twitter.com/cjrptravel">
        <img src="img/twitter_blue.png" alt="twitter account" />
      </a>
    </div>

  </div><!--/.nav-collapse -->

</nav>
