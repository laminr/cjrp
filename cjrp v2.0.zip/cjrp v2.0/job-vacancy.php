<!DOCTYPE html>
<html lang="en">
  <head>
    <title><?php include 'title.php' ?></title>
    <?php include 'meta-keywords.php' ?>
    
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet" media="screen">
    <link href="css/ui-lightness/jquery-ui-1.10.3.custom.min.css" rel="stylesheet" media="screen"/>

    <link href="css/commons.css" rel="stylesheet" media="screen">

    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,300' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css'>
    <!--avant la balise-->
    <script src="js/email.js"></script>
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="js/assets/html5shiv.js"></script>
      <script src="js/assets/respond.min.js"></script>
    <![endif]-->
  </head>
  <body id="vacancy">
    
    <div id="login" class="Box">
      <?php include 'login.php' ?>
    </div>
    <header class="container">
      <?php include 'navbar.php' ?>
    </header>
    <div class="container">
      <div class="row">
        <div class="col-xs-12">
          <h1>Job Vacancies</h1>
          <br>
          <h4>General Information.</h4>
          <p>
            Provided you qualify, your application will be processed, and you will be guided through the recruitment process.
          </p>
          <p>
            Please note that there are no vacancies available at this time. We respectfully request that you do not send applications, resumes, or request an application for positions not currently posted. Thank you for your interest in career opportunities at CJRP Travel, The Cheaper Way To Book!
          </p>
          <p>
            If you discover a job that you think is right for you, email your application and resume to our Human Resources Department, at 
            <strong><script>mail("humanresources","cjrptravel",0,"")</script></strong> or 
           mail your application to:
          </p>
          <address class="col-md-offset-1">
            Director, Human Resources<br>
            CJRP Travel, P.O. Box PW5080,<br>
            Coronation Avenue, The Valley<br>
            Anguilla.
          </address>
        </div>
      </div>
    </div>
    <!-- IMG LINE -->
    <div class="img-line"></div>    
    <footer>
      <?php include 'footer.php' ?>
    </footer>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) 
    <script src="//code.jquery.com/jquery.js"></script>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>-->
<!---->
    <script src="js/jquery-1.10.1.min.js"></script>

    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-ui-1.10.3.custom.min.js"></script>
    <script src="js/img-line.js"></script>
    <!-- Placed at the end of the document so the pages load faster
    <script src="../../assets/js/holder.js"></script> -->
    <?php include_once("analyticstracking.php") ?>
  </body>
</html>