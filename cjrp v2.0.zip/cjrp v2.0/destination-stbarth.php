<div class="row col-xs-12">
  <h1>Welcome to <span class="title-cursive">Saint Barts</span></h1>
</div>
<div class="row">
  <div class="col-md-8">
	<p>
		<em>Saint Barth&eacute;lemy</em>, officially the <em>Territorial collectivity of Saint Barth&eacute;lemy</em>, is an overseas collectivity of <em>France</em>.
		It is often abbreviated to <em>Saint-Barth</em> in French, or <em>St. Barts</em> / <em>St. Barths</em> in English.
	</p>
	<p>
		It has been discovered by <em>Columbus</em> in 1493, and named for his brother Bartolomeo, St. Barts was first settled in 1648 by French colonists from the nearby island of St. Kitts.
	</p>
	<p>
		Arriving in <em>St. Barts</em>, you will find yourself transported into a dreamland, a far-away place without the constraints of everyday life. 
	</p>
	<p>
		<em>Excellence</em>, <em>luxury</em>, <em>serenity</em> are the perfect adjectives to describe this unusual island! Nothing is lacking: the picture of perfection, <em>St. Barts</em> appeals to an upscale clientele seeking a garden of earthly delights.
	</p>
	<p>
		The island is the perfect sun-filled destination, especially during the cold winter months in the US or Europe. Superb beaches call for lazy days in the shade of the coconut palms.
	</p>
	<p>
		<em>St. Barts</em> is also known for its fine dining. The diversity of its restaurants allows you to try a large variety of culinary styles, from traditional French to a more West Indian flavor.
	</p>
	<p>
		It is also a paradise for luxury goods in a multitude of small boutiques. Many major brands are represented.
	</p>
	<div class="row dest-info">
		<div class="col-xs-12">
		  <div class="row">
			<div class="col-xs-6">Capital </div><div class="col-xs-6">Gustavia</div>
			<div class="col-xs-6">Airport </div><div class="col-xs-6">St Barthelemy</div>
			<div class="col-xs-6">Land Area </div><div class="col-xs-6">8.5 sq. miles</div>
			<div class="col-xs-6">Population </div><div class="col-xs-6">8,902</div>
			<div class="col-xs-6">Currency </div><div class="col-xs-6">Euro</div>
			<div class="col-xs-6">St. Barths Tourism Board</div>
			<div class="col-xs-6">0590 27 8727</div>
			<div class="col-sm-8 col-sm-offset-2">
				<a href="http://www.saintbarth-tourisme.com" target="_blank">www.saintbarth-tourisme.com</a>
			</div>
		  </div>
		</div>
	</div>
  </div>
  <div class="col-sm-12 col-md-4">
	<div class="row">
	  <div class="dest-img-line col-xs-6 col-md-12">
		<img src="img/destinations/stbarts_1.jpg" alt="St Barts view" class="img-thumbnail"/>
	  </div>
	  <div class="dest-img-line col-xs-6 col-md-12">
		<img src="img/destinations/stbarts_2.jpg" alt="St Barts airport" class="img-thumbnail"/>
	  </div> 
	</div>
  </div>
</div>