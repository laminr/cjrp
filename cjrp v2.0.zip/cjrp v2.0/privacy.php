<!DOCTYPE html>
<html lang="en">
  <head>
    <title><?php include 'title.php' ?></title>
    <?php include 'meta-keywords.php' ?>
    
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet" media="screen">
    <link href="css/ui-lightness/jquery-ui-1.10.3.custom.min.css" rel="stylesheet" media="screen"/>

    <link href="css/privacy.css" rel="stylesheet" media="screen">
    <link href="css/commons.css" rel="stylesheet" media="screen">

    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,300' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css'>

    <!--avant la balise-->
    <script src="js/email.js"></script>

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="js/assets/html5shiv.js"></script>
      <script src="js/assets/respond.min.js"></script>
    <![endif]-->
  </head>
  <body id="privacy">
    
    <div id="login" class="Box">
      <?php include 'login.php' ?>
    </div>
    <header class="container">
      <?php include 'navbar.php' ?>
    </header>
    <div class="container">
      <div class="row">
        <div class="col-xs-12 privacy-line">
          <p>
            As a valued <em>CJRP Travel</em> customer, your privacy is very important to us. This page outlines our policy concerning your personal information. By using CJRP Travel website, you accept the practices described in this Privacy Policy. We may update our Policy from time to time to take account of changing requirements such as changes in technology or legislation, and request that you refer back to this Policy frequently to become aware of any such revisions.
          </p>
        </div>
        <div class="col-xs-12 privacy-line">
          <h4>
            How do I know my personal details are confidential and safe when I purchase flights or access my personal profile through the CJRP Travel website?
          </h4>
          <p>
			To ensure the security of your credit card information when you book flights through cjrptravel.com, we use the latest Secure Socket Layer (SSL) technology. SSL is currently the preferred method to securely transfer credit card and other sensitive data over the Internet. If your browser supports SSL, please select the Secure Mode option when confirming your booking and your credit card and other personal details will be protected by this technology.
          </p>
          <p>
            If your browser does not support SSL, we recommend that you upgrade to the latest version of any browser to enhance the security of further transactions, otherwise the transmission of your personal data may not be protected and CJRP Travel disclaims any responsibility in this regard
          </p>
        </div>
        <div class="col-xs-12 privacy-line">
          <h4>
            What personal information does CJRP Travel collect when I visit the CJRP Travel website?
          </h4>
          <p>
            We do not collect personal information about you when you browse the CJRP Travel website. However, if you wish to book a flight using the site's interactive services, we will require you to complete the Booking Form and provide us with certain information, which may include the following:
          </p>
          <p>
            <ul>
              <li>Name </li>
              <li>Postal Address </li>
              <li>Credit/Debit Card number and expiration date </li>
              <li>Billing address </li>
              <li>Phone numbers </li>
              <li>E-mail address</li>
            </ul>
          </p>
        </div>
        <div class="col-xs-12 privacy-line">
          <h4>
            How will CJRP Travel use my personal information?
          </h4>
          <p>
            We use your personal information to identify you as a customer, to process your booking, to verify credit or other charge card details, to manage your Frequent Flyer Club Account (if applicable) and to deliver relevant information to you in connection with your travel and any ancillary services which you may wish to avail of. Your information may also be used for immigration and customs control (see further below), security, administrative, and legal purposes. For these purposes, we may transmit your personal information to our own offices, authorized agents, other carriers and service providers, credit and charge card companies, data processing companies working on our behalf and to government and enforcement agencies. Your personal information and any records relating to your air travel will also be retained for audit functions.
          </p>
          <p>
            We may also use the personal information of Site Members to provide them with information which we think they may find of interest. This may include information about services, products, special offers and promotions offered by CJRP Travel, other carriers and service providers. We may contact you by any means of communication for which you have given us contact details, including by post, e-mail, pop-up window, fax and telephone. However, you may choose not to receive such information by so indicating on the booking form or on the Site Membership Information form.
          </p>
        </div>
        <div class="col-xs-12 privacy-line">
          <h4>
            Cookies, web beacons and pixel tags and how they can benefit your website experience?
          </h4>
          <p>
            Cookies are very small text files stored on your hard drive. They uniquely identify your computer and allow us to store profile information, improve website security and help us to customize your website experience. A unique user identity is created which ensures that you are not required to re-enter login details as you move throughout the website. Time spent navigating the site is kept to a minimum. As is described in more detail below, they may also be used to assist us in making our website and our emails work more efficiently as well as to provide us with business and marketing information. For more detailed information on cookies, visit www.allaboutcookies.org.
          </p>
        </div>
        <div class="col-xs-12 privacy-line">
          <h4>
            Technology used during your web visit
          </h4>
          <p>
            We contract with online partners to help manage and optimise our internet business and communications and to help us measure the effectiveness of our advertising and how visitors use our site. To do this, we use cookies provided by our online partners on this site. By supplementing our records, this information helps us learn things such as what pages are most attractive to our visitors, which of our products most interest our customers, and what kinds of offers our customers like to see. Although our online partner logs the information coming from our site on our behalf, we control how that data may and may not be used.
          </p>
          <p>
            If you do not want to help us learn how to improve our site, products, offers and marketing strategy, you can "opt-out" of this website analysis tool. How you do this will depend upon the internet browser you use (for example, Internet Explorer 5, Netscape 4 or Opera etc). Please refer to the relevant internet browser manufacturer's website where you should be able to receive all the information required.
          </p>
        </div>
        <div class="col-xs-12 privacy-line">
          <h4>
            Technology used in our e-mails
          </h4>
          <p>
            In addition, we may use e-mail delivery and marketing companies to send e-mails that you have consented to receive. Pixel tags and cookies may be used in those e-mails and at our website to help us measure the effectiveness of our advertising and how visitors use our website.
          </p>
          <p>
            The following is a list of all the cookies that CJRP Travel or its third party contractors may use for this purpose:
          </p>
          <p>
            "Email Opening Sensing": In order to understand how our readers interact with the emails and the content that we send, we may use pixels in the text in order to understand who has opened the emails that they have been sent.
          </p>
          <p>
            "Message Format Sensing": In order to provide our content in the most interesting way, we may also use pixels to learn whether you can receive emails in text or html form.
          </p>
          <p>
            "Click-Through Sensing": If you click on a link in the email, we may set a cookie on your browser.
          </p>
          <p>
            "Response Analysis": If you click on a link in the email, we may set a cookie on your browser. If you visit our website as a result of clicking on a link, we are able to understand how you interact with the pages of our website through the combination of the cookie and pixels set on the pages of our website. This enables us to understand what interested you in our emails and what did not, and what interests you about our website and what does not. We can then try to send you more interesting information in the future. Please note that this information is for our use only - we do not disclose or share this information with any third parties. If you do not wish this to happen, you can change the cookie settings in your browser.
          </p>
        </div>
        <div class="col-xs-12 privacy-line">
          <h4>
            Is it easy to update and alter my personal information?
          </h4>
          <p>
            If you have any other concerns, suggestions or questions about any issues relating to privacy on the CJRP Travel web site, please contact us via e-mail, <em><script>mail("info","cjrptravel",0,"")</script></em>.
          </p>  
        </div>
      </div>
    </div>
    <!-- IMG LINE -->
    <div class="img-line"></div>    
    <footer>
      <?php include 'footer.php' ?>
    </footer>

    <script src="js/jquery-1.10.1.min.js"></script>

    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-ui-1.10.3.custom.min.js"></script>
    <script src="js/img-line.js"></script>

    <?php include_once("analyticstracking.php") ?>

  </body>
</html>