<!DOCTYPE html>
<html lang="en">
  <head>
    <title><?php include 'title.php' ?></title>
    <?php include 'meta-keywords.php' ?>
    
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet" media="screen">
    <link href="css/commons.css" rel="stylesheet" media="screen">

    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,300' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css'>
    <!--avant la balise-->
    <script src="js/email.js"></script>
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="js/assets/html5shiv.js"></script>
      <script src="js/assets/respond.min.js"></script>
    <![endif]-->
  </head>
  <body id="contact-us">
    
    <div id="login" class="Box">
      <?php include 'login.php' ?>
    </div>
    <header class="container">
      <?php include 'navbar.php' ?>
    </header>
    <div class="container">
      <div class="row">
        <div class="col-xs-12">
          <h1>Contacting Us</h1>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <h2>Reservations</h2>
          <table class="table">
            <tr>
              <td>
                <span class="glyphicon glyphicon-earphone"></span>
                +1-264-497-2577
              </td>
              <td>from most destinations within the Caribbean Region.</td>
            </tr>
            <tr>
              <td>
                <span class="glyphicon glyphicon-earphone"></span>
                465-2577
              </td>
              <td>for customers calling from St. Kitts</td>
            </tr>
            <tr>
              <td colspan="2">
                <span class="glyphicon glyphicon-envelope"></span>
                Email: <script>mail("reservations","cjrptravel",0,"")</script>
              </td>
            </tr>
          </table>
        </div>
        <div class="col-md-6">
          <h2>Baggage</h2>
          <div>
            Please help us to assist you efficiently by including the following information in your email:
          </div>
          <ul>
            <li>Name of passengers</li>
            <li>Nature of the problem/complaint</li>
            <li>Date of incident, flight information, Island where incident occurred</li>
            <li>Amount of expenditure, if any</li>
            <li>Mailing address</li>
          </ul>
          <strong>
            Please  keep receipts for any expenditures and the Passenger Receipt from your ticket. 
          </strong>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <h2>Station</h2>
          <table class="table">
            <thead>
              <tr>
                <th>Baggage</th>
                <th>Contact Numbers</th>
                <th>Email</th>
                <th>Hours of Operation</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Anguilla</td>
                <td>
                  +1-264-497-2577
                </td>
                <td rowspan="2"><script>mail("info","cjrptravel",0,"")</script></td>
                <td>08:00 am - 5:00 pm</td>
              </tr>
              <tr>
                <td>St. Kitts</td>
                <td>
                  +1-869-465-2577
                </td>
                <td>09:00 am - 5:00 pm</td>
              </tr>
            </tbody>
          </table>
        </div>
        <div class="col-md-6">
          <h2>Questions</h2>
          <div>Do you have a question about any CJRP Travel services or products?</div>
          <span class="glyphicon glyphicon-envelope"></span>
          Email: <script>mail("customerrelations","cjrptravel",0,"")</script>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <h2>Compliments</h2>
          <div><em>CJRP Travel</em> strives to <em>recognize employees that go the extra mile.</em></div>
          <div>Let us know when an employee has delivered exceptional customer service. </div>
          <span class="glyphicon glyphicon-envelope"></span> Email: <script>mail("customerrelations","cjrptravel",0,"")</script>
        </div>
        <div class="col-md-6">
          <h2>New Business</h2>
          Have an idea how our business can work better with yours? <br>
          <span class="glyphicon glyphicon-envelope"></span> Email: <script>mail("info","cjrptravel",0,"")</script>
        </div>
      </div>
    </div>
    <!-- IMG LINE -->
    <div class="img-line last"></div>    
    <footer>
      <?php include 'footer.php' ?>
    </footer>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) 
    <script src="//code.jquery.com/jquery.js"></script>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>-->
<!---->
    <script src="js/jquery-1.10.1.min.js"></script>

    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-ui-1.10.3.custom.min.js"></script>
    <script src="js/img-line.js"></script>
    <!-- Placed at the end of the document so the pages load faster
    <script src="../../assets/js/holder.js"></script> -->
    <?php include_once("analyticstracking.php") ?>
  </body>
</html>