<meta charset="UTF-8" />
<meta name="revisit-after" content="30 days" />
<meta name="robots" content="index,follow" />
<!--<meta name="author" content="" />-->
<meta name="copyright" content="Copyright CJRP Travel : Caribbean Travel agency" />
<meta name="distribution" content="global" />
<meta name="description" content="CJRP Travel Agency is in the beautiful island of Anguilla. Need an airline to get you there on time? Choose CJRP Travel where it's safe, affordable and worth every dime. CJRP Travel has become one of the leading travel agencies in Anguilla. We have a dedicated team of travel professionals with a combined experience in the tourism industry for over 20 years." />
<meta name="keywords" content="cjrp travel, travel agency, caribbean, dominica, anguilla, nevis, stkitts, cjrptravel, flycjrp, vi airlink, sanjuan, st maarten, st barths, tortola, tradewind aviation" />

<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />

<link rel="icon" type="image/png" href="img/favicon.png" />