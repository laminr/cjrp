<?php

/* cjrpWebsiteBundle:Hotel:hotelBookingForm.html.twig */
class __TwigTemplate_f1c977d798ec5fd7a8f8ec32a94527fd6428aa426ad5418ad562b3f6c41f8773 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "
<div class=\"col-md-10\">
  <form role=\"form\" class=\"form-horizontal\" id=\"hotel-booking-form\" method=\"POST\" action=\"";
        // line 3
        echo $this->env->getExtension('routing')->getPath("_hotelBookingSearch");
        echo "\">
    <div>
      <div class=\"line clearfix\">
        <div class=\"col-md-6 control-label\">Destination</div>
        <div class=\"col-md-6\">
          <select name=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["hotelForm"]) ? $context["hotelForm"] : $this->getContext($context, "hotelForm")), "country"), "vars"), "full_name"), "html", null, true);
        echo "\" class=\"form-control\" required=\"required\">
              <option value=\"\"></option> 
              <option value=\"Anguilla\">Anguilla</option> 
              <option value=\"Antigua\">Antigua</option> 
              <option value=\"Barbuda\">Barbuda</option>
              <option value=\"Barbados\">Barbados</option> 
              <option value=\"Dominica\">Dominica</option> 
              <option value=\"Dominican Republic\">Dominican Republic</option> 
              <option value=\"Grenada\">Grenada</option> 
              <option value=\"Guadeloupe\">Guadeloupe</option> 
              <option value=\"Jamaica\">Jamaica</option> 
              <option value=\"Martinique\">Martinique</option> 
              <option value=\"Puerto Rico\">Puerto Rico</option> 
              <option value=\"Saint Kitts\">Saint Kitts</option> 
              <option value=\"Nevis\">Nevis</option> 
              <option value=\"Saint Lucia\">Saint Lucia</option> 
              <option value=\"Saint Martin\">Saint Martin</option> 
              <option value=\"Saint Vincent\">Saint Vincent</option>
              <option value=\"Trinidad\">Trinidad</option> 
              <option value=\"Tobago\">Tobago</option> 
              <option value=\"US Virgin Islands\">US Virgin Islands</option> 
              <option value=\"Trinidad\">Trinidad (POS)</option> 
          </select>
        </div>
      </div>
      <div class=\"line clearfix\">
        <div class=\"col-md-6\">
          <div class=\"row\">
            <div class=\"col-md-12 control-label\">Check-In date</div>
            <div class=\"col-md-12\">
              <input id=\"check-in-date\" name=\"";
        // line 38
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["hotelForm"]) ? $context["hotelForm"] : $this->getContext($context, "hotelForm")), "checkInDate"), "vars"), "full_name"), "html", null, true);
        echo "\" class=\"col-xs-12 form-control datepicker\" size=\"16\" type=\"text\" value=\"\" placeholder=\"Check In\" required=\"required\" autocomplete=\"off\" />
            </div>
          </div>
          <div class=\"row\">
            <div class=\"col-md-12 control-label\">Check-Out date</div>
            <div class=\"col-md-12\">
              <input id=\"check-out-date\" name=\"";
        // line 44
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["hotelForm"]) ? $context["hotelForm"] : $this->getContext($context, "hotelForm")), "checkOutDate"), "vars"), "full_name"), "html", null, true);
        echo "\" class=\"col-xs-12 form-control datepicker\" size=\"16\" type=\"text\" value=\"\" placeholder=\"Check Out\" required=\"required\" autocomplete=\"off\" />
            </div>
          </div>
        </div>
        <div class=\"col-md-6\">
          <div class=\"row\"> 
            <div class=\"col-xs-4\">Adults</div>
            <div class=\"col-xs-8\">
              <select class=\"form-control\" name=\"";
        // line 52
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["hotelForm"]) ? $context["hotelForm"] : $this->getContext($context, "hotelForm")), "hotelAdults"), "vars"), "full_name"), "html", null, true);
        echo "\" required=\"required\"> 
                <option value=\"\"></option>
                <option value=\"1\" selected=\"selected\">1 Adult</option>  
                <option value=\"2\">2 Adults</option>  
                <option value=\"3\">3 Adults</option>  
                <option value=\"4\">4 Adults</option>  
                <option value=\"5\">5 Adults</option>  
                <option value=\"6\">6 Adults</option>  
                <option value=\"7\">7 Adults</option>
              </select>
            </div>
            <div class=\"col-xs-4\">Children</div>
            <div class=\"col-xs-8\">
              <select class=\"form-control\" name=\"";
        // line 65
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["hotelForm"]) ? $context["hotelForm"] : $this->getContext($context, "hotelForm")), "hotelChildren"), "vars"), "full_name"), "html", null, true);
        echo "\"> 
                 <option value=\"0\">0 Child</option>  
                 <option value=\"1\">1 Childs</option>  
                 <option value=\"2\">2 Childs</option>  
                 <option value=\"3\">3 Childs</option>  
                 <option value=\"4\">4 Childs</option>  
                 <option value=\"5\">5 Childs</option>  
                 <option value=\"6\">6 Childs</option>  
                 <option value=\"7\">7 Childs</option>  
              </select>
            </div>
            <div class=\"col-xs-4\">Infant</div>
            <div class=\"col-xs-8\">
              <select class=\"form-control\" name=\"";
        // line 78
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["hotelForm"]) ? $context["hotelForm"] : $this->getContext($context, "hotelForm")), "hotelMinor"), "vars"), "full_name"), "html", null, true);
        echo "\"> 
                 <option value=\"0\">0 Infant</option>  
                 <option value=\"1\">1 Infants</option>  
                 <option value=\"2\">2 Infants</option>  
                 <option value=\"3\">3 Infants</option>  
                 <option value=\"4\">4 Infants</option>  
                 <option value=\"5\">5 Infants</option>  
                 <option value=\"6\">6 Infants</option>  
                 <option value=\"7\">7 Infants</option>  
              </select>
            </div>
            <div class=\"col-xs-4\">Rooms</div>
            <div class=\"col-xs-8\">
              <select class=\"form-control\" name=\"";
        // line 91
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["hotelForm"]) ? $context["hotelForm"] : $this->getContext($context, "hotelForm")), "nbrRooms"), "vars"), "full_name"), "html", null, true);
        echo "\">
                 <option value=\"1\">1</option>  
                 <option value=\"2\">2</option>  
                 <option value=\"3\">3</option>  
                 <option value=\"4\">4</option>  
              </select>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class=\"col-md-12\">
      <button name=\"";
        // line 103
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["hotelForm"]) ? $context["hotelForm"] : $this->getContext($context, "hotelForm")), "hotelSubmit"), "vars"), "full_name"), "html", null, true);
        echo "\" type=\"submit\" class=\"btn btn-default pull-right\" >Search</button>
    </div>
  </form>
  <div id=\"trouble-booking\">
    <div class=\"\">
      <div>Need help booking ?</div>
      <div><i class=\"glyphicon glyphicon-earphone\"></i> +1-264-498-4578 from most destinations within the Caribbean Region.</div>
      <div><i class=\"glyphicon glyphicon-earphone\"></i> +1-786-453-1448 for customers calling from Canada, USA &amp; UK</div>
    </div>
  </div>
</div>";
    }

    public function getTemplateName()
    {
        return "cjrpWebsiteBundle:Hotel:hotelBookingForm.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  147 => 103,  132 => 91,  116 => 78,  100 => 65,  84 => 52,  73 => 44,  64 => 38,  31 => 8,  23 => 3,  19 => 1,);
    }
}
