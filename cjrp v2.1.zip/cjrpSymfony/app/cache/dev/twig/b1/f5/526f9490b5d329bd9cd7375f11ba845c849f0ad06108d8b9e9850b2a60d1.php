<?php

/* cjrpWebsiteBundle:Index:index.html.twig */
class __TwigTemplate_b1f5526f9490b5d329bd9cd7375f11ba845c849f0ad06108d8b9e9850b2a60d1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("cjrpWebsiteBundle:Base:base.html.twig");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'pageId' => array($this, 'block_pageId'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "cjrpWebsiteBundle:Base:base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        echo " CJRP Travel - The Cheaper Way To Book ";
    }

    // line 4
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 5
        echo "    <link href=\"http://codeorigin.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css\" rel=\"stylesheet\"  media=\"screen\">
    <link href=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("css/index.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" media=\"screen\">
";
    }

    // line 9
    public function block_pageId($context, array $blocks = array())
    {
        echo "id=\"index\"";
    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        echo "    

    <div class=\"container\">
      <section class=\"row\">
        <div class=\"col-xs-12 col-sm-6 col-md-4\">
          <div class=\"\" id=\"booking-form\" >
            <div class=\"row\">
              <ul id=\"booking-tab\">
                <li class=\"active col-xs-4\"><a href=\"#flight-tab\">Flights</a></li>
                <li class=\"col-xs-4\"><a href=\"#ferry-tab\">Ferry</a></li>
                <li class=\"col-xs-4\"><a href=\"#check-online\">CheckIn</a></li>
              </ul>
            </div>
            <div class=\"tab-content\">
              <div class=\"tab-pane active fade in\" id=\"flight-tab\">
                <!-- BOOKING FORM -->
                ";
        // line 26
        echo twig_include($this->env, $context, "cjrpWebsiteBundle:Index:flight-booking.html.twig");
        echo "
              </div>
              <div class=\"tab-pane fade\" id=\"ferry-tab\">
                 ";
        // line 29
        echo twig_include($this->env, $context, "cjrpWebsiteBundle:Index:ferry-booking.html.twig");
        echo "
              </div>
              <div class=\"tab-pane fade\" id=\"check-online\">
                  ";
        // line 32
        echo twig_include($this->env, $context, "cjrpWebsiteBundle:Index:checkin.html.twig");
        echo "
              </div>
            </div>            
          </div>
        </div> 
        <!--
        <div class=\"clearfix visible-sm\"></div>    
        -->
        <div id=\"myCarousel\" class=\"hidden-xs col-sm-6 col-md-8\" >
          <div class=\"carousel slide\">
            <ol class=\"carousel-indicators\">
              <li data-target=\"#myCarousel\" data-slide-to=\"0\" class=\"active\"></li>
              <li data-target=\"#myCarousel\" data-slide-to=\"1\"></li>
              <li data-target=\"#myCarousel\" data-slide-to=\"2\"></li>
              <li data-target=\"#myCarousel\" data-slide-to=\"3\"></li>
              <li data-target=\"#myCarousel\" data-slide-to=\"4\"></li>           
            </ol>
            <!-- Carousel items -->
            <div class=\"carousel-inner\">
              <div class=\"active item\">
                <img src=\"";
        // line 52
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("img/slide/slide1.jpg"), "html", null, true);
        echo "\">
                <div class=\"carousel-caption\">
                      <div>The cheaper way to book..</div>
                      <div class=\"small\">Some people dream of  success. We make it happen.</div>
                  </div>
              </div>
              <div class=\"item\">
                <img src=\"";
        // line 59
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("img/slide/slide2.jpg"), "html", null, true);
        echo "\">
                <div class=\"carousel-caption\">
                      <div>The cheaper way to book..</div>
                      <div class=\"small\">Some people dream of  success. We make it happen.</div>
                  </div>            
              </div>
              <div class=\"item\">
                <img src=\"";
        // line 66
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("img/slide/slide3.jpg"), "html", null, true);
        echo "\">
                <div class=\"carousel-caption\">
                      <div>The cheaper way to book..</div>
                      <div class=\"small\">Some people dream of  success. We make it happen.</div>
                  </div>            
              </div>
              <div class=\"item\">
                <img src=\"";
        // line 73
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("img/slide/slide4.jpg"), "html", null, true);
        echo "\">
                <div class=\"carousel-caption\">
                      <div>The cheaper way to book..</div>
                      <div class=\"small\">Some people dream of  success. We make it happen.</div>
                  </div>            
              </div>
              <div class=\"item\">
                <img src=\"";
        // line 80
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("img/slide/slide5.jpg"), "html", null, true);
        echo "\">
                <div class=\"carousel-caption\">
                      <div>The cheaper way to book..</div>
                      <div class=\"small\">Some people dream of  success. We make it happen.</div>
                  </div>            
              </div>        
            </div>
            <!-- Carousel nav -->
            <a class=\"left carousel-control hidden-sm\" href=\"#myCarousel\" data-slide=\"prev\"><span class=\"glyphicon glyphicon-chevron-left\"></span></a>
            <a class=\"right carousel-control hidden-sm\" href=\"#myCarousel\" data-slide=\"next\"><span class=\"glyphicon glyphicon-chevron-right\"></span></a>
          </div>
        </div>
      </section>
      <section id=\"other-booking\" class=\"row\">
        <div class=\"col-md-12\">
          <h1>Our services</h1>          
        </div>  
        <div class=\"col-md-4\">
          <div class=\"thumbnails\">
            <div class=\"imgOtherBooking\">
              <img src=\"";
        // line 100
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("img/booking-hotel.jpg"), "html", null, true);
        echo "\" alt=\"hotel booking\" class=\"img-thumbnail img-responsive\">
            </div>
            <div class=\"caption\">
              <h2 class=\"container longer\">Hotels &amp; Villas</h2>
              <p>You have an idea about where you want your vacation to be? Need some help getting a hotel? </p>
              <p>We are the experts at helping our clients make their vacation a reality. We  look forward to recommending a hotel that suits your needs and caters to your expectations</p>
            </div>
            <a href=\"";
        // line 107
        echo $this->env->getExtension('routing')->getPath("_hotelBooking");
        echo "\" class=\"btn btn-primary\">Book now</a>
          </div>
        </div>
        <div class=\"col-md-4\">
          <div class=\"thumbnails\">
            <div class=\"imgOtherBooking\">
              <img src=\"";
        // line 113
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("img/booking-car.jpg"), "html", null, true);
        echo "\" alt=\"car rental\" class=\"img-thumbnail img-responsive\">
            </div>
            <div class=\"caption\">
              <h2 class=\"container\">Cars</h2>
              <p>CJRP Travel has partnered with several car rental brands to offer discounted rental rates anywhere in the world, to our clients.</p>
              <p> Book your next regional travel ticket with us and enjoy discounted vehicle rental rates from our partners.</p>
            </div>
            <a href=\"";
        // line 120
        echo $this->env->getExtension('routing')->getPath("_carBooking");
        echo "\" class=\"btn btn-primary\">Book now</a>
          </div>          
        </div>
        <div class=\"col-md-4\">
          <div class=\"thumbnails\">
            <div class=\"imgOtherBooking\">
              <img src=\"";
        // line 126
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("img/booking-cruise.jpg"), "html", null, true);
        echo "\" alt=\"cruise booking\" class=\"img-thumbnail img-responsive\">
            </div>
            <div class=\"caption\">
              <h2 class=\"container\">Cruises</h2>
              <p>Because it's more than just another vacation vacation -it's an experience like none other. </p>
              <p>Not only are there lots of amazing things to do onboard but there are also an endless number of fun onshore activities, too. On one cruise you will visit different destinations.</p>
            </div>
           <a href=\"";
        // line 133
        echo $this->env->getExtension('routing')->getPath("_cruiseBooking");
        echo "\" class=\"btn btn-primary\">Book now</a>
          </div>
        </div>
      </section>
      <section>
        <div class=\"row\">
          <div class=\"col-xs-12 col-sm-6 col-md-8\">
            <h2 class=\"col-md-12\">The caribbean can be yours!</h2>
            <div class=\" clearfix\" id=\"news\">
              <div class=\"visible-md visible-lg col-md-6 row\">
                <img src=\"";
        // line 143
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("img/caribbean.jpg"), "html", null, true);
        echo "\" alt=\"offices\" class=\"img-responsive thumbnail\">
              </div>
              <div class=\"col-sm-12 col-md-6\">
                <p>CJRP travel, now offering daily flight to :</p>
                <p>
                  <em>Anguilla</em>, <em>St Kitts</em>, &amp; <em>Tortola</em>
                </p>
                <br>
                <p>
                  <em>One way's</em> starting from <strong><em>\$69.99 USD</em></strong> <br/>
                  <em>Round trip's</em> starting from <strong><em>\$189.99 USD.</em></strong>
                </p>            
              </div>
            </div>
          </div>
          
          <div class=\"col-xs-12 col-sm-6 col-md-4\" id=\"testimonial\">
            <h2>Slogan</h2>
              <div class=\"col-md-12\">
                <div id=\"quote\">
                  <em>
                    &laquo; Need an airline to get you there on time? <br> Choose CJRP Travel where it's safe, affordable and worth every dime &raquo;
                  </em>
                </div>
                <div id=\"written-by\">
                  Written by <strong>Karece Webster</strong>
                </div>
              </div>
          </div>
        </div>
      </section>
    </div>
    <div id=\"fb-root\"></div>

";
    }

    // line 178
    public function block_javascripts($context, array $blocks = array())
    {
        // line 179
        echo "    <script src=\"http://codeorigin.jquery.com/ui/1.10.3/jquery-ui.min.js\"></script>
    <script src=\"";
        // line 180
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("js/index.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 181
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("js/flight-booking.js"), "html", null, true);
        echo "\"></script>
";
    }

    public function getTemplateName()
    {
        return "cjrpWebsiteBundle:Index:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  284 => 181,  280 => 180,  277 => 179,  274 => 178,  235 => 143,  222 => 133,  212 => 126,  203 => 120,  193 => 113,  184 => 107,  174 => 100,  151 => 80,  141 => 73,  131 => 66,  121 => 59,  111 => 52,  88 => 32,  82 => 29,  76 => 26,  56 => 10,  50 => 9,  44 => 6,  41 => 5,  38 => 4,  32 => 3,);
    }
}
