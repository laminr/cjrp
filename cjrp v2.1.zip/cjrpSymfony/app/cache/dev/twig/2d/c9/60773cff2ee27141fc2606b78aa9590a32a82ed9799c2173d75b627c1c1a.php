<?php

/* cjrpWebsiteBundle:Base:base.html.twig */
class __TwigTemplate_2dc960773cff2ee27141fc2606b78aa9590a32a82ed9799c2173d75b627c1c1a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'pageId' => array($this, 'block_pageId'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        ob_start();
        // line 2
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <meta name=\"revisit-after\" content=\"30 days\" />
        <meta name=\"robots\" content=\"index,follow\" />
        <!--<meta name=\"author\" content=\"\" />-->
        <meta name=\"copyright\" content=\"Copyright CJRP Travel : Caribbean Travel agency\" />
        <meta name=\"distribution\" content=\"global\" />
        <meta name=\"description\" content=\"CJRP Travel Agency is in the beautiful island of Anguilla. It has become one of the leading travel agencies in Anguilla. We have a dedicated team of travel professionals with a combined experience in the tourism industry for over 20 years, who are always ready and willing to assist. CJRP Travel is owned and operated by CJRP Group Anguilla Limited. We have a combined experience of over 10 years in the industry. Running CJRP Travel has been both our business and our hobby; we are reliable and trustworthy and have earned a reputation for excellence.\" />
        <meta name=\"keywords\" content=\"cjrp travel, travel agency, caribbean dominica, anguilla, nevis, stkitts, cjrptravel, flycjrp, viairlink, sanjuan, st maarten, st barths, tortola, tradewind aviation\" />

        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />
        <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\" />

        <title>";
        // line 17
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        
        <!--<link href=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("css/bootstrap.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" media=\"screen\">-->
        
        <link href=\"//netdna.bootstrapcdn.com/bootstrap/3.0.2/css/bootstrap.min.css\" rel=\"stylesheet\" media=\"screen\">
        <link href=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("css/commons.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" media=\"screen\">

        ";
        // line 24
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 25
        echo "        <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,300' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css'>        

        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        // line 28
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("favicon.png"), "html", null, true);
        echo "\" />
        
        <script src=\"";
        // line 30
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("js/email.js"), "html", null, true);
        echo "\"></script>
        <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!--[if lt IE 9]>
          <script src=\"js/assets/html5shiv.js\"></script>
          <script src=\"js/assets/respond.min.js\"></script>
        <![endif]-->
    </head>
    <body ";
        // line 37
        $this->displayBlock('pageId', $context, $blocks);
        echo ">

        <div id=\"login\" class=\"Box\">
         ";
        // line 40
        echo twig_include($this->env, $context, "cjrpWebsiteBundle::login.html.twig");
        echo "
        </div>
        <header class=\"container\">
            ";
        // line 43
        echo twig_include($this->env, $context, "cjrpWebsiteBundle::navbar.html.twig");
        echo "
        
            <div class=\"pull-right\" style=\"margin-top:-15px; margin-bottom:-10px;\">
                <div class=\"g-plusone\" data-size=\"medium\" data-annotation=\"none\"></div>
            <div class=\"fb-like\" data-href=\"https://www.facebook.com/flycjrp\" data-ref=\"cjrp_website\" data-width=\"The pixel width of the plugin\" data-height=\"The pixel height of the plugin\" data-colorscheme=\"light\" data-layout=\"button_count\" data-action=\"like\" data-show-faces=\"true\" data-send=\"false\"></div>
        </div>
        </header>

        ";
        // line 51
        $this->displayBlock('body', $context, $blocks);
        // line 52
        echo "
        <!-- IMG LINE -->
        <div class=\"img-line last\"></div>
        <footer>
          ";
        // line 56
        echo twig_include($this->env, $context, "cjrpWebsiteBundle::footer.html.twig");
        echo "
        </footer>

        <script>
            var symPath = \"";
        // line 60
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("img"), "html", null, true);
        echo "\";
        </script>
        <!-- <script src=\"//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js\"></script> -->
        <script src=\"";
        // line 63
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("js/jquery-1.10.1.min.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 64
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("js/bootstrap.min.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 65
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("js/img-line.js"), "html", null, true);
        echo "\"></script>
        
        ";
        // line 67
        $this->displayBlock('javascripts', $context, $blocks);
        echo "\t\t
\t\t
        <script>
\t    \t// FACEBOOK
\t      (
\t        function(d, s, id) {
\t          var js, fjs = d.getElementsByTagName(s)[0];
\t          if (d.getElementById(id)) return;
\t          js = d.createElement(s); js.id = id;
\t          js.src = \"//connect.facebook.net/en/all.js#xfbml=1\";
\t          fjs.parentNode.insertBefore(js, fjs);
\t        }
\t        (document, 'script', 'facebook-jssdk')
\t      );
\t    </script>
\t    <!-- G+ > Place this tag after the last +1 button tag. -->
\t\t<script type=\"text/javascript\">
\t\t  (function() {
\t\t    var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
\t\t    po.src = 'https://apis.google.com/js/plusone.js';
\t\t    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
\t\t  })();
\t\t</script>
\t\t        
        ";
        // line 91
        echo twig_include($this->env, $context, "cjrpWebsiteBundle::analyticstracking.html.twig");
        echo "       
    </body>
</html>
";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    // line 17
    public function block_title($context, array $blocks = array())
    {
        echo "CJRP Booking";
    }

    // line 24
    public function block_stylesheets($context, array $blocks = array())
    {
    }

    // line 37
    public function block_pageId($context, array $blocks = array())
    {
    }

    // line 51
    public function block_body($context, array $blocks = array())
    {
    }

    // line 67
    public function block_javascripts($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "cjrpWebsiteBundle:Base:base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  195 => 67,  190 => 51,  180 => 24,  174 => 17,  165 => 91,  138 => 67,  133 => 65,  129 => 64,  125 => 63,  119 => 60,  112 => 56,  106 => 52,  104 => 51,  93 => 43,  87 => 40,  81 => 37,  71 => 30,  66 => 28,  59 => 24,  54 => 22,  48 => 19,  43 => 17,  26 => 2,  24 => 1,  187 => 91,  185 => 37,  181 => 89,  178 => 88,  175 => 87,  161 => 76,  157 => 74,  153 => 72,  151 => 71,  147 => 70,  140 => 66,  120 => 49,  114 => 46,  108 => 43,  102 => 40,  96 => 37,  90 => 34,  72 => 18,  70 => 17,  61 => 25,  55 => 11,  49 => 8,  44 => 6,  41 => 5,  38 => 4,  32 => 3,);
    }
}
