<?php

/* cjrpWebsiteBundle::footer.html.twig */
class __TwigTemplate_8b928d870f1a28b9c9b6428593edb5d7c62658f7207a0e1bdd3df90a54c44244 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"container\">
  <div class=\"col-md-12\">
    <div class=\"social\">
      <a href=\"https://www.facebook.com/flycjrp\">
        <img src=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("img/facebook.png"), "html", null, true);
        echo "\" alt=\"facebook account\">
      </a>
      <a href=\"http://www.twitter.com/cjrptravel\">
        <img src=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("img/twitter.png"), "html", null, true);
        echo "\" alt=\"twitter account\">
      </a>
    </div>
    <ul id=\"footer-list\" class=\"col-md-8 col-md-offset-2\">  
      <li><a href=\"/\">Home</a></li>
      <li><a href=\"http://login.cjrptravel.com/\">Agent / Employee Log-In</a></li>
      <li><a href=\"";
        // line 14
        echo $this->env->getExtension('routing')->getPath("_jobVacancy");
        echo "\">Job Vacancies</a></li>
      <li><a href=\"";
        // line 15
        echo $this->env->getExtension('routing')->getPath("_privacy");
        echo "\">Privacy Policy</a></li>
      <li><a href=\"";
        // line 16
        echo $this->env->getExtension('routing')->getPath("_terms");
        echo "\">Terms &amp; Conditions</a></li>
    </ul>
    <div id=\"proud\">&copy; CJRP Travel - A Proud Member Of CJRP Group.</div>
  </div>
</div>";
    }

    public function getTemplateName()
    {
        return "cjrpWebsiteBundle::footer.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 14,  25 => 5,  132 => 91,  116 => 78,  100 => 65,  84 => 52,  64 => 38,  31 => 8,  23 => 3,  159 => 67,  145 => 59,  139 => 56,  135 => 55,  131 => 54,  115 => 44,  111 => 43,  107 => 42,  103 => 41,  99 => 40,  95 => 39,  91 => 38,  77 => 30,  73 => 44,  67 => 26,  63 => 25,  51 => 22,  47 => 21,  37 => 14,  29 => 9,  19 => 1,  195 => 67,  190 => 51,  180 => 24,  174 => 17,  165 => 91,  138 => 67,  133 => 65,  129 => 64,  125 => 63,  119 => 45,  112 => 56,  106 => 52,  104 => 51,  93 => 43,  87 => 37,  81 => 37,  71 => 30,  66 => 28,  59 => 24,  54 => 22,  48 => 16,  43 => 17,  26 => 2,  24 => 1,  187 => 91,  185 => 37,  181 => 89,  178 => 88,  175 => 87,  161 => 76,  157 => 74,  153 => 64,  151 => 71,  147 => 103,  140 => 66,  120 => 49,  114 => 46,  108 => 43,  102 => 40,  96 => 37,  90 => 34,  72 => 18,  70 => 17,  61 => 25,  55 => 23,  49 => 8,  44 => 15,  41 => 5,  38 => 4,  32 => 3,);
    }
}
