<?php

/* cjrpWebsiteBundle:Index:checkin.html.twig */
class __TwigTemplate_4c15c770b3942281de6fcaf60c6a10400c123030262579bf28ba588ec7a8c225 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!-- https://booksecure.cjrptravel.com/process/search -->
<form role=\"form\" class=\"form-horizontal\" id=\"checkIn-form\" action=\"https://booksecure.cjrptravel.com/checkin/checkin\" method=\"post\">

  <div class=\"row lines\">
      <p>To check in, please enter the confirmation number of your reservation below, followed by the last name of the first passenger on the reservation.</p>
      <p>You may check in up to 24 hours prior to the scheduled departure of your flight.</p>
      <div class=\"form-label\">Confirmation Number:</div>
      <input type=\"text\" class=\"form-control\" name=\"conf_number\" />

      <div class=\"form-label\">Last Name:</div>
      <input type=\"text\" class=\"form-control\" name=\"name_last\" />
  </div>
  <div id=\"submit-flight\">
    <button type=\"submit\" class=\"btn btn-default pull-right\">Submit</button>
  </div>
</form>";
    }

    public function getTemplateName()
    {
        return "cjrpWebsiteBundle:Index:checkin.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  183 => 98,  172 => 96,  161 => 90,  150 => 88,  139 => 82,  128 => 80,  117 => 74,  106 => 72,  95 => 70,  89 => 69,  201 => 116,  190 => 114,  186 => 113,  179 => 108,  168 => 95,  164 => 105,  157 => 100,  146 => 87,  142 => 97,  135 => 92,  124 => 79,  113 => 88,  107 => 87,  19 => 1,  284 => 181,  280 => 180,  277 => 179,  274 => 178,  235 => 143,  222 => 133,  212 => 126,  203 => 120,  193 => 113,  184 => 107,  174 => 100,  151 => 80,  141 => 73,  131 => 66,  121 => 59,  111 => 52,  88 => 32,  82 => 29,  76 => 26,  56 => 10,  50 => 9,  44 => 6,  41 => 5,  38 => 4,  32 => 3,);
    }
}
