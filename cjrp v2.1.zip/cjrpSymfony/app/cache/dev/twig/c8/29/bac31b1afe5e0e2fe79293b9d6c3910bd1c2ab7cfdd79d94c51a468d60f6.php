<?php

/* cjrpWebsiteBundle::navbar.html.twig */
class __TwigTemplate_c829bac31b1afe5e0e2fe79293b9d6c3910bd1c2ab7cfdd79d94c51a468d60f6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<nav class=\"navbar navbar-default Box\">
  <div class=\"navbar-header\">
    <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
      <span class=\"icon-bar\"></span>
      <span class=\"icon-bar\"></span>
      <span class=\"icon-bar\"></span>
    </button>
    <a class=\"navbar-brand\" href=\"/\">
      <img src=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("img/cjrp-logo.png"), "html", null, true);
        echo "\" id=\"img-nav-logo\" alt=\"CJRP Travel logo\" />
    </a>
  </div>
  <div class=\"navbar-collapse collapse\">
    <ul class=\"nav navbar-nav\">
      <li><a href=\"";
        // line 14
        echo $this->env->getExtension('routing')->getPath("_news");
        echo "\">News</a></li>
      <li class=\"dropdown\">
        <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">
          Before you Fly
          <b class=\"caret\"></b>
        </a>
        <ul id=\"menu-b4ufly\" class=\"dropdown-menu\"> 
          <li><a href=\"";
        // line 21
        echo $this->env->getExtension('routing')->getPath("_b4Ufly");
        echo "#checkIn\">Check In</a></li>
          <li><a href=\"";
        // line 22
        echo $this->env->getExtension('routing')->getPath("_b4Ufly");
        echo "#documentation\">Documentation</a></li>
          <li><a href=\"";
        // line 23
        echo $this->env->getExtension('routing')->getPath("_b4Ufly");
        echo "#resa-change\">Reservation Changes</a></li>
          <li><a href=\"";
        // line 24
        echo $this->env->getExtension('routing')->getPath("_b4Ufly");
        echo "#special-request\">Special Service Request (SSR)</a></li>
          <li><a href=\"";
        // line 25
        echo $this->env->getExtension('routing')->getPath("_b4Ufly");
        echo "#baggage\">Baggage</a></li>
          <li><a href=\"";
        // line 26
        echo $this->env->getExtension('routing')->getPath("_b4Ufly");
        echo "b4Ufly') }}#security-tips\">Security Tips</a></li>
        </ul>         
      </li>
      <li><a href=\"";
        // line 29
        echo $this->env->getExtension('routing')->getPath("_schedule");
        echo "\">Schedule</a></li>
      <li><a href=\"";
        // line 30
        echo $this->env->getExtension('routing')->getPath("_charters");
        echo "\">Charters</a></li>
      <li>
          <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">
            Destinations
            <b class=\"caret\"></b>
          </a>
          <ul class=\"dropdown-menu\"> 
            <li><a href=\"";
        // line 37
        echo $this->env->getExtension('routing')->getPath("_destinations", array("whereTo" => "anguilla"));
        echo "\">Anguilla</a></li>
            <li><a href=\"";
        // line 38
        echo $this->env->getExtension('routing')->getPath("_destinations", array("whereTo" => "antigua"));
        echo "\">Antigua</a></li>
            <li><a href=\"";
        // line 39
        echo $this->env->getExtension('routing')->getPath("_destinations", array("whereTo" => "dominica"));
        echo "\">Dominica</a></li>
            <li><a href=\"";
        // line 40
        echo $this->env->getExtension('routing')->getPath("_destinations", array("whereTo" => "nevis"));
        echo "\">Nevis</a></li>
            <li><a href=\"";
        // line 41
        echo $this->env->getExtension('routing')->getPath("_destinations", array("whereTo" => "puertorico"));
        echo "\">Puerto Rico</a></li>
            <li><a href=\"";
        // line 42
        echo $this->env->getExtension('routing')->getPath("_destinations", array("whereTo" => "stbarth"));
        echo "\">St. Barts</a></li>
            <li><a href=\"";
        // line 43
        echo $this->env->getExtension('routing')->getPath("_destinations", array("whereTo" => "stkitts"));
        echo "\">St. Kitts</a></li>
            <li><a href=\"";
        // line 44
        echo $this->env->getExtension('routing')->getPath("_destinations", array("whereTo" => "stmaarten"));
        echo "\">St. Maarten</a></li>
            <li><a href=\"";
        // line 45
        echo $this->env->getExtension('routing')->getPath("_destinations", array("whereTo" => "tortola"));
        echo "\">Tortola</a></li>           
          </ul> 
      </li>
      <li>
        <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">
          About Us
          <b class=\"caret\"></b>
        </a>
        <ul class=\"dropdown-menu\"> 
          <li><a href=\"";
        // line 54
        echo $this->env->getExtension('routing')->getPath("_aboutUs");
        echo "#handling-agent\">Handling Agent</a></li>
          <li><a href=\"";
        // line 55
        echo $this->env->getExtension('routing')->getPath("_aboutUs");
        echo "#travel-agency\">Travel Agency</a></li>
          <li><a href=\"";
        // line 56
        echo $this->env->getExtension('routing')->getPath("_aboutUs");
        echo "#tour-operator\">Tour Operator</a></li>
        </ul>                   
      </li>
      <li><a href=\"";
        // line 59
        echo $this->env->getExtension('routing')->getPath("_contactUs");
        echo "\">Contact Us</a></li>
    </ul>
    <!--  -->
    <div class=\"navbar-right social\">
      <a href=\"https://www.facebook.com/flycjrp\">
        <img src=\"";
        // line 64
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("img/facebook_blue.png"), "html", null, true);
        echo "\" alt=\"facebook account\" />
      </a>
      <a href=\"http://www.twitter.com/cjrptravel\">
        <img src=\"";
        // line 67
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("img/twitter_blue.png"), "html", null, true);
        echo "\" alt=\"twitter account\" />
      </a>
    </div>

  </div><!--/.nav-collapse -->

</nav>
";
    }

    public function getTemplateName()
    {
        return "cjrpWebsiteBundle::navbar.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  159 => 67,  145 => 59,  139 => 56,  135 => 55,  131 => 54,  115 => 44,  111 => 43,  107 => 42,  103 => 41,  99 => 40,  95 => 39,  91 => 38,  77 => 30,  73 => 29,  67 => 26,  63 => 25,  51 => 22,  47 => 21,  37 => 14,  29 => 9,  19 => 1,  195 => 67,  190 => 51,  180 => 24,  174 => 17,  165 => 91,  138 => 67,  133 => 65,  129 => 64,  125 => 63,  119 => 45,  112 => 56,  106 => 52,  104 => 51,  93 => 43,  87 => 37,  81 => 37,  71 => 30,  66 => 28,  59 => 24,  54 => 22,  48 => 19,  43 => 17,  26 => 2,  24 => 1,  187 => 91,  185 => 37,  181 => 89,  178 => 88,  175 => 87,  161 => 76,  157 => 74,  153 => 64,  151 => 71,  147 => 70,  140 => 66,  120 => 49,  114 => 46,  108 => 43,  102 => 40,  96 => 37,  90 => 34,  72 => 18,  70 => 17,  61 => 25,  55 => 23,  49 => 8,  44 => 6,  41 => 5,  38 => 4,  32 => 3,);
    }
}
