<?php

/* cjrpWebsiteBundle::login.html.twig */
class __TwigTemplate_4dbf48f4bdb232c016854aa3ad4e52a2916392c63ff707b3d8c50f68a971232a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<form role=\"form\" class=\"form-inline\" method=\"post\" action=\"https://booksecure.cjrptravel.com/process/profile_login\">
  <label for=\"profile_username\">My Account :</label>
  <div class=\"form-group\">
    <label class=\"sr-only\" for=\"profile_username\">Email address</label>
    <input name=\"profile_username\" id=\"profile_username\" type=\"email\" value=\"\" class=\"form-control\" placeholder=\"Enter email\">
  </div>
  <div class=\"form-group\">
    <label class=\"sr-only\" for=\"profile_username\">Password</label> 
    <input name=\"profile_password\" id=\"profile_password\" type=\"password\" value=\"\" class=\"form-control\" placeholder=\"Your password\">
  </div>
  <button type=\"submit\" class=\"btn btn-default btn-xs\">Log in</button>
  <a href=\"https://booksecure.cjrptravel.com/profile_create\">Register</a>
</form>";
    }

    public function getTemplateName()
    {
        return "cjrpWebsiteBundle::login.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,  195 => 67,  190 => 51,  180 => 24,  174 => 17,  165 => 91,  138 => 67,  133 => 65,  129 => 64,  125 => 63,  119 => 60,  112 => 56,  106 => 52,  104 => 51,  93 => 43,  87 => 40,  81 => 37,  71 => 30,  66 => 28,  59 => 24,  54 => 22,  48 => 19,  43 => 17,  26 => 2,  24 => 1,  187 => 91,  185 => 37,  181 => 89,  178 => 88,  175 => 87,  161 => 76,  157 => 74,  153 => 72,  151 => 71,  147 => 70,  140 => 66,  120 => 49,  114 => 46,  108 => 43,  102 => 40,  96 => 37,  90 => 34,  72 => 18,  70 => 17,  61 => 25,  55 => 11,  49 => 8,  44 => 6,  41 => 5,  38 => 4,  32 => 3,);
    }
}
