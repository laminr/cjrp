<?php

/* cjrpWebsiteBundle:Ads:ads.html.twig */
class __TwigTemplate_26df8afa27c3c4322f5978d9918484612eed04899645daa5fa57ea83149322e9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<h1>Partners</h1>
";
        // line 2
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["ads"]) ? $context["ads"] : $this->getContext($context, "ads")));
        foreach ($context['_seq'] as $context["_key"] => $context["line"]) {
            // line 3
            echo "\t";
            if (($this->getAttribute((isset($context["line"]) ? $context["line"] : $this->getContext($context, "line")), 0, array(), "array") == "blank")) {
                // line 4
                echo "
    <div class=\"advert well col-md-12\">
      <div>
  \t\t  Your ads here <br/> 360 x 240 (thumbnail) <br/> 750 x 500 full screen
      </div>
\t\t</div>
  \t
    ";
            } else {
                // line 12
                echo "
\t\t<div class=\"advert col-md-12\">
\t\t\t<a class=\"fancybox\" rel=\"ads\" href=\"";
                // line 14
                echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl(("img/ads/" . $this->getAttribute((isset($context["line"]) ? $context["line"] : $this->getContext($context, "line")), 0, array(), "array"))), "html", null, true);
                echo "\" title=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["line"]) ? $context["line"] : $this->getContext($context, "line")), 2, array(), "array"), "html", null, true);
                echo "\">
\t\t\t  <img src=\"";
                // line 15
                echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl(("img/ads/" . $this->getAttribute((isset($context["line"]) ? $context["line"] : $this->getContext($context, "line")), 1, array(), "array"))), "html", null, true);
                echo "\" alt=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["line"]) ? $context["line"] : $this->getContext($context, "line")), 2, array(), "array"), "html", null, true);
                echo "\" class=\"img-thumbnail\" />
\t\t\t</a>
\t\t</div>
  \t
  ";
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['line'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
    }

    public function getTemplateName()
    {
        return "cjrpWebsiteBundle:Ads:ads.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 15,  43 => 14,  39 => 12,  29 => 4,  26 => 3,  22 => 2,  19 => 1,);
    }
}
