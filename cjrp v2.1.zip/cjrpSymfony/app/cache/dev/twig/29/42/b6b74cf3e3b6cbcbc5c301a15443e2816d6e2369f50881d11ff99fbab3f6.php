<?php

/* cjrpWebsiteBundle:Standalone:news.html.twig */
class __TwigTemplate_2942b6b74cf3e3b6cbcbc5c301a15443e2816d6e2369f50881d11ff99fbab3f6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("cjrpWebsiteBundle:Base:base.html.twig");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'pageId' => array($this, 'block_pageId'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "cjrpWebsiteBundle:Base:base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        echo " CJRP Travel - The Cheaper Way To Book /our privacy policies ";
    }

    // line 4
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 5
        echo "  <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("css/jquery.fancybox.css?v=2.1.5"), "html", null, true);
        echo "\" type=\"text/css\" media=\"screen\" />
  <style>
  .one-news {
    margin: 0 0 20px 0;
    padding: 20px 0;
    border-bottom: 2px solid #4A849E;
  }
  </style>
";
    }

    // line 15
    public function block_pageId($context, array $blocks = array())
    {
        echo "id=\"news\"";
    }

    // line 16
    public function block_body($context, array $blocks = array())
    {
        echo " 
  <div class=\"container\">
    <div class=\"row\">
      <div class=\"col-xs-12 col-md-8\">
        <h1>News</h1>
        ";
        // line 21
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["news"]) ? $context["news"] : $this->getContext($context, "news")));
        foreach ($context['_seq'] as $context["_key"] => $context["new"]) {
            // line 22
            echo "        <div class=\"row one-news\">
          <h2 class=\"col-xs-12\">";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["new"]) ? $context["new"] : $this->getContext($context, "new")), "title"), "html", null, true);
            echo " <small>";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["new"]) ? $context["new"] : $this->getContext($context, "new")), "whenFormattedValue"), "html", null, true);
            echo "</small></h2>
          <div class=\"col-xs-12\">
            ";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["new"]) ? $context["new"] : $this->getContext($context, "new")), "content"), "html", null, true);
            echo "
          </div>
        </div>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['new'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 29
        echo "      </div>
      <div class=\"col-md-4 adsColumn\">
        ";
        // line 31
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("cjrpWebsiteBundle:Ads:index", array("pageName" => "news")));
        echo "
      </div>
    </div>
  </div>
";
    }

    // line 37
    public function block_javascripts($context, array $blocks = array())
    {
        // line 38
        echo "  <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("js/jquery.fancybox.pack.js?v=2.1.5"), "html", null, true);
        echo "\" type=\"text/javascript\"></script>
  <script>
  \$(document).ready(function() {
    \$(\".fancybox\").fancybox();
  });
  </script>  
";
    }

    public function getTemplateName()
    {
        return "cjrpWebsiteBundle:Standalone:news.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  110 => 38,  107 => 37,  98 => 31,  94 => 29,  84 => 25,  77 => 23,  74 => 22,  70 => 21,  61 => 16,  55 => 15,  41 => 5,  38 => 4,  32 => 3,);
    }
}
