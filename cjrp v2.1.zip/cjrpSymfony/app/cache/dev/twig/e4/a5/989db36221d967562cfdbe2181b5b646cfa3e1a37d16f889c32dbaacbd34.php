<?php

/* cjrpWebsiteBundle:Hotel:hotelSearchResults.html.twig */
class __TwigTemplate_e4a5989db36221d967562cfdbe2181b5b646cfa3e1a37d16f889c32dbaacbd34 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("cjrpWebsiteBundle:Base:base.html.twig");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'pageId' => array($this, 'block_pageId'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "cjrpWebsiteBundle:Base:base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        echo " CJRP Travel - The Cheaper Way To Book ";
    }

    // line 4
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 5
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("css/hotelSearch.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" media=\"screen\">
";
    }

    // line 8
    public function block_pageId($context, array $blocks = array())
    {
        echo "id=\"hotel-results\"";
    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        // line 11
        echo "    <div class=\"container\">
        <h1 class=\"text-center\">Hotel search</h1>
        <div class=\"col-md-8\">
            <h2>My booking selection</h2>
            <div class=\"row well\">
                I want an hotel reservation in <span class=\"val\">";
        // line 16
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "country"), "html", null, true);
        echo "</span>, 
                for the period starting from <span class=\"val\">";
        // line 17
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "checkInDate"), "html", null, true);
        // line 18
        echo "</span> to  <span class=\"val\">";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "checkOutDate"), "html", null, true);
        echo "</span>.
                I want <span class=\"val\">";
        // line 19
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "nbrRooms"), "html", null, true);
        echo "</span> room";
        if (($this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "nbrRooms") > 1)) {
            echo "s";
        }
        echo ",
                for <span class=\"val\">";
        // line 20
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "hotelAdults"), "html", null, true);
        echo "</span> adult";
        echo ((($this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "hotelAdults") > 1)) ? ("s") : (""));
        echo "
                ";
        // line 21
        if (($this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "hotelChildren") > 0)) {
            // line 22
            echo "                    , <span class=\"val\">";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "hotelChildren"), "html", null, true);
            echo "</span> children";
            echo ((($this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "hotelChildren") > 1)) ? ("s") : (""));
            echo "
                ";
        }
        // line 24
        echo "                ";
        if (($this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "hotelMinor") > 0)) {
            // line 25
            echo "                    , <span class=\"val\">";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "hotelMinor"), "html", null, true);
            echo "</span> infant";
            echo ((($this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "hotelMinor") > 1)) ? ("s") : (""));
            echo "
                ";
        }
        // line 27
        echo "            </div>
        
            <div id=\"results\">
                ";
        // line 30
        if (twig_test_empty((isset($context["hotels"]) ? $context["hotels"] : $this->getContext($context, "hotels")))) {
            // line 31
            echo "                    <div id=\"no-result\">
                        <p class=\"text-center\">
                            We currently have no results for this destination. <br> please send us a request and we will find you the best deal possible!
                        </p>
                    </div>
                ";
        }
        // line 37
        echo "                ";
        // line 38
        echo "                ";
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["hotels"]) ? $context["hotels"] : $this->getContext($context, "hotels")));
        foreach ($context['_seq'] as $context["_key"] => $context["hotel"]) {
            // line 39
            echo "                    <div id=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["hotel"]) ? $context["hotel"] : $this->getContext($context, "hotel")), "id"), "html", null, true);
            echo "\">
                        <div class=\"row\">
                            ";
            // line 41
            $context["rest"] = (5 - $this->getAttribute((isset($context["hotel"]) ? $context["hotel"] : $this->getContext($context, "hotel")), "rating"));
            // line 42
            echo "                            <h3 class=\"col-sm-8\">
                                ";
            // line 43
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["hotel"]) ? $context["hotel"] : $this->getContext($context, "hotel")), "name"), "html", null, true);
            echo " <small>";
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable(range(1, $this->getAttribute((isset($context["hotel"]) ? $context["hotel"] : $this->getContext($context, "hotel")), "rating")));
            foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
                echo "&#9733;";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable(range(1, (isset($context["rest"]) ? $context["rest"] : $this->getContext($context, "rest"))));
            foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
                echo "&#9734;";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            echo "</small>                        
                                <span class=\"city-n-island\">
                                    ";
            // line 45
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["hotel"]) ? $context["hotel"] : $this->getContext($context, "hotel")), "city"), "value"), "html", null, true);
            if (($this->getAttribute($this->getAttribute((isset($context["hotel"]) ? $context["hotel"] : $this->getContext($context, "hotel")), "city"), "value") != "")) {
                echo ", ";
            }
            echo " <i>";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["hotel"]) ? $context["hotel"] : $this->getContext($context, "hotel")), "island"), "value"), "html", null, true);
            echo "</i>
                                </span>
                            </h3>
                            <div class=\"col-sm-4 starting-at\">
                                ";
            // line 49
            $context["first"] = twig_first($this->env, $this->getAttribute((isset($context["hotel"]) ? $context["hotel"] : $this->getContext($context, "hotel")), "hotelRatings"));
            // line 50
            echo "                                <span><small>starting at</small> \$";
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute((isset($context["first"]) ? $context["first"] : $this->getContext($context, "first")), "perDay"), 2, ".", ","), "html", null, true);
            echo "</span>
                                <button class=\"pull-right btn btn-primary btn-sm\" onclick=\"javascript:displayPriceList(";
            // line 51
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["hotel"]) ? $context["hotel"] : $this->getContext($context, "hotel")), "id"), "html", null, true);
            echo ")\">See more</button>
                            </div>
                        </div>
                        <div class=\"Box row price-list\">
                            <div class=\"col-xs-12 description\">
                                ";
            // line 57
            echo "                            </div>
                            <div class=\"col-xs-12\">
                                <table class=\"table\">
                                    <thead>
                                    <tr>
                                        <th></th>
                                        <th>Base Rate</th>
                                        <th>Taxe</th>
                                        <th>Gov. Levy</th>
                                        <th>Total</th>
                                        <th></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                        ";
            // line 71
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["hotel"]) ? $context["hotel"] : $this->getContext($context, "hotel")), "hotelRatings"));
            foreach ($context['_seq'] as $context["_key"] => $context["hotelRating"]) {
                // line 72
                echo "                                        ";
                $context["bigTotal"] = ($this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "nbrRooms") * $this->getAttribute((isset($context["hotelRating"]) ? $context["hotelRating"] : $this->getContext($context, "hotelRating")), "totalWithoutFee"));
                // line 73
                echo "                                        <tr>
                                            <td>";
                // line 74
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["hotelRating"]) ? $context["hotelRating"] : $this->getContext($context, "hotelRating")), "room"), "description"), "html", null, true);
                echo "</td>
                                            <td class=\"value\">\$";
                // line 75
                echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute((isset($context["hotelRating"]) ? $context["hotelRating"] : $this->getContext($context, "hotelRating")), "perday"), 2, ".", ","), "html", null, true);
                echo "</td>
                                            <td class=\"value\">\$";
                // line 76
                echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute((isset($context["hotelRating"]) ? $context["hotelRating"] : $this->getContext($context, "hotelRating")), "taxValue"), 2, ".", ","), "html", null, true);
                echo "</td>
                                            <td class=\"value\">\$";
                // line 77
                echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute((isset($context["hotelRating"]) ? $context["hotelRating"] : $this->getContext($context, "hotelRating")), "government"), 2, ".", ","), "html", null, true);
                echo " </td>
                                            <td class=\"value\">
                                                \$";
                // line 79
                echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute((isset($context["hotelRating"]) ? $context["hotelRating"] : $this->getContext($context, "hotelRating")), "totalWithoutFee"), 2, ".", ","), "html", null, true);
                echo "
                                                ";
                // line 80
                if (($this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "nbrRooms") > 1)) {
                    // line 81
                    echo "                                                <div class=\"totalValue\">
                                                    ";
                    // line 82
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "nbrRooms"), "html", null, true);
                    echo " rooms: ";
                    echo twig_escape_filter($this->env, twig_number_format_filter($this->env, (isset($context["bigTotal"]) ? $context["bigTotal"] : $this->getContext($context, "bigTotal")), 2, ".", ","), "html", null, true);
                    echo "
                                                </div>
                                                ";
                }
                // line 85
                echo "                                            </td>
                                            <td><button class=\"btn btn-primary pull-right\" 
                                                onclick=\"javascript:setFormValue('";
                // line 87
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["hotel"]) ? $context["hotel"] : $this->getContext($context, "hotel")), "name"), "html", null, true);
                echo "', ";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["hotelRating"]) ? $context["hotelRating"] : $this->getContext($context, "hotelRating")), "id"), "html", null, true);
                echo ", ";
                echo twig_escape_filter($this->env, (isset($context["bigTotal"]) ? $context["bigTotal"] : $this->getContext($context, "bigTotal")), "html", null, true);
                echo ", ";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["hotelRating"]) ? $context["hotelRating"] : $this->getContext($context, "hotelRating")), "fullTaxValue"), "html", null, true);
                echo ", ";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["hotelRating"]) ? $context["hotelRating"] : $this->getContext($context, "hotelRating")), "fee"), "html", null, true);
                echo ")\">Book</button></td>
                                        </tr>
                                        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['hotelRating'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 90
            echo "                                    </tbody>
                                    <tfoot></tfoot>
                                </table>
                            </div>
                        </div>
                    </div>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['hotel'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 97
        echo "            </div>
        </div>
        <div id=\"not-found-my-need\" class=\"col-md-4\">
            <p class=\"text-center\">
                Haven't found your need ?
            </p>
            <form role=\"form\" method=\"POST\" action=\"";
        // line 103
        echo $this->env->getExtension('routing')->getPath("_hotelGeneralRequest");
        echo "\">
                <div class=\"row\">
                    <div class=\"col-md-4 control-label\">Name</div>
                    <div class=\"col-md-8\">
                        <input id=\"\" name=\"";
        // line 107
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["contact"]) ? $context["contact"] : $this->getContext($context, "contact")), "name"), "vars"), "full_name"), "html", null, true);
        echo "\" class=\"form-control\" size=\"16\" type=\"text\" value=\"\" placeholder=\"contact name\">
                    </div>
                </div>
                <div class=\"row\">
                    <div class=\"col-md-4 control-label\">Phone</div>
                    <div class=\"col-md-8\">
                        <input id=\"\" name=\"";
        // line 113
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["contact"]) ? $context["contact"] : $this->getContext($context, "contact")), "phone"), "vars"), "full_name"), "html", null, true);
        echo "\" class=\"form-control\" size=\"16\" type=\"text\" value=\"\" placeholder=\"Phone number\">
                    </div> 
                </div>
                <div class=\"row\">
                    <div class=\"col-md-4 control-label\">Email</div>
                    <div class=\"col-md-8\">
                        <input id=\"\" name=\"";
        // line 119
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["contact"]) ? $context["contact"] : $this->getContext($context, "contact")), "email"), "vars"), "full_name"), "html", null, true);
        echo "\" class=\"form-control\" size=\"16\" type=\"text\" value=\"\" placeholder=\"email\">
                    </div>
                </div>
                <div class=\"row\">
                    <div class=\"col-xs-12\">Comment</div>
                    <div class=\"col-xs-12\">
                        <textarea name=\"";
        // line 125
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["contact"]) ? $context["contact"] : $this->getContext($context, "contact")), "comment"), "vars"), "full_name"), "html", null, true);
        echo "\" id=\"\" cols=\"40\" rows=\"6\" class=\"form-control\">
Dear CJRP Travel,
I want an hotel reservation in ";
        // line 127
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "country"), "html", null, true);
        echo ", for the period starting from ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "checkInDate"), "html", null, true);
        echo " to ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "checkOutDate"), "html", null, true);
        echo ". I need ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "nbrRooms"), "html", null, true);
        echo " room";
        if (($this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "nbrRooms") > 1)) {
            echo "s";
        }
        echo ", for ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "hotelAdults"), "html", null, true);
        echo " adult";
        echo ((($this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "hotelAdults") > 1)) ? ("s") : (""));
        if (($this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "hotelChildren") > 0)) {
            echo ", ";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "hotelChildren"), "html", null, true);
            echo " children";
            echo ((($this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "hotelChildren") > 1)) ? ("s") : (""));
        }
        if (($this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "hotelMinor") > 0)) {
            echo ", ";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "hotelMinor"), "html", null, true);
            echo " infant";
            echo ((($this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "hotelMinor") > 1)) ? ("s") : (""));
        }
        echo ".
Please find my the best deal.</textarea>
                    </div>
                </div>
                <div class=\"row\">
                    <div id=\"submit\" class=\"col-xs-12\">
                        <button type=\"submit\" class=\"btn btn-default pull-right\">Send</button>
                    </div>
                </div>
            </form>             
        </div>
    </div>

    <!-- modal -->
    <div id=\"modal-message\" class=\"modal fade\">
        <form role=\"form\" class=\"form-horizontal\" id=\"contact-form\" method=\"POST\" action=\"";
        // line 142
        echo $this->env->getExtension('routing')->getPath("_validateHotelBooking");
        echo "\">
        <input type=\"hidden\" id=\"hotelRatingId\" name=\"";
        // line 143
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["contact"]) ? $context["contact"] : $this->getContext($context, "contact")), "ratingId"), "vars"), "full_name"), "html", null, true);
        echo "\" value=\"\"/>
        <input type=\"hidden\" id=\"nbrRoom\" name=\"";
        // line 144
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["contact"]) ? $context["contact"] : $this->getContext($context, "contact")), "nbrRoom"), "vars"), "full_name"), "html", null, true);
        echo "\" value=\"";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "nbrRooms"), "html", null, true);
        echo "\"/>
        <input type=\"hidden\" name=\"";
        // line 145
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["contact"]) ? $context["contact"] : $this->getContext($context, "contact")), "bookDates"), "vars"), "full_name"), "html", null, true);
        echo "\" value=\"";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "checkInDate"), "html", null, true);
        echo " to ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "checkOutDate"), "html", null, true);
        echo "\"/>
        <input type=\"hidden\" id=\"nbrPerson\" name=\"";
        // line 146
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["contact"]) ? $context["contact"] : $this->getContext($context, "contact")), "nbrPerson"), "vars"), "full_name"), "html", null, true);
        echo "\" value=\"";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "hotelAdults"), "html", null, true);
        echo " adult(s)  ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "hotelChildren"), "html", null, true);
        echo " children(s) | ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "hotelMinor"), "html", null, true);
        echo " minor(s)\"/>
        <div class=\"modal-dialog\">
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\" data-hidden=\"true\">&times;</button>
                    <h4 class=\"modal-title\">Hotel request</h4>
                </div>
                <div class=\"modal-body\">
                    <div class=\"col-md-4 control-label\">Contact name</div>
                    <div class=\"col-md-8\">
                        <input id=\"\" name=\"";
        // line 156
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["contact"]) ? $context["contact"] : $this->getContext($context, "contact")), "name"), "vars"), "full_name"), "html", null, true);
        echo "\" class=\"col-xs-12 form-control\" size=\"16\" type=\"text\" value=\"\" placeholder=\"contact name\" required=\"required\">
                    </div>
                    <div class=\"col-md-4 control-label\">Phone number</div>
                    <div class=\"col-md-8\">
                        <input id=\"\" name=\"";
        // line 160
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["contact"]) ? $context["contact"] : $this->getContext($context, "contact")), "phone"), "vars"), "full_name"), "html", null, true);
        echo "\" class=\"col-xs-12 form-control\" size=\"16\" type=\"text\" value=\"\" placeholder=\"Phone number\" required=\"required\">
                    </div> 
                    <div class=\"col-md-4 control-label\">email</div>
                    <div class=\"col-md-8\">
                        <input id=\"\" name=\"";
        // line 164
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["contact"]) ? $context["contact"] : $this->getContext($context, "contact")), "email"), "vars"), "full_name"), "html", null, true);
        echo "\" class=\"col-xs-12 form-control\" size=\"16\" type=\"text\" value=\"\" placeholder=\"email\" required=\"required\">
                    </div> 
                    <div class=\"col-md-4 control-label text-left\">Comment</div>
                    <div class=\"col-md-8\">
                        <textarea id=\"final-message\" name=\"";
        // line 168
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["contact"]) ? $context["contact"] : $this->getContext($context, "contact")), "comment"), "vars"), "full_name"), "html", null, true);
        echo "\" id=\"\" cols=\"30\" rows=\"5\" class=\"form-control\">
Dear CJRP Travel,
I confirm this reservation in #hotel# ";
        // line 170
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "country"), "html", null, true);
        echo ", for the period starting from ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "checkInDate"), "html", null, true);
        echo " to ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "checkOutDate"), "html", null, true);
        echo ". I book ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "nbrRooms"), "html", null, true);
        echo " room";
        if (($this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "nbrRooms") > 1)) {
            echo "s";
        }
        echo ", for ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "hotelAdults"), "html", null, true);
        echo " adult";
        echo ((($this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "hotelAdults") > 1)) ? ("s") : (""));
        if (($this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "hotelChildren") > 0)) {
            echo ", ";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "hotelChildren"), "html", null, true);
            echo " children";
            echo ((($this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "hotelChildren") > 1)) ? ("s") : (""));
        }
        if (($this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "hotelMinor") > 0)) {
            echo ", ";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "hotelMinor"), "html", null, true);
            echo " infant";
            echo ((($this->getAttribute((isset($context["booking"]) ? $context["booking"] : $this->getContext($context, "booking")), "hotelMinor") > 1)) ? ("s") : (""));
        }
        echo ".</textarea>
                    </div>
                    <div class=\"clearfix\"></div>
                    <div id=\"service-fee\" class=\"col-xs-12\">
                        Room charge: <span id=\"final-charge\"></span><br>
                        <i>including tax of: <span id=\"final-tax\"></span></i><br>
                        service fee: <span id=\"final-fee\"></span>
                    </div>
                </div>
                <div class=\"modal-footer\">
                    <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
                    <button type=\"submit\" class=\"btn btn-primary\">Confirm</button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
        </form>
    </div><!-- /.modal -->

";
    }

    // line 190
    public function block_javascripts($context, array $blocks = array())
    {
        // line 191
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("js/hotel-results.js"), "html", null, true);
        echo "\"></script>
";
    }

    public function getTemplateName()
    {
        return "cjrpWebsiteBundle:Hotel:hotelSearchResults.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  495 => 191,  492 => 190,  443 => 170,  438 => 168,  431 => 164,  424 => 160,  417 => 156,  398 => 146,  390 => 145,  384 => 144,  380 => 143,  376 => 142,  332 => 127,  327 => 125,  318 => 119,  309 => 113,  300 => 107,  293 => 103,  285 => 97,  273 => 90,  256 => 87,  252 => 85,  244 => 82,  241 => 81,  239 => 80,  235 => 79,  230 => 77,  226 => 76,  222 => 75,  218 => 74,  215 => 73,  212 => 72,  208 => 71,  192 => 57,  184 => 51,  179 => 50,  177 => 49,  165 => 45,  143 => 43,  140 => 42,  138 => 41,  132 => 39,  127 => 38,  125 => 37,  117 => 31,  115 => 30,  110 => 27,  102 => 25,  99 => 24,  91 => 22,  89 => 21,  83 => 20,  75 => 19,  70 => 18,  68 => 17,  64 => 16,  57 => 11,  54 => 10,  48 => 8,  41 => 5,  38 => 4,  32 => 3,);
    }
}
