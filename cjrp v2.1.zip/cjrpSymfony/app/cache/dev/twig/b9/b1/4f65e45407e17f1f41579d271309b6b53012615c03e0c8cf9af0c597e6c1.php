<?php

/* cjrpWebsiteBundle:Index:ferry-booking.html.twig */
class __TwigTemplate_b9b14f65e45407e17f1f41579d271309b6b53012615c03e0c8cf9af0c597e6c1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!-- https://booksecure.cjrptravel.com/process/search -->
<form role=\"form\" class=\"form-horizontal\" id=\"ferry-booking-form\" action=\"https://booksecure.cjrptravel.com/process/search\" method=\"post\">
  <div id=\"ferry-route\" class=\"row lines\">
    <div>
      <div class=\"col-md-4 control-label\"> Ferrying from</div>
      <div class=\"col-md-8\">
        <select name=\"origin\" id=\"origin\"  class=\"form-control\" onchange=\"javascript:updateDestination(this.value)\">
          <option value=''></option>
          <option value=\"BPF\" selected=\"selected\">Anguilla (BPF)</option>
          <option value=\"SXM\">St. Maarten (SXM)</option>
        </select>
      </div>
    </div>
    <div>
      <div class=\"col-md-4 control-label\">Going to</div>
      <div class=\"col-md-8\">
        <select name=\"dest\" id=\"dest\" class=\"form-control\">
          <option value=''></option>
          <option value=\"BPF\">Anguilla (BPF)</option>
          <option value=\"SXM\" selected=\"selected\">St. Maarten (SXM)</option>
        </select>
      </div>
    </div>
  </div>
  <div class=\"row lines\">
    <div class=\"col-xs-12 col-md-4 control-label\">Trip</div>
    <div class=\"checkbox col-xs-6 col-md-4\">
      <label>
        <input type=\"radio\" name=\"return\" value=\"1\" checked=\"checked\" />&nbsp;round trip
      </label>
    </div>
    <div class=\"checkbox col-xs-6 col-md-4\">
      <label>
        <input type=\"radio\" name=\"return\" value=\"0\" />&nbsp; One-Way
      </label>
    </div>
  </div>
  <div class=\"row lines\">
      <div class=\"col-xs-12 col-md-4 control-label\">Flexible</div>
      <div class=\"checkbox col-xs-6 col-md-4\">
        <label>
          <input type=\"radio\" name=\"selectedSearchType\" value=\"FLEXIBLE\" checked=\"checked\"/>&nbsp;Yes
        </label>
      </div>
      <div class=\"checkbox col-xs-6 col-md-4\">
        <label>
          <input type=\"radio\" name=\"selectedSearchType\" value=\"FIXED\"  />&nbsp;No
        </label>
      </div>
  </div>
  <div id=\"dates\" class=\"row lines\">
    <div class=\"col-md-4 control-label\">Dates</div>
    <div class=\"col-xs-12 col-md-4 date-selection-depart\">
      <!-- departing date 
      <div for=\"depart_date\">Outbound</div>-->
      <input id=\"ferry-depart-date\" name=\"depart_date\" class=\"col-xs-12 form-control datepicker\" size=\"16\" type=\"text\" autocomplete=\"off\" placeholder=\"departing\">
    </div>
    <div class=\"col-xs-12 col-md-4 date-selection-return\">
      <!-- returning date 
      <div for=\"return_date\">Return</div>-->
      <input id=\"ferry-return-date\" name=\"return_date\" class=\"col-xs-12 form-control datepicker\" size=\"16\" type=\"text\" autocomplete=\"off\" placeholder=\"returning\">
    </div>
  </div>
  <div id=\"pax\" class=\"row lines\">
      <input type=\"hidden\" name=\"passengers\" id=\"passengers\" value=\"\" />
      <div class=\"col-md-3\">
          <label>Adults</label>
          <select name=\"adult_passengers\" id=\"adult_passengers\" class=\"form-control\" onchange=\"javascript:udpatePaxTotalNbr()\">
            ";
        // line 69
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable(range(1, 10));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            if (((isset($context["i"]) ? $context["i"] : $this->getContext($context, "i")) == 1)) {
                // line 70
                echo "              <option value=\"";
                echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : $this->getContext($context, "i")), "html", null, true);
                echo "\" selected=\"selected\">";
                echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : $this->getContext($context, "i")), "html", null, true);
                echo "</option>
            ";
                $context['_iterated'] = true;
            }
        }
        if (!$context['_iterated']) {
            // line 72
            echo "              <option value=\"";
            echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : $this->getContext($context, "i")), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : $this->getContext($context, "i")), "html", null, true);
            echo "</option>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 74
        echo "          </select>
      </div>
      <div class=\"col-md-3\">
          <label data-toggle=\"tooltip\" title=\"2-11 years\">Children*</label>
          <select name=\"child_passengers\" id=\"child_passengers\" class=\"form-control\" onchange=\"javascript:udpatePaxTotalNbr()\">
            ";
        // line 79
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable(range(0, 10));
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            // line 80
            echo "              <option value=\"";
            echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : $this->getContext($context, "i")), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : $this->getContext($context, "i")), "html", null, true);
            echo "</option>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 82
        echo "          </select>                      
      </div>
      <div class=\"col-md-3\">
          <label data-toggle=\"tooltip\" title=\"60 or greater\">Seniors*</label>
          <select name=\"senior_passengers\" id=\"senior_passengers\" class=\"form-control\" onchange=\"javascript:udpatePaxTotalNbr()\">
            ";
        // line 87
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable(range(0, 10));
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            // line 88
            echo "              <option value=\"";
            echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : $this->getContext($context, "i")), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : $this->getContext($context, "i")), "html", null, true);
            echo "</option>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 90
        echo "          </select>                      
      </div>
      <div class=\"col-md-3\">
          <label data-toggle=\"tooltip\" title=\"under 2 years\">Infant*</label>
          <select name=\"infant_passengers\" id=\"infant_passengers\" class=\"form-control\" onchange=\"javascript:udpatePaxTotalNbr()\">
            ";
        // line 95
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable(range(0, 10));
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            // line 96
            echo "              <option value=\"";
            echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : $this->getContext($context, "i")), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : $this->getContext($context, "i")), "html", null, true);
            echo "</option>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 98
        echo "          </select>                      
      </div>
  </div>
  <div class=\"row lines\">
    <div class=\"col-md-4 control-label\">Promo code</div>
    <div class=\"col-md-8\">
      <input type=\"text\" name=\"promo_code\" class=\"form-control\" />
    </div>
  </div>
  <div id=\"submit-flight\">
    <button type=\"submit\" class=\"btn btn-default pull-right\">Submit</button>
  </div>
</form>";
    }

    public function getTemplateName()
    {
        return "cjrpWebsiteBundle:Index:ferry-booking.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  183 => 98,  172 => 96,  161 => 90,  150 => 88,  139 => 82,  128 => 80,  117 => 74,  106 => 72,  95 => 70,  89 => 69,  201 => 116,  190 => 114,  186 => 113,  179 => 108,  168 => 95,  164 => 105,  157 => 100,  146 => 87,  142 => 97,  135 => 92,  124 => 79,  113 => 88,  107 => 87,  19 => 1,  284 => 181,  280 => 180,  277 => 179,  274 => 178,  235 => 143,  222 => 133,  212 => 126,  203 => 120,  193 => 113,  184 => 107,  174 => 100,  151 => 80,  141 => 73,  131 => 66,  121 => 59,  111 => 52,  88 => 32,  82 => 29,  76 => 26,  56 => 10,  50 => 9,  44 => 6,  41 => 5,  38 => 4,  32 => 3,);
    }
}
