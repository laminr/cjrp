<?php

/* cjrpWebsiteBundle:Email:requestHotelBooking.html.twig */
class __TwigTemplate_dc5fbb41caba02752977a548fb6716dded944aa087e57a270256f618d53a15c9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<html>
<body>
    <table rules=\"all\" style=\"border-color: #666; border: 1px solid #000\" cellpadding=\"10\">
        <tr>
            <td style=\"background: #eee;\">
                <strong>Time</strong>
            </td>
            <td>
                ";
        // line 9
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "(l) F dS, Y @ H:i e"), "html", null, true);
        echo "
            </td>
        </tr>       
        <tr>
            <td style=\"background: #eee;\">
                <strong>Contact Name:</strong>
            </td>
            <td>
                ";
        // line 17
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["contact"]) ? $context["contact"] : $this->getContext($context, "contact")), "name"), "html", null, true);
        echo "
            </td>
        </tr>
        <tr>
            <td style=\"background: #eee;\">
                <strong>Phone:</strong>
            </td>
            <td>
                ";
        // line 25
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["contact"]) ? $context["contact"] : $this->getContext($context, "contact")), "phone"), "html", null, true);
        echo "
            </td>
        </tr>
        <tr>
            <td style=\"background: #eee;\">
                <strong>Email:</strong>
            </td>
            <td>
                ";
        // line 33
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["contact"]) ? $context["contact"] : $this->getContext($context, "contact")), "email"), "html", null, true);
        echo "
            </td>
        </tr>
        <tr>
            <td style=\"background: #eee;\">
                <strong>Comment:</strong>
            </td>
            <td>
                ";
        // line 41
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["contact"]) ? $context["contact"] : $this->getContext($context, "contact")), "comment"), "html", null, true);
        echo "
            </td>
        </tr>        
    </table>
</body>
</html>";
    }

    public function getTemplateName()
    {
        return "cjrpWebsiteBundle:Email:requestHotelBooking.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 41,  62 => 33,  51 => 25,  40 => 17,  29 => 9,  19 => 1,);
    }
}
