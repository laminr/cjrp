<?php

/* cjrpWebsiteBundle:Hotel:hotelBooking.html.twig */
class __TwigTemplate_397503fc1d86b77fc6abcc01ef08378aeeb63c1c607811779b87091653ad4091 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("cjrpWebsiteBundle:Base:base.html.twig");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'pageId' => array($this, 'block_pageId'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "cjrpWebsiteBundle:Base:base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        echo " CJRP Travel - The Cheaper Way To Book your hotel";
    }

    // line 4
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 5
        echo "    <link href=\"http://codeorigin.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css\" rel=\"stylesheet\"  media=\"screen\">
    <link href=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("css/car-hotel-booking.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" media=\"screen\">
    
    <script src=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("js/email.js"), "html", null, true);
        echo "\"></script>
";
    }

    // line 11
    public function block_pageId($context, array $blocks = array())
    {
        echo "id=\"car-hotel-booking\"";
    }

    // line 12
    public function block_body($context, array $blocks = array())
    {
        echo "  
    <div class=\"container\">
      <div class=\"row\">
        <div class=\"col-md-6\">
          <h1>Hotel booking</h1>
          ";
        // line 17
        $this->env->loadTemplate("cjrpWebsiteBundle:Hotel:hotelBookingForm.html.twig")->display($context);
        // line 18
        echo "        </div>
        <div class=\"col-md-6\" style=\"margin-top: 30px\">
          <div id=\"myCarousel\">
          <div class=\"carousel slide\">
            <ol class=\"carousel-indicators\">
              <li data-target=\"#myCarousel\" data-slide-to=\"0\" class=\"active\"></li>
              <li data-target=\"#myCarousel\" data-slide-to=\"1\"></li>
              <li data-target=\"#myCarousel\" data-slide-to=\"2\"></li>
              <li data-target=\"#myCarousel\" data-slide-to=\"3\"></li>
              <li data-target=\"#myCarousel\" data-slide-to=\"4\"></li>
              <li data-target=\"#myCarousel\" data-slide-to=\"5\"></li> 
              <li data-target=\"#myCarousel\" data-slide-to=\"6\"></li>           
            </ol>
            <!-- Carousel items -->
            <div class=\"carousel-inner\">
              <div class=\"active item\">
                <img class=\"thumbnail\" src=\"";
        // line 34
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("img/hotelBooking/hotel_1.jpg"), "html", null, true);
        echo "\">
              </div>
              <div class=\"item\">
                <img class=\"thumbnail\" src=\"";
        // line 37
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("img/hotelBooking/hotel_2.jpg"), "html", null, true);
        echo "\">           
              </div>
              <div class=\"item\">
                <img class=\"thumbnail\" src=\"";
        // line 40
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("img/hotelBooking/hotel_3.jpg"), "html", null, true);
        echo "\">           
              </div>
              <div class=\"item\">
                <img class=\"thumbnail\" src=\"";
        // line 43
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("img/hotelBooking/hotel_4.jpg"), "html", null, true);
        echo "\">          
              </div>
              <div class=\"item\">
                <img class=\"thumbnail\" src=\"";
        // line 46
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("img/hotelBooking/hotel_5.jpg"), "html", null, true);
        echo "\">          
              </div> 
              <div class=\"item\">
                <img class=\"thumbnail\" src=\"";
        // line 49
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("img/hotelBooking/hotel_6.jpg"), "html", null, true);
        echo "\">          
              </div> 
            </div>
            <!-- Carousel nav -->
            <a class=\"left carousel-control hidden-sm\" href=\"#myCarousel\" data-slide=\"prev\"><span class=\"glyphicon glyphicon-chevron-left\"></span></a>
            <a class=\"right carousel-control hidden-sm\" href=\"#myCarousel\" data-slide=\"next\"><span class=\"glyphicon glyphicon-chevron-right\"></span></a>
          </div>
        </div>
        </div>
      </div>
    </div>
    <!-- modal -->
    <div id=\"modal-message\" class=\"modal fade\">
      <div class=\"modal-dialog\">
        <div class=\"modal-content\">
          <div class=\"modal-header\">
            <button type=\"button\" class=\"close\" data-dismiss=\"modal\" data-hidden=\"true\">&times;</button>
            <h4 class=\"modal-title\">";
        // line 66
        echo (((isset($context["isGettingEmailHotel"]) ? $context["isGettingEmailHotel"] : $this->getContext($context, "isGettingEmailHotel"))) ? ("Hotel") : ("Car"));
        echo " booking request</h4>
          </div>
          <div class=\"modal-body\">
            <p>Thank you for choosing CJRP Travel.</p>
            <p>We have received your ";
        // line 70
        echo (((isset($context["isGettingEmailHotel"]) ? $context["isGettingEmailHotel"] : $this->getContext($context, "isGettingEmailHotel"))) ? ("Hotel") : ("Car"));
        echo " request. 
              ";
        // line 71
        if ((isset($context["isGettingEmailHotel"]) ? $context["isGettingEmailHotel"] : $this->getContext($context, "isGettingEmailHotel"))) {
            // line 72
            echo "                Will contact you shortly.
              ";
        } else {
            // line 74
            echo "                Please allow us 1 to 2 business days to complete your quotation.
              ";
        }
        // line 76
        echo "            </p>
            <p>If this reservation is an emergency, please contact us via phone, for immediate assistance.</p>
          </div>
          <div class=\"modal-footer\">
            <button type=\"button\" class=\"btn btn-primary\" data-dismiss=\"modal\">Close</button>
          </div>
        </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->

";
    }

    // line 87
    public function block_javascripts($context, array $blocks = array())
    {
        // line 88
        echo "    <script src=\"http://codeorigin.jquery.com/ui/1.10.3/jquery-ui.min.js\"></script>
    <script src=\"";
        // line 89
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("js/hotel-booking.js"), "html", null, true);
        echo "\"></script>
    ";
        // line 90
        if ((isset($context["isGettingEmailHotel"]) ? $context["isGettingEmailHotel"] : $this->getContext($context, "isGettingEmailHotel"))) {
            // line 91
            echo "      <script type=\"text/javascript\">
        \$('#modal-message').modal({
          keyboard: true
        });
      </script>
    ";
        }
    }

    public function getTemplateName()
    {
        return "cjrpWebsiteBundle:Hotel:hotelBooking.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  187 => 91,  185 => 90,  181 => 89,  178 => 88,  175 => 87,  161 => 76,  157 => 74,  153 => 72,  151 => 71,  147 => 70,  140 => 66,  120 => 49,  114 => 46,  108 => 43,  102 => 40,  96 => 37,  90 => 34,  72 => 18,  70 => 17,  61 => 12,  55 => 11,  49 => 8,  44 => 6,  41 => 5,  38 => 4,  32 => 3,);
    }
}
