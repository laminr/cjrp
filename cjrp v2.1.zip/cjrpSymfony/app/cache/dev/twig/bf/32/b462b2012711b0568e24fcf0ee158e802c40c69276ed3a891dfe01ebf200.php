<?php

/* cjrpWebsiteBundle::analyticstracking.html.twig */
class __TwigTemplate_bf32b462b2012711b0568e24fcf0ee158e802c40c69276ed3a891dfe01ebf200 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!--
<?php include_once(\"analyticstracking.php\") ?>
-->
<script type=\"text/javascript\">
/*
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-44717879-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
//*/
</script>";
    }

    public function getTemplateName()
    {
        return "cjrpWebsiteBundle::analyticstracking.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  40 => 14,  25 => 5,  132 => 91,  116 => 78,  100 => 65,  84 => 52,  64 => 38,  31 => 8,  23 => 3,  159 => 67,  145 => 59,  139 => 56,  135 => 55,  131 => 54,  115 => 44,  111 => 43,  107 => 42,  103 => 41,  99 => 40,  95 => 39,  91 => 38,  77 => 30,  73 => 44,  67 => 26,  63 => 25,  51 => 22,  47 => 21,  37 => 14,  29 => 9,  19 => 1,  195 => 67,  190 => 51,  180 => 24,  174 => 17,  165 => 91,  138 => 67,  133 => 65,  129 => 64,  125 => 63,  119 => 45,  112 => 56,  106 => 52,  104 => 51,  93 => 43,  87 => 37,  81 => 37,  71 => 30,  66 => 28,  59 => 24,  54 => 22,  48 => 16,  43 => 17,  26 => 2,  24 => 1,  187 => 91,  185 => 37,  181 => 89,  178 => 88,  175 => 87,  161 => 76,  157 => 74,  153 => 64,  151 => 71,  147 => 103,  140 => 66,  120 => 49,  114 => 46,  108 => 43,  102 => 40,  96 => 37,  90 => 34,  72 => 18,  70 => 17,  61 => 25,  55 => 23,  49 => 8,  44 => 15,  41 => 5,  38 => 4,  32 => 3,);
    }
}
