<?php

/* cjrpWebsiteBundle:Index:flight-booking.html.twig */
class __TwigTemplate_76c37efbdc1ce7de83e3c1159b6ba0570ba49c1fddf69cac5c7718ac754624e2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!-- https://booksecure.cjrptravel.com/process/search -->
<form role=\"form\" class=\"form-horizontal\" id=\"flight-booking-form\" action=\"https://booksecure.cjrptravel.com/process/search\" method=\"post\">
  <div id=\"flight-route\" class=\"row lines\">
    <div>
      <div class=\"col-md-4 control-label\">Flying from</div>
      <div class=\"col-md-8\">
        <select name=\"origin\" id=\"origin\"  class=\"form-control\" onchange=\"javascript:updateDestination('dest', this.value)\">
          <option value=''></option>
          <option value=\"ANU\">Antigua (ANU)</option>
          <option value=\"NGD\">Anegada Airport (NGD)</option>
          <option value=\"AXA\" selected=\"selected\">Anguilla (AXA)</option>
          <option value=\"DOM\">Dominica (DOM)</option>
          <option value=\"SJU\">Puerto Rico (SJU)</option>
          <option value=\"SKB\">St. Kitts (SKB)</option>
          <option value=\"EIS\">Tortola (EIS)</option>
          <option value=\"SXM\">St. Maarten (SXM)</option>
          <option value=\"STT\">St. Thomas (STT)</option>
          <option value=\"NEV\">Nevis (NEV)</option>
          <option value=\"VIJ\">Virgin Gorda Airport (VIJ)</option> 
        </select>
      </div>
    </div>
    <div>
      <div class=\"col-md-4 control-label\">Going to</div>
      <div class=\"col-md-8\">
        <select name=\"dest\" id=\"dest\" class=\"form-control\">
          <option value=''></option>
          <option value=\"ANU\">Antigua (ANU)</option>
          <option value=\"NGD\">Anegada Airport (NGD)</option>
          <option value=\"AXA\">Anguilla (AXA)</option>
          <option value=\"DOM\">Dominica (DOM)</option>
          <option value=\"SJU\">Puerto Rico (SJU)</option>
          <option value=\"SKB\" selected=\"selected\">St. Kitts (SKB)</option>
          <option value=\"EIS\">Tortola (EIS)</option>
          <option value=\"SXM\">St. Maarten (SXM)</option>
          <option value=\"STT\">St. Thomas (STT)</option>
          <option value=\"NEV\">Nevis (NEV)</option>
          <option value=\"VIJ\">Virgin Gorda Airport (VIJ)</option> 
        </select>
      </div>
    </div>
  </div>
  <div class=\"row lines\">
    <div class=\"col-xs-12 col-md-4 control-label\">Trip</div>
    <div class=\"checkbox col-xs-6 col-md-4\">
      <label>
        <input type=\"radio\" name=\"return\" value=\"1\" checked=\"checked\" />&nbsp;round trip
      </label>
    </div>
    <div class=\"checkbox col-xs-6 col-md-4\">
      <label>
        <input type=\"radio\" name=\"return\" value=\"0\" />&nbsp; One-Way
      </label>
    </div>
  </div>
  <div class=\"row lines\">
      <div class=\"col-xs-12 col-md-4 control-label\">Flexible</div>
      <div class=\"checkbox col-xs-6 col-md-4\">
        <label>
          <input type=\"radio\" name=\"selectedSearchType\" value=\"FLEXIBLE\" checked=\"checked\"/>&nbsp;Yes
        </label>
      </div>
      <div class=\"checkbox col-xs-6 col-md-4\">
        <label>
          <input type=\"radio\" name=\"selectedSearchType\" value=\"FIXED\"  />&nbsp;No
        </label>
      </div>
  </div>
  <div id=\"dates\" class=\"row lines\">
    <div class=\"col-md-4 control-label\">Dates</div>
    <div class=\"col-xs-12 col-md-4 date-selection-depart\">
      <!-- departing date 
      <div for=\"depart_date\">Outbound</div>-->
      <input id=\"flight-depart-date\" name=\"depart_date\" class=\"col-xs-12 form-control datepicker\" size=\"16\" type=\"text\" value=\"\" placeholder=\"departing\" autocomplete=\"off\">
    </div>
    <div class=\"col-xs-12 col-md-4 date-selection-return\">
      <!-- returning date 
      <div for=\"return_date\">Return</div>-->
      <input id=\"flight-return-date\" name=\"return_date\" class=\"col-xs-12 form-control datepicker\" size=\"16\" type=\"text\" value=\"\" placeholder=\"returning\" autocomplete=\"off\">
    </div>
  </div>
  <div id=\"pax\" class=\"row lines\">
      <input type=\"hidden\" name=\"passengers\" id=\"passengers\" value=\"\" />
      <div class=\"col-md-3\">
          <label>Adults</label>
          <select name=\"adult_passengers\" id=\"adult_passengers\" class=\"form-control\" onchange=\"javascript:udpatePaxTotalNbr()\">
            ";
        // line 87
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable(range(1, 10));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            if (((isset($context["i"]) ? $context["i"] : $this->getContext($context, "i")) == 1)) {
                // line 88
                echo "              <option value=\"";
                echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : $this->getContext($context, "i")), "html", null, true);
                echo "\" selected=\"selected\">";
                echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : $this->getContext($context, "i")), "html", null, true);
                echo "</option>
            ";
                $context['_iterated'] = true;
            }
        }
        if (!$context['_iterated']) {
            // line 90
            echo "              <option value=\"";
            echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : $this->getContext($context, "i")), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : $this->getContext($context, "i")), "html", null, true);
            echo "</option>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 92
        echo "          </select>
      </div>
      <div class=\"col-md-3\">
          <label class=\"flight-tooltip\" data-toggle=\"tooltip\" data-placement=\"top\" data-original-title=\"2-11 years\">Children*</label>
          <select name=\"child_passengers\" id=\"child_passengers\" class=\"form-control\" onchange=\"javascript:udpatePaxTotalNbr()\">
            ";
        // line 97
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable(range(0, 10));
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            // line 98
            echo "              <option value=\"";
            echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : $this->getContext($context, "i")), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : $this->getContext($context, "i")), "html", null, true);
            echo "</option>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 100
        echo "          </select>                      
      </div>
      <div class=\"col-md-3\">
          <label class=\"flight-tooltip\" data-toggle=\"tooltip\" data-placement=\"top\" data-original-title=\"60 or greater\">Seniors*</label>
          <select name=\"senior_passengers\" id=\"senior_passengers\" class=\"form-control\" onchange=\"javascript:udpatePaxTotalNbr()\">
            ";
        // line 105
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable(range(0, 10));
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            // line 106
            echo "              <option value=\"";
            echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : $this->getContext($context, "i")), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : $this->getContext($context, "i")), "html", null, true);
            echo "</option>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 108
        echo "          </select>                      
      </div>
      <div class=\"col-md-3\">
          <label class=\"flight-tooltip\" data-toggle=\"tooltip\" data-placement=\"top\" data-original-title=\"under 2 years\">Infant*</label>
          <select name=\"infant_passengers\" id=\"infant_passengers\" class=\"form-control\" onchange=\"javascript:udpatePaxTotalNbr()\">
            ";
        // line 113
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable(range(0, 10));
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            // line 114
            echo "              <option value=\"";
            echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : $this->getContext($context, "i")), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : $this->getContext($context, "i")), "html", null, true);
            echo "</option>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 116
        echo "          </select>                      
      </div>
  </div>
  <div class=\"row lines\">
    <div class=\"col-md-4 control-label\">Promo code</div>
    <div class=\"col-md-8\">
      <input type=\"text\" name=\"promo_code\" class=\"form-control\" />
    </div>
  </div>
  <div id=\"submit-flight\">
    <button type=\"submit\" class=\"btn btn-default pull-right\">Submit</button>
  </div>
</form>";
    }

    public function getTemplateName()
    {
        return "cjrpWebsiteBundle:Index:flight-booking.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  201 => 116,  190 => 114,  186 => 113,  179 => 108,  168 => 106,  164 => 105,  157 => 100,  146 => 98,  142 => 97,  135 => 92,  124 => 90,  113 => 88,  107 => 87,  19 => 1,  284 => 181,  280 => 180,  277 => 179,  274 => 178,  235 => 143,  222 => 133,  212 => 126,  203 => 120,  193 => 113,  184 => 107,  174 => 100,  151 => 80,  141 => 73,  131 => 66,  121 => 59,  111 => 52,  88 => 32,  82 => 29,  76 => 26,  56 => 10,  50 => 9,  44 => 6,  41 => 5,  38 => 4,  32 => 3,);
    }
}
