<?php

namespace cjrp\WebsiteBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Hotelbooking
 *
 * @ORM\Table(name="hotelbooking")
 * @ORM\Entity
 */
class Hotelbooking
{
    /**
     * @var integer
     *
     * @ORM\Column(name="hotelBooking_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $hotelbookingId;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=50, nullable=true)
     */
    private $name;

    /**
     * @var string
     *
     * @ORM\Column(name="island", type="string", length=45, nullable=false)
     */
    private $island;

    /**
     * @var string
     *
     * @ORM\Column(name="city", type="string", length=45, nullable=false)
     */
    private $city;

    /**
     * @var string
     *
     * @ORM\Column(name="type", type="string", length=20, nullable=true)
     */
    private $type;

    /**
     * @var float
     *
     * @ORM\Column(name="perDay", type="float", nullable=true)
     */
    private $perday;

    /**
     * @var float
     *
     * @ORM\Column(name="taxe", type="float", nullable=true)
     */
    private $taxe;

    /**
     * @var float
     *
     * @ORM\Column(name="govLevy", type="float", nullable=true)
     */
    private $govlevy;

    /**
     * @var float
     *
     * @ORM\Column(name="chargePerDay", type="float", nullable=true)
     */
    private $chargeperday;



    /**
     * Get hotelbookingId
     *
     * @return integer 
     */
    public function getHotelbookingId()
    {
        return $this->hotelbookingId;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return Hotelbooking
     */
    public function setName($name)
    {
        $this->name = $name;
    
        return $this;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set island
     *
     * @param string $island
     * @return Hotelbooking
     */
    public function setIsland($island)
    {
        $this->island = $island;
    
        return $this;
    }

    /**
     * Get island
     *
     * @return string 
     */
    public function getIsland()
    {
        return $this->island;
    }

    /**
     * Set city
     *
     * @param string $city
     * @return Hotelbooking
     */
    public function setCity($city)
    {
        $this->city = $city;
    
        return $this;
    }

    /**
     * Get city
     *
     * @return string 
     */
    public function getCity()
    {
        return $this->city;
    }

    /**
     * Set type
     *
     * @param string $type
     * @return Hotelbooking
     */
    public function setType($type)
    {
        $this->type = $type;
    
        return $this;
    }

    /**
     * Get type
     *
     * @return string 
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * Set perday
     *
     * @param float $perday
     * @return Hotelbooking
     */
    public function setPerday($perday)
    {
        $this->perday = $perday;
    
        return $this;
    }

    /**
     * Get perday
     *
     * @return float 
     */
    public function getPerday()
    {
        return $this->perday;
    }

    /**
     * Set taxe
     *
     * @param float $taxe
     * @return Hotelbooking
     */
    public function setTaxe($taxe)
    {
        $this->taxe = $taxe;
    
        return $this;
    }

    /**
     * Get taxe
     *
     * @return float 
     */
    public function getTaxe()
    {
        return $this->taxe;
    }

    /**
     * Set govlevy
     *
     * @param float $govlevy
     * @return Hotelbooking
     */
    public function setGovlevy($govlevy)
    {
        $this->govlevy = $govlevy;
    
        return $this;
    }

    /**
     * Get govlevy
     *
     * @return float 
     */
    public function getGovlevy()
    {
        return $this->govlevy;
    }

    /**
     * Set chargeperday
     *
     * @param float $chargeperday
     * @return Hotelbooking
     */
    public function setChargeperday($chargeperday)
    {
        $this->chargeperday = $chargeperday;
    
        return $this;
    }

    /**
     * Get chargeperday
     *
     * @return float 
     */
    public function getChargeperday()
    {
        return $this->chargeperday;
    }
}