<?php

namespace cjrp\WebsiteBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Carbooking
 *
 * @ORM\Table(name="carbooking")
 * @ORM\Entity
 */
class CarBooking
{
    /**
     * @var integer
     *
     * @ORM\Column(name="carBooking_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="company", type="string", length=50, nullable=true)
     */
    private $company;

    /**
     * @var string
     *
     * @ORM\Column(name="island", type="string", length=45, nullable=true)
     */
    private $island;

    /**
     * @var string
     *
     * @ORM\Column(name="type", type="string", length=45, nullable=true)
     */
    private $type;

    /**
     * @var string
     *
     * @ORM\Column(name="make", type="string", length=45, nullable=true)
     */
    private $make;

    /**
     * @var string
     *
     * @ORM\Column(name="model", type="string", length=45, nullable=true)
     */
    private $model;

    /**
     * @var string
     *
     * @ORM\Column(name="seats", type="string", length=5, nullable=true)
     */
    private $seats;

    /**
     * @var float
     *
     * @ORM\Column(name="perDay", type="float", nullable=true)
     */
    private $perDay;

    /**
     * @var float
     *
     * @ORM\Column(name="perWeek", type="float", nullable=true)
     */
    private $perWeek;

    /**
     * @var float
     *
     * @ORM\Column(name="chargePerDay", type="float", nullable=true)
     */
    private $chargePerDay;

    /**
     * @var float
     *
     * @ORM\Column(name="ratioChargePerWeek", type="float", nullable=true)
     */
    private $ratioChargePerWeek;

    
    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set company
     *
     * @param string $company
     * @return CarBooking
     */
    public function setCompany($company)
    {
        $this->company = $company;
    
        return $this;
    }

    /**
     * Get company
     *
     * @return string 
     */
    public function getCompany()
    {
        return $this->company;
    }

    /**
     * Set island
     *
     * @param string $island
     * @return CarBooking
     */
    public function setIsland($island)
    {
        $this->island = $island;
    
        return $this;
    }

    /**
     * Get island
     *
     * @return string 
     */
    public function getIsland()
    {
        return $this->island;
    }

    /**
     * Set type
     *
     * @param string $type
     * @return CarBooking
     */
    public function setType($type)
    {
        $this->type = $type;
    
        return $this;
    }

    /**
     * Get type
     *
     * @return string 
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * Set make
     *
     * @param string $make
     * @return CarBooking
     */
    public function setMake($make)
    {
        $this->make = $make;
    
        return $this;
    }

    /**
     * Get make
     *
     * @return string 
     */
    public function getMake()
    {
        return $this->make;
    }

    /**
     * Set model
     *
     * @param string $model
     * @return CarBooking
     */
    public function setModel($model)
    {
        $this->model = $model;
    
        return $this;
    }

    /**
     * Get model
     *
     * @return string 
     */
    public function getModel()
    {
        return $this->model;
    }

    /**
     * Set seats
     *
     * @param string $seats
     * @return CarBooking
     */
    public function setSeats($seats)
    {
        $this->seats = $seats;
    
        return $this;
    }

    /**
     * Get seats
     *
     * @return string 
     */
    public function getSeats()
    {
        return $this->seats;
    }

    /**
     * Set perDay
     *
     * @param float $perDay
     * @return CarBooking
     */
    public function setPerDay($perDay)
    {
        $this->perDay = $perDay;
    
        return $this;
    }

    /**
     * Get perDay
     *
     * @return float 
     */
    public function getPerDay()
    {
        return $this->perDay;
    }

    /**
     * Set perWeek
     *
     * @param float $perWeek
     * @return CarBooking
     */
    public function setPerWeek($perWeek)
    {
        $this->perWeek = $perWeek;
    
        return $this;
    }

    /**
     * Get perWeek
     *
     * @return float 
     */
    public function getPerWeek()
    {
        return $this->perWeek;
    }

    /**
     * Set chargePerDay
     *
     * @param float $chargePerDay
     * @return CarBooking
     */
    public function setChargePerDay($chargePerDay)
    {
        $this->chargePerDay = $chargePerDay;
    
        return $this;
    }

    /**
     * Get chargePerDay
     *
     * @return float 
     */
    public function getChargePerDay()
    {
        return $this->chargePerDay;
    }

    /**
     * Set ratioChargePerWeek
     *
     * @param float $ratioChargePerWeek
     * @return CarBooking
     */
    public function setRatioChargePerWeek($ratioChargePerWeek)
    {
        $this->ratioChargePerWeek = $ratioChargePerWeek;
    
        return $this;
    }

    /**
     * Get ratioChargePerWeek
     *
     * @return float 
     */
    public function getRatioChargePerWeek()
    {
        return $this->ratioChargePerWeek;
    }
}