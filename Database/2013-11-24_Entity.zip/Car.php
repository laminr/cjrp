<?php

namespace cjrp\WebsiteBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

use cjrp\WebsiteBundle\Entity\Label;
/**
 * Car
 *
 * @ORM\Table(name="car")
 * @ORM\Entity
 */
class Car
{
    /**
     * @var integer
     *
     * @ORM\Column(name="car_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="model", type="string", length=45, nullable=true)
     */
    private $model;

    /**
     * @var integer
     *
     * @ORM\Column(name="capacity", type="integer", nullable=true)
     */
    private $capacity;

    /**
     * @var \Label
     *
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     * @ORM\OneToOne(targetEntity="Label")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="make_label_id", referencedColumnName="label_id")
     * })
     */
    private $make;

    /**
     * @var \Label
     *
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     * @ORM\OneToOne(targetEntity="Label")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="type_label_id", referencedColumnName="label_id")
     * })
     */
    private $type;

    public function __construct() {
        $this->make = new \Label("CAR_MAKE");
        $this->make = new \Label("CAR_TYPE");
    }

    /**
     * Set id
     *
     * @param integer $id
     * @return Car
     */
    public function setId($id)
    {
        $this->id = $id;
    
        return $this;
    }

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set model
     *
     * @param string $model
     * @return Car
     */
    public function setModel($model)
    {
        $this->model = $model;
    
        return $this;
    }

    /**
     * Get model
     *
     * @return string 
     */
    public function getModel()
    {
        return $this->model;
    }

    /**
     * Set capacity
     *
     * @param integer $capacity
     * @return Car
     */
    public function setCapacity($capacity)
    {
        $this->capacity = $capacity;
    
        return $this;
    }

    /**
     * Get capacity
     *
     * @return integer 
     */
    public function getCapacity()
    {
        return $this->capacity;
    }

    /**
     * Set make
     *
     * @param \cjrp\WebsiteBundle\Entity\Label $make
     * @return Car
     */
    public function setMake(\cjrp\WebsiteBundle\Entity\Label $make)
    {
        $this->make = $make;
    
        return $this;
    }

    /**
     * Get make
     *
     * @return \cjrp\WebsiteBundle\Entity\Label 
     */
    public function getMake()
    {
        return $this->make;
    }

    /**
     * Set type
     *
     * @param \cjrp\WebsiteBundle\Entity\Label $type
     * @return Car
     */
    public function setType(\cjrp\WebsiteBundle\Entity\Label $type)
    {
        $this->type = $type;
    
        return $this;
    }

    /**
     * Get type
     *
     * @return \cjrp\WebsiteBundle\Entity\Label 
     */
    public function getType()
    {
        return $this->type;
    }
}